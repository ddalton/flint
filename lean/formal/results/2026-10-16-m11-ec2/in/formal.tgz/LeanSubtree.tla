------------------------------ MODULE LeanSubtree ------------------------------
(***************************************************************************)
(* The lean (checkout/publish) subtree protocol, modelled BEFORE the code  *)
(* exists — the FlintExtents posture.  Spec of record:                     *)
(* docs/plans/flint-lean-plan.md v2 (f0776e0), §2.1 barrier + §2.2         *)
(* inbox/window/takeover.  This module is deliberately SEPARATE from the   *)
(* flint corpus in formal/: lean is a separate system that reuses tier::   *)
(* as a library, and its protocol lives in the bucket, not in the hub.     *)
(*                                                                         *)
(* One subtree.  Two syncer incarnations (A, then B after takeover), a    *)
(* gateway abstracted to its bucket effects (HITL writes, window check,    *)
(* per-request epoch validation), and the bucket substrate: lease cell,    *)
(* manifest (seq + per-path citation), whole-file objects (per-path        *)
(* generation = ETag), the inbox/window cell.                              *)
(*                                                                         *)
(* Generations model ETags: objects[p] = g means the object at p currently *)
(* has content/ETag g; 0 = absent.  If-Match is modelled as an equality    *)
(* test against the writer's expected generation.  Whole-PUT atomicity is  *)
(* assumed (real S3 gives it for PutObject).                               *)
(*                                                                         *)
(* Deliberate abstractions (tranche 1 — each is a README entry, not a      *)
(* claim of coverage):                                                     *)
(*   - The scan is ATOMIC, so the rename-vs-walk race and the             *)
(*     two-consecutive-scans deletion rule are UNREPRESENTABLE here.       *)
(*   - The 6-quiet-poll takeover observation is abstracted into a single   *)
(*     ClaimB action enabled when A is stalled or dead.  The poll protocol *)
(*     itself is machine-checked in flint's FlintTierEpoch.tla; lean       *)
(*     re-scopes it and tranche 2 may refine it here.                      *)
(*   - Checkout reads the manifest's citations without modelling           *)
(*     hydrate's 412/S3-wins arm.                                          *)
(*   - The sync verb, multi-subtree layout, partial checkout, preStop      *)
(*     timing, and all perf axes are out of scope (tranche 2+ / Phase 0b). *)
(*   - conflicts is a set of (path, generation) RECORDS.  The             *)
(*     implementation obligation this hides: a conflict record must        *)
(*     preserve the BYTES (conflict-suffixed key or versioning), not just  *)
(*     the reference — otherwise "both versions recoverable" is false.     *)
(***************************************************************************)
EXTENDS Naturals, FiniteSets, Sequences, TLC

CONSTANTS
  Paths,          \* model values, e.g. {p1, p2}
  MaxGen,         \* generation mint budget (Init uses 1; mints start at 2)
  MaxSeq,         \* manifest CAS budget
  MaxHitl,        \* HITL write budget
  MaxBarriers,    \* barrier (scan) budget
  MaxCrashes,     \* pod hard-kill budget
  MaxRestarts,    \* container-restart budget
  MaxSyncs,       \* sync-verb budget
  AllowStall,     \* enable the stall/thaw arm (the straggler world)
  \* ---- protocol arms: TRUE = plan v2; FALSE = the refuted design -------
  InboxEnabled,        \* FALSE: gateway direct-manifest-bump (the v1 reading)
  MergeCapable,        \* FALSE: whole-rewrite writer (412 -> re-seed -> overwrite)
  ConflictSurfacing,   \* FALSE: LOCAL-WINS silently (the flush.rs:1391 reuse)
  WindowCheck,         \* FALSE: gateway admits HITL during an open window
  Rotation,            \* successor CAS-rotates manifest seq before serving
  EpochCheck,          \* per-request epoch validation on syncer writes
  GuardedGC,           \* HEAD etag-guard before the GC delete
  DeletesAfterCAS,     \* FALSE: v1 order upload -> delete -> CAS
  RematerializeOnRestart, \* TRUE = mutation: re-checkout over a live tree
  \* ---- tranche 2: the sync verb x barrier product ----------------------
  SyncEnabled,         \* FALSE in every tranche-1 cfg (spaces preserved)
  SyncScanFirst,       \* FALSE: sync judges dirt from the LAST BARRIER's
                       \* snapshot instead of its own scan (the refuted
                       \* design; the review's steady-state destruction)
  \* ---- tranche 3 product 4: the SCOPED sync verb (boundary-verbs D4) ----
  SyncScope,           \* TRUE: the sentinel's scoped form — remote changes
                       \* apply only to in-scope paths.  FALSE in every
                       \* tranche-1/2 cfg, so those state spaces are
                       \* preserved by construction.
  ScopedInstBase,      \* TRUE  = D4: a scoped sync advances the MERGE BASE
                       \* only for paths it applied or verified in scope.
                       \* FALSE = the mutation: it advances the whole
                       \* instBase to bucket-current, so every out-of-scope
                       \* foreign entry reads as already-integrated at the
                       \* next merge and is lost from the inbox flow
                       \* FOREVER.  `instBase` is the object the model has
                       \* refuted naive designs on twice; D4 rewrites its
                       \* per-path semantics, which is why it is modelled.
  \* ---- tranche 3 product 2: gated citation x version GC x backstop -----
  \* (boundary-verbs D6/D7/D8/D13.)  Generations are unique mints, so a
  \* generation IS a version id and `manifest[p]` already cites one; the
  \* substrate this product adds is `versions[p]` — the generations that
  \* still EXIST as stored versions, which on a versioned bucket is a
  \* different question from what the object currently reads as.
  \*
  \* That distinction is the whole tranche.  `Inv_NoDangling` asks
  \* "does the object exist" and was the right question until D7: gated
  \* staging makes the CITED version noncurrent, so an object can exist,
  \* read as newer uncited bytes, and have nothing behind its citation.
  GatedCitation,       \* FALSE in every pre-existing cfg: the gated
                       \* actions are disabled and `versions`/`stage`/
                       \* `withheldDel` stay frozen at Init, so every
                       \* earlier state space is preserved by construction.
  AtomicCitation,      \* TRUE = D6: ONE CAS installs the entire pending
                       \* set.  FALSE = the mutation: the install is split
                       \* across two CASes, so a reader can see half a
                       \* logical change.
  GCKeepsCurrent,      \* TRUE = the reaper never reclaims the CURRENT
                       \* version.  FALSE = the shipped rule THIS MODEL
                       \* REFUTED: "delete every version of a touched key
                       \* except the one the installed manifest cites"
                       \* deletes a foreign write that landed between the
                       \* lane and the citation — and it was current,
                       \* acked, and about to be read.
  CiteDropsInflightHitl, \* TRUE = a staged path with a LIVE INBOX ENTRY is
                       \* dropped from the boundary rather than cited
                       \* over.  The base-version check cannot see that
                       \* write (it reads the baseline, and the citation
                       \* lane consumes nothing) and the lane opens no
                       \* window, so the inbox is the only witness — and
                       \* the window CAS has already loaded it.
  \* ---- tranche 3 product 1: the boundary VERB x barrier x inbox --------
  \* (boundary-verbs D1/D2/D3/D12.)  The sentinel is a FILE in the tree,
  \* not a bucket object: the agent touches `.flint/publish`, the syncer
  \* renames it into its own state dir (the consume), honors it with a
  \* real barrier, writes `.flint/publish.ack`, and retires the pending
  \* record.  What this product searches is the interleaving of those
  \* four steps with the barrier, the inbox, restarts and DEPOSAL.
  SentinelEnabled,     \* FALSE in every pre-existing cfg: every sentinel
                       \* action is disabled and the new sc fields stay
                       \* frozen at their (empty) Init values, so earlier
                       \* state spaces are preserved by construction.
  MaxTouches,          \* agent touch budget (a touch id doubles as the
                       \* nonce AND as the sentinel's mtime clock).
  FoldPending,         \* TRUE = D2.1: a consume never overwrites the
                       \* standing pending record, it FOLDS into it, so
                       \* every coalesced nonce is still named by the ack
                       \* that eventually lands.  FALSE = the mutation:
                       \* the rename clobbers the old record and orphans
                       \* its nonces forever.
  AckFromInstall,      \* TRUE = the uniform crash rule: an ok ack is only
                       \* ever written from a barrier that ran STRICTLY
                       \* AFTER the consume.  FALSE = the mutation the
                       \* review retracted from the draft's crash matrix:
                       \* ack from persisted state, which is the same
                       \* observable state for crash-before-CAS as for
                       \* crash-after-step-7 and asserts publication of
                       \* writes that never uploaded.
  RefuseOnFence,       \* TRUE = D2: a deposed incarnation answers every
                       \* owed sentinel with `refused-fenced` and never
                       \* with ok — on the honor path AND on the D12
                       \* heartbeat arm, which is decoupled from publish
                       \* cadence and so usually discovers deposal first.
                       \* FALSE = the mutation: success-ack-after-fence.
  FastPathGuards,      \* TRUE = the shipped skip-on-no-diff fast path
                       \* with all of its guards: nothing local, no
                       \* citation repair owed, and the remote manifest
                       \* where we left it.  FALSE = the mutation that
                       \* drops the last two.  This arm is modelled
                       \* because §10.1 records a DELIBERATE deviation
                       \* from §2.1 here — the shipped honor path lets a
                       \* no-diff sentinel take the fast path, on the
                       \* strength of a prose argument.  This is that
                       \* argument, machine-checked.
  GatedRepair,         \* TRUE = the citation lane carries the same
                       \* citation-repair the fused barrier has: re-cite
                       \* an object this syncer INTEGRATED (a consumed
                       \* HITL write) whose citation is still behind it.
                       \* FALSE = what shipped, where the repair lived
                       \* only in the fused barrier — which gated mode
                       \* structurally never runs — so an acked HITL
                       \* write stayed cited at its predecessor forever
                       \* (§2.4.2's exemption and D13's "within one
                       \* floor", both prose-only until C2).
  LaneCancelsStaged,   \* TRUE = a withheld delete cancels the version the
                       \* stage still holds for that path (and vice
                       \* versa, in the lane).  FALSE = the shipped lane
                       \* before C3's second half: the stage and the
                       \* tombstone set both reach the citation and
                       \* merge order decides, which cites a file the
                       \* agent deleted.  FALSE in every pre-existing
                       \* cfg — including `LeanGatedInflightHitl`, whose
                       \* counterexample runs through exactly the shape
                       \* this arm closes (see the ledger note there).
  AckHonest,           \* TRUE = a boundary that does not carry a path the
                       \* agent declared is answered with a partial ack
                       \* naming it, never with `ok`: a gated citation
                       \* that DROPPED the path, or (2026-09-14) a fused
                       \* install whose merge kept another writer's
                       \* entry over the agent's delete.  FALSE = the
                       \* mutation, which is what shipped until then:
                       \* `status: "ok"` whenever nothing was parked.
                       \* FALSE in every pre-existing cfg: citeDropped
                       \* stays {} there, so their spaces are preserved.
  MineIsNotForeign,    \* TRUE = a commit that finds the pointer still at
                       \* the document IT installed merges onto THAT
                       \* document, whatever the persisted merge base
                       \* says.  The merge base is rewritten at step 7,
                       \* so a barrier that crashed between its manifest
                       \* CAS and that rewrite leaves the workspace's own
                       \* installed entry looking like somebody else's —
                       \* and delete/modify then resolves conservatively
                       \* AGAINST the agent's own delete.  FALSE = the
                       \* shipped rule THIS MODEL REFUTED
                       \* (`LeanSentinelStaleMergeBase`).  2026-09-21: the
                       \* MECHANISM is now the code's — the intent
                       \* journal's `installed_etag`, read at the merge
                       \* (`MergeBase`) — and not a flat set of every
                       \* generation the writer ever knew, which excused
                       \* far more than this window and hid the defect
                       \* `LeanCoreForeignFlat` prices.
  BackstopEnabled,     \* TRUE = the noncurrent-retention lifecycle rule
                       \* fires.  It is a BACKSTOP, never the reaper, and
                       \* enabling it is a mutation: on `files/` it cannot
                       \* tell cited from uncited, so it runs a clock
                       \* against live cited data (D8's inversion, and
                       \* §2.4.3's abandoned-mid-stage endgame).
  TwoScanDelete,       \* TRUE = a path is delete-eligible only if it was
                       \* ALSO ABSENT at the PREVIOUS scan — the shipped
                       \* two-consecutive-scans rule (`scan.rs` classify:
                       \* absent now and in `prev_scan` is a FIRST
                       \* absence, withheld).  Until 2026-09-12 this read
                       \* `p \in prevScan` — present at the previous scan
                       \* — which is a one-scan rule with a spurious
                       \* conjunct; the narrow runs did not notice (their
                       \* comment records that prevScan changed nothing
                       \* there), and the declared-removal mutation could
                       \* not be expressed against it.
                       \* FALSE in every PRE-EXISTING cfg, deliberately:
                       \* this tranche is the first to model `prev_scan`
                       \* at all, and turning it on globally would shrink
                       \* every earlier run's delete space and let a
                       \* pinned mutation stop finding its counterexample.
  MaxNarrows,          \* bound on Narrow actions (0 disables the verb).
  NarrowAtomic,        \* TRUE = the SHIPPED rule: a narrow removes the
                       \* path from the baseline, from `prevScan` and
                       \* from the tree in ONE step.  FALSE selects a
                       \* naive arm via NarrowUnlinkFirst.
  NarrowUnlinkFirst,   \* only under ~NarrowAtomic.  TRUE = unlink and
                       \* leave the citation (classify reads a DELETE);
                       \* FALSE = uncite and leave the file (classify
                       \* reads an UPLOAD).  Both are the naive orders
                       \* §4.2 says are each destructive on their own.
  StampBoundarySource, \* TRUE = every install stamps the manifest with
                       \* the SAME clock its ack will name.  FALSE = the
                       \* mutation, and it is what shipped: the barrier
                       \* installed through an UNSTAMPED CAS, so every
                       \* boundary read as the default clock no matter
                       \* what drove it — and a drain that renamed its own
                       \* ack left the bucket and the agent naming two
                       \* different clocks for one boundary.  The ack is a
                       \* LOCAL file; the manifest is what the fleet
                       \* reads, so the bucket held the wrong one.
  \* ---- tranche 5: DECLARED removals (delete/rename design §3-§6) --------
  MaxRemovals,         \* budget for HitlRemove/HitlRename; 0 in every
                       \* pre-existing cfg, so `removals` stays {} and
                       \* those state spaces are preserved by construction.
  DeclaredSkipsWalk,   \* TRUE = §4: a declared removal goes STRAIGHT into
                       \* the delete set at the scan that follows its
                       \* consume.  FALSE = the mutation: the consume only
                       \* unlinks and the walk infers the absence — under
                       \* the two-scan rule that is one barrier late, and a
                       \* rename's two halves land in two generations.
  FreePaths,           \* the paths that start UNPUBLISHED (a rename needs
                       \* a free destination; every pre-existing cfg has
                       \* {} and starts every path at gen 1 as before).
  RenameWaitsForDestination, \* TRUE = a rename's removal is performed only
                       \* once its destination is INTEGRATED AND CLEAN.
                       \* FALSE = the mutation: the source goes as soon as
                       \* it is clean, whatever became of the destination.
  EarlyInboxDrop,      \* TRUE = the rule that SHIPPED until 2026-09-12: a
                       \* consume clears the inbox at once ("durably in
                       \* the baseline").  FALSE = consumed entries leave
                       \* the cell at Finish / CiteFinish, after the
                       \* manifest cites them.  TRUE is the mutation: a
                       \* pod REPLACEMENT between the two takes the
                       \* baseline with the emptyDir, and an acked write
                       \* is then tracked by nothing.
  \* ---- tranche 6: the PER-BARRIER lease (writer-lease design §4-§5) ----
  \* The cell is held for ONE barrier's commit section — claim after the
  \* uploads, release after the baseline — instead of for the pod's life,
  \* and it carries a FIFO ticket.  Both syncers run from the start; the
  \* takeover (`ClaimB`) is the life-lease world's and does not exist
  \* here: a dead holder mid-commit is deposed by the generic `Claim`.
  BarrierLease,        \* FALSE in every pre-existing cfg: `StartA`/`ClaimB`
                       \* keep the life lease, `Scan` opens the window,
                       \* every fence kills, and the three new cell
                       \* variables stay frozen at Init — those state
                       \* spaces are preserved by construction.
  Ticket,              \* TRUE = release names the queue head as the
                       \* HANDOFF and only the handoff may acquire a
                       \* released cell.  FALSE = the mutation (falsifier
                       \* L5): release names nobody and any syncer may
                       \* acquire — random arbitration, and under
                       \* fairness one writer claims forever.
  DeadHandoffSkip,     \* TRUE = a released cell whose handoff is quiet
                       \* (dead or stalled, the 20 s rule) may be acquired
                       \* by anyone and the handoff is dropped.  FALSE =
                       \* the mutation: a crashed waiter wedges the cell
                       \* for every survivor, forever.
  InfiniteBarriers,    \* TRUE = the LIVENESS abstraction, and nothing
                       \* else: the barrier budget, the manifest seq and
                       \* the epoch SATURATE instead of stopping the world
                       \* (every counter a no-change barrier moves is
                       \* monotone, so with budgets the state graph has no
                       \* cycle and TLC cannot exhibit "claims forever").
                       \* Only meaningful under FairSpec; every safety run
                       \* keeps FALSE.
  ConditionalGC,       \* TRUE = the GC delete carries If-Match on the
                       \* recognised etag: guard and delete are ONE
                       \* request, which is what this module's atomic
                       \* `GCDelete` has always modelled.  FALSE = what
                       \* SHIPS (`barrier.rs` step 6): a HEAD, then an
                       \* unconditional DELETE.  Under the life lease the
                       \* lease covered that window; under the barrier
                       \* lease the other writer's uploads hold no lease,
                       \* and a supersede landing between the two dangles
                       \* its citation.  THE MODEL FOUND THIS the moment
                       \* the step was made two steps — see
                       \* LeanBarrierLeaseGCUnconditional.  Modelled only
                       \* under BarrierLease (TRUE everywhere else, so
                       \* every earlier state space is preserved).
  VerifyAdoptedCitations,\* TRUE = an entry this barrier ADOPTED (the 412
                       \* arm found its own bytes already there and cited
                       \* the existing object) is re-verified INSIDE the
                       \* commit section and withheld if the object is
                       \* gone.  FALSE = what SHIPS: the adopt cites blind.
                       \* Under the life lease nothing else could GC the
                       \* object; under the barrier lease the other
                       \* writer's commit can uncite it and its GC — HEAD-
                       \* guarded on an etag it learned at checkout —
                       \* deletes it between the adopt and the adopter's
                       \* CAS.  A same-bytes re-PUT would not help: a real
                       \* etag is the content hash.  The commit section is
                       \* the one race-free place to look, because GCs run
                       \* only under the lease.  THE MODEL FOUND THIS at
                       \* depth 28 of the first two-writer stall run.
                       \* Only under BarrierLease; TRUE elsewhere.
  HitlOverwritesTrackedOnly, \* TRUE = a HITL write (the gateway) overwrites
                       \* only a version the workspace TRACKS: the object at
                       \* the key is the manifest's citation or an inbox
                       \* entry (or absent).  FALSE = what shipped until
                       \* 2026-09-13: any current object, including another
                       \* writer's upload its commit has not cited — which,
                       \* under the barrier lease (no window during
                       \* uploads), loses the acked HITL write
                       \* (LeanBarrierLeaseHitlOverUncited).  FALSE in every
                       \* pre-existing cfg, so earlier state spaces are
                       \* preserved by construction.
  SyncKeepsHiddenBase, \* TRUE = a sync does NOT advance the merge base for
                       \* a path whose remote truth came from an inbox
                       \* overlay that differs from the manifest: the
                       \* manifest's version was hidden from it, never
                       \* applied or verified (`sync.rs` step 5, built
                       \* 2026-09-13 for LeanBarrierLeaseSyncOverlayStale).
                       \* FALSE in every pre-existing cfg — the shipped
                       \* advance — so earlier state spaces are preserved
                       \* by construction.
  MaxSameBytes,        \* budget for `AgentWriteSame`: the agent writes a
                       \* file with bytes some version it RECOGNISES
                       \* already has.  A generation here is a unique
                       \* mint; a real S3 etag is the MD5 of the bytes,
                       \* so two PUTs of identical bytes carry ONE etag
                       \* and an etag-guarded GC cannot tell them apart.
                       \* The module modelled every write as a fresh mint
                       \* until the live drill found what that hid
                       \* (finding 13, runcv A3).  0 in every
                       \* pre-existing cfg, so the action is unreachable
                       \* and `touched` stays {} — those state spaces are
                       \* preserved by construction.
  VerifyUploadedCitations,\* TRUE = CASInstall re-verifies EVERY citation
                       \* its own uploads add, not only the adopted ones,
                       \* and withholds what is gone (`barrier.rs`, the
                       \* commit section's re-read, 79e7dac9).  FALSE =
                       \* the rule before it: an upload that LANDED is
                       \* cited without a look, which is sound only while
                       \* no other writer's GC can recognise its etag.
                       \* BarrierLease only.  FALSE in every pre-existing
                       \* cfg: with unique mints the other writer's GC
                       \* never recognises an uncited upload, but a HITL
                       \* write over one does move it, and
                       \* LeanBarrierLeaseHitlOverUncited must keep
                       \* finding its counterexample.
  \* ---- tranche 7: MODEL THE IMPLEMENTATION (2026-09-15) -----------------
  \* Three things the code has done since v1.52.0 that this module did
  \* not.  Each was a named gap in the CHANGELOG, and each changes which
  \* interleavings exist, so a green run over the old shape was a claim
  \* about a design the code no longer has.
  WriterQueue,         \* TRUE = what ships: the other writers' changes a
                       \* merge carries into the manifest go to THIS
                       \* writer's LOCAL queue (`state::queue_foreign`,
                       \* keyed by path, a later change replacing the
                       \* queued one), deletions included, and the next
                       \* consume drains it BEFORE the shared inbox's
                       \* entries and applies its deletions AFTER them
                       \* (`barrier.rs` `consume_counted`).  The queue is
                       \* a file in the state directory: a restart keeps
                       \* it, a pod replacement takes it.  FALSE = this
                       \* module's shape until now: foreign upserts
                       \* re-queued into the SHARED inbox, foreign
                       \* deletions never reaching the other tree at all.
                       \* BarrierLease only; FALSE in every pre-existing
                       \* cfg, where `fq` stays {}.
  EmptyInstall,        \* TRUE = what ships: a barrier that adds nothing
                       \* installs nothing.  Three routes (`barrier.rs`):
                       \* the skip-on-no-diff fast path on EVERY barrier
                       \* (not only a sentinel honor); the PULL-ONLY
                       \* boundary — nothing uploaded, deleted, consumed,
                       \* removed or re-cited — which queues theirs and
                       \* takes it as the merge base with no claim, no
                       \* window and no CAS; and a commit whose merge
                       \* equals theirs, which skips the CAS and keeps
                       \* the seq.  FALSE = every install advanced the
                       \* seq, the CHANGELOG's "no empty-install rule".
                       \* Requires WriterQueue (the pull-only route
                       \* queues locally; it has no window to write the
                       \* inbox under).
  TombstoneHeadsKey,   \* TRUE = the fix for what modelling the queue found
                       \* (2026-09-15): a queued DELETION applies only
                       \* while the key is still absent — a key holding an
                       \* object means a newer write superseded it, which
                       \* is the rule the queue's UPSERTS already follow
                       \* ("superseded").  FALSE = what shipped: the
                       \* deletion runs after the consume's entries, over
                       \* whatever they just adopted, so a UI write that
                       \* re-created a path a peer deleted is removed from
                       \* the tree the same consume adopted it into, and
                       \* the window clear then drops its inbox entry —
                       \* acked, and tracked by nothing
                       \* (LeanBarrierLeaseQueueTombstoneOverHitl).
                       \* WriterQueue only.
  \* Three more, found by TRACE VALIDATION (lean/formal/trace/): the first
  \* syncer traces checked against this module were rejected at exactly
  \* these steps.  Each is what the code does; FALSE keeps every earlier
  \* state space.
  CommitLoadsCurrent,  \* TRUE = the commit merges onto the manifest it
                       \* LOADS after the claim and CASes against that
                       \* (`barrier.rs` commit section), so a writer whose
                       \* last seq is stale does not first lose a CAS.
                       \* FALSE = CASInstall If-Matches the seq remembered
                       \* from the writer's last boundary (CASMiss first).
  Upload412Preserves,  \* TRUE = `upload_one`'s 412 policy since review
                       \* 2026-09-12 (inbox-1): a FOREIGN version at the
                       \* key is preserved as a conflict copy and then
                       \* superseded knowingly; the path parks only when
                       \* that races (a second 412) or the preserve fails.
                       \* FALSE = the park this module always modelled.
  DeclaredConfirmsAbsence, \* TRUE = a DECLARED barrier (a sentinel honor)
                       \* confirms a first absence with a fresh stat and
                       \* deletes it at once (`confirm_absences`); and the
                       \* skip-on-no-diff fast path refuses a pending first
                       \* absence and still advances the two-scan clock.
                       \* FALSE = the two-scan rule on every barrier and a
                       \* fast path blind to first absences.
  OrphanTrack,         \* FINDING 10 (shipped 2026-09-16 as `untracked.rs`;
                       \* IMPL keeps it FALSE, SAFETY.md §4.11): a writer lost for good between
                       \* its upload and its commit leaves bytes at a
                       \* CITED key that no manifest cites and nothing
                       \* tracks.  TRUE = the candidate fix: a writer that
                       \* finds such an object appends it to the shared
                       \* inbox, as a UI write is tracked, and the normal
                       \* consume integrates it.  The action is allowed
                       \* WHENEVER the object is untracked — the grace that
                       \* keeps a live writer's in-flight upload out of it
                       \* is not modelled, so a green run means the grace
                       \* is not what keeps anything safe.  FALSE = what
                       \* ships.  BarrierLease only.
  Writers,             \* tranche 7: the writers, IN START ORDER, as a
                       \* sequence of names.  <<"A", "B">> in every cfg
                       \* before the third-writer worlds, and the life
                       \* lease's actions (StartA, ClaimB, CheckoutB) and
                       \* the stall (A only) still name those two.
  BaselineKeepsUncollected, \* TRUE = what SHIPS, found by replaying the
                       \* storm (W4 phase 2): step 7 drops a path from the
                       \* baseline only for the deletes whose OBJECT the GC
                       \* actually collected (`report.deleted`).  A delete
                       \* whose GC SKIPPED — the key held bytes this writer
                       \* does not recognize — keeps its baseline entry, so
                       \* the tree reads as locally deleted at the next
                       \* consume and an incoming version is PRESERVED
                       \* rather than adopted.  FALSE = the model as it was:
                       \* every published delete clears the baseline.
  InboxSnapshot,       \* TRUE = what SHIPS: the barrier reads the cell ONCE,
                       \* at its first step (`barrier.rs` step 1, "the cell,
                       \* read ONCE"), and consumes from that SNAPSHOT.
                       \* Another writer's window clear can empty the shared
                       \* inbox in between, and the code still integrates
                       \* what it read.  FALSE = the model as it was: the
                       \* consume reads the inbox at the instant it runs, so
                       \* it has nothing to adopt and the step is not
                       \* enabled.  THE REPLAY OF churn/p47.txt FOUND THIS
                       \* (W4 phase 2, R3-S2): the model was less faithful
                       \* than the code, not wrong about it.  FALSE
                       \* everywhere else, so every earlier state space is
                       \* preserved by construction.
  CollectorOff,        \* TRUE = the collector GIVES WAY: it recognises the
                       \* object and still does not delete it.  Not a
                       \* mutation and not a defect — it is what the syncer
                       \* does on a store that accepts `If-Match` on DELETE
                       \* and ignores it (`conformance.rs`, Ozone 2.2.x,
                       \* HDDS-14907).  There the shipped DELETE would be
                       \* `ConditionalGC=FALSE`, which this module refutes,
                       \* so the code leaves the object where it is.  The
                       \* question this constant exists to answer is whether
                       \* LEAKING is safe: the object survives, cited by no
                       \* manifest, and because it is not in `gcTook` the
                       \* baseline keeps its entry under
                       \* BaselineKeepsUncollected — exactly the arm a
                       \* SKIPPED etag already takes.  FALSE everywhere
                       \* else, so every earlier state space is preserved.
  ClaimMintsEpoch,     \* TRUE = what ships: every claim writes a NEW epoch
                       \* (`lease.rs`'s acquire increments).  FALSE = the
                       \* mutation: a claim REUSES the cell's epoch, so two
                       \* writers hold at the same epoch and neither reads as
                       \* deposed — the refutation `Inv_CommitExclusive` had
                       \* none of (COVERAGE.md, 2026-09-15).
  ClaimStampsEpoch,    \* TRUE = what ships: the claimant records the epoch it
                       \* claimed at, which is what every later fence compares
                       \* against.  FALSE = the mutation: the cell names a
                       \* holder whose own epoch is older, and
                       \* `Inv_CellHeldByHolder` catches it.
  AbandonOnStoreError, \* TRUE = the code's other way out of a commit
                       \* section, which the 2026-09-15 storm traces show
                       \* and the model had no step for: the store REFUSES
                       \* a request the commit makes (S3 answered the
                       \* window-open PUT with 409 ConditionalRequestConflict),
                       \* the barrier returns the error, releases the cell
                       \* and keeps its pending sentinel, and the next
                       \* barrier redoes the work.  Nothing is installed and
                       \* nothing is acked.  FALSE = the model as it was: a
                       \* claimed barrier only ever installs, misses the CAS
                       \* or is fenced.  BarrierLease only.
  ProjectedTrace,      \* Trace validation only (W4 phase 2).  TRUE = this
                       \* run replays ONE PATH of a live leg, so a barrier's
                       \* reason to claim may lie in a path the projection
                       \* dropped: `WantsCell` then holds on a scanned
                       \* barrier whatever the projected paths show.  It
                       \* relaxes NOTHING else, and no gate run sets it.
  QueueForeignChanges, \* TRUE = what ships.  FALSE = the mutation: the
                       \* merge base moves past the other writers'
                       \* changes and nothing queues them, so the tree
                       \* never receives them — the direct fingerprint of
                       \* the harm `Inv_AckBoundaryCoherent`'s queue
                       \* exemption must NOT excuse (the known-bad run for
                       \* that relaxation).  WriterQueue only.
  \* ---- review 2026-09-18: C2 and H1 -----------------------------------
  GCFencePerDelete,    \* TRUE = the fix: the collector observes the cell
                       \* before EVERY delete (the code: a renew whenever
                       \* the last cell WRITE is older than the renew
                       \* spacing, which a deposal's 60 s stillness always
                       \* exceeds).  FALSE = what shipped: the cell is read
                       \* before the CAS and then every 200 deletes, and
                       \* the DELETE itself carries no epoch — so a holder
                       \* deposed AFTER its CAS landed still deletes, and
                       \* takes an etag the successor has just re-cited
                       \* (same bytes, or an adoption).  The module's
                       \* atomic `~Fenced` guard on GCDelete hid it.
  TombstoneNamesRetired, \* TRUE = the fix: a queued deletion carries the
                       \* generation the peer's delete RETIRED (the merge
                       \* base's citation), and an object at the key
                       \* supersedes it only when it is a DIFFERENT
                       \* generation.  FALSE = what shipped: any object
                       \* at the key supersedes it — including the peer's
                       \* own leaked object on a store without a
                       \* conditional DELETE, so the tombstone settles,
                       \* the baseline keeps the path, the citation repair
                       \* re-cites it, and the two writers flap forever.
  OrphanEntryCited,    \* Review 2026-09-18, H1b (found by the model once
                       \* Inv_NoDeleteResurrected reached the OrphanTracked
                       \* world).  TRUE = the fix: the untracked sweep's
                       \* entry carries the citation it judged the object
                       \* against (`gh.orphanAt[p]`, real state the code
                       \* keeps in `InboxEntry.cited`), and a consume
                       \* honours it only while the manifest still cites
                       \* exactly that at the path.  FALSE = what shipped:
                       \* the entry outlives the commit that cites its
                       \* object — the window clear removes only what a
                       \* barrier CONSUMED — and after the uploader's own
                       \* delete of the path (and a crash before its GC
                       \* and clear, or a peer's consume that straddles
                       \* the delete) the other writer adopts a generation
                       \* the manifest cited and then dropped, and its
                       \* citation repair re-cites it on every tree.
                       \* Inert without OrphanTrack.  The rule applies
                       \* twice: at the consume (an outlived entry is
                       \* dropped) and at the repair (an adoption made
                       \* while the entry was still pending is VOID once
                       \* the citation moves — `sc[s].judged`, the code's
                       \* `BaselineEntry.judged`), and a voided path the
                       \* manifest no longer cites is queued as a
                       \* tombstone.
  LeakSupersedesNothing, \* Review 2026-09-18, H1b's convergence half.
                       \* TRUE = the fix: an object at the key supersedes
                       \* a queued deletion only if something will
                       \* integrate it — the manifest cites it, or an
                       \* entry this consume honoured names it.  FALSE =
                       \* what shipped: ANY different object superseded,
                       \* so a leaked generation this tree never
                       \* integrated (a delete whose GC never ran; the
                       \* tombstone names the older one this tree had)
                       \* kept a clean stale copy in the tree forever,
                       \* uncited — Inv_TreesConverged sees it.
  ManifestTombstones,  \* Review 2026-09-18, H1e (the collector-off world
                       \* with every arm above on): a writer adopts a UI
                       \* write while it is still PENDING, another writer
                       \* cites it and later deletes it KNOWINGLY, and the
                       \* adopter's repair re-cites it — nothing in the
                       \* bucket tells the adopter that the generation it
                       \* holds was published and then removed; a delete
                       \* that raced the write (its author never saw it)
                       \* leaves the same manifest, and there modify
                       \* rightly wins.  The same tombstone answers H1c
                       \* (the adopter itself cited the write and
                       \* restarted between its CAS and step 7, so its
                       \* merge base lagged the document it installed)
                       \* and H1d (the citer restarted before its window
                       \* clear, so the entry outlived the citation and
                       \* another writer adopted it as pending): a
                       \* base-at-CAS arm and a consume-time "pull" arm,
                       \* written for those two, were each dropped as
                       \* redundant once this one was in — their
                       \* known-bad worlds would not go red.  TRUE = the
                       \* fix: a published
                       \* delete names the generation it retired, in the
                       \* manifest (`gh.tomb[p]`, real bucket state; the
                       \* document's `tombstones`), until the path is
                       \* cited again; a repair whose generation the
                       \* tombstone names is void.  FALSE = what shipped.
  SupersedeRestoresBase, \* Review 2026-09-18, H1f (the four-barrier orphan
                       \* world, every arm above on): a queued deletion
                       \* is SUPERSEDED — the manifest re-cited the path
                       \* with a newer generation — and settled; the pull
                       \* it defers to is the next install's diff from the
                       \* merge base.  But the base moved past the path
                       \* when the deletion was queued, and when the path
                       \* is deleted AGAIN before that install, the diff
                       \* has nothing at it: the clean copy of the retired
                       \* generation stays in the tree forever, uncited,
                       \* and (baseline # base) a repair candidate at
                       \* every barrier — Inv_TreesConverged sees it.
                       \* TRUE = the fix: superseding a deletion restores
                       \* the merge base to the generation it retired
                       \* (`fqRetired`, the code's `ForeignChange.retired`),
                       \* so the next install queues the deletion again,
                       \* or the upsert if the re-cite still stands.
                       \* FALSE = what shipped.
  AckFromCarrier,      \* Review 2026-09-18, H10 (the crash world at
                       \* OrphanTrack = TRUE, depth 25): the barrier that
                       \* CARRIED a declaration is not always the one whose
                       \* report the ack reads.  A restart after step 7
                       \* and before the ack loses the in-memory honor;
                       \* the re-run finds the manifest moved by a peer's
                       \* delete of the declared path and answers with a
                       \* PULL-ONLY — `ok`, naming the peer's document,
                       \* while the tree still holds the declared bytes.
                       \* (The code has two more routes to the same ack:
                       \* the ack write failing after the install, and the
                       \* floor's cadence barrier publishing a declaration
                       \* whose honor had just failed.)  TRUE = the fix:
                       \* every install whose barrier began after the
                       \* consume journals, with its CAS (the code's
                       \* `IntentJournal::carrier`), the declared paths it
                       \* published and the ones it dropped; a restart
                       \* keeps them; and the ack — still naming the
                       \* writer's latest document — reports as dropped a
                       \* carried path whose deletion by another writer
                       \* waits in this writer's queue.  (A first cut named
                       \* the FIRST carrying install instead; its world
                       \* went red on Inv_AckBoundaryCoherent in 18 steps:
                       \* a restart between the CAS and step 7 made the
                       \* re-run publish the agent's later write, and the
                       \* ack then named a document older than the tree.)
                       \* FALSE = what shipped.
  FenceAfterLoad,      \* Review 2026-09-18, H2 (the fence's position):
                       \* TRUE = the commit's fence is observed AFTER the
                       \* manifest load it merges onto — the cell read
                       \* between that load and the CAS, whose expected
                       \* etag a successor's rotation moves — which is
                       \* this module's atomic `~Fenced(s)` on the CAS.
                       \* FALSE = what shipped: ONE read of the cell at the
                       \* start of the commit section (`VerifyCell`), then
                       \* the HEAD fan-out and the window, then the load and
                       \* the CAS with no fence at all.  A holder deposed in
                       \* between loads its successor's ROTATED document
                       \* and its CAS lands on it.
  OutrankedRemovalLeavesBaseline, \* L-125: TRUE = the code since 2026-09-24
  RemovalNamesGen,     \* Review 2026-09-18, H4: TRUE = a declared removal
                       \* carries the generation it was judged against (the
                       \* code's `Removal::etag`, in the cell; here
                       \* `gh.remJudged`, kept in the view as the real state
                       \* it stands for, and recorded in both arms so the
                       \* shipped one can be judged) and removes only that
                       \* generation:
                       \* a newer one refuses it, one still in the inbox
                       \* defers it.  FALSE = what shipped: any CLEAN
                       \* version is removed — a UI re-upload after the
                       \* delete, or an agent write another barrier
                       \* published in between, was deleted.  The
                       \* amputation stamp cannot see it (the installer
                       \* had consumed the write, which reads as ordinary
                       \* editing), hence `Inv_RemovalNamesItsVersion`.
  \* ---- immutable object handles (design 2026-09-19, the fix for H6) ----
  \* `docs/plans/flint-lean-immutable-objects-design.md`.  Every write lands
  \* at a HANDLE nobody else writes; the manifest cites handles; a handle a
  \* landed document cites is never overwritten and is deleted only once no
  \* document cites it.  `objects` (the one slot per path that every 412,
  \* adopt, park, HEAD-guarded GC and S3-wins arm arbitrates) is FROZEN, and
  \* `versions[p]` — the substrate the gated tranche left behind — is the
  \* set of live handles at p.  The shipped Upload/HitlWrite/HitlRename/GC
  \* are replaced by UploadIO/HitlWriteIO/HitlRenameIO/GCCollect, and an
  \* orphan sweep (SweepOrphan) collects what nothing cites or tracks.
  ImmutableObjects,    \* FALSE in every pre-existing cfg: the IO actions are
                       \* disabled, `versions` stays frozen at Init and the
                       \* new sc fields at their Init values, so every earlier
                       \* state space is preserved by construction.
  RetirePerPath,       \* FALSE = the design: an install retires a handle
                       \* only if no path of the installed document cites it
                       \* and no inbox entry names it.  TRUE = the mutation:
                       \* retirement is judged path by path, so a RENAME —
                       \* which cites the source's handle at the destination
                       \* — has its handle collected under the destination's
                       \* citation (Inv_NoDangling).
  SweepSparesTracked,  \* TRUE = the design: the sweep never takes a handle an
                       \* inbox entry names.  FALSE = the mutation: an acked
                       \* UI write's handle is collected before any barrier
                       \* consumes it (Inv_HITLDurable).
  SweepUnderLease,     \* TRUE = the design: the orphan sweep runs inside a
                       \* barrier's commit section, under the cell, so the
                       \* commit's re-verification of its own uploads
                       \* (VerifyUploads) and its CAS are race-free against
                       \* it.  FALSE = the mutation: a lease-free sweep lands
                       \* between a writer's verify and its CAS, and the
                       \* installed document cites a collected handle
                       \* (Inv_NoDangling).
  CommitSurfacesForeign, \* TRUE = the design (rule 5): a commit whose
                       \* upload's path was published past what it
                       \* integrated surfaces the published version and cites
                       \* its upload over it knowingly — the slot's 412 arm,
                       \* taken at the CAS.  FALSE = the mutation, the shape
                       \* the first HitlOverAny run had: cited over blind
                       \* (Inv_HITLDurable for an acked write,
                       \* Inv_NoStaleOverride for a peer's).
  RenameMovesEntry,    \* TRUE = the design: a rename takes the source's
                       \* PENDING entry with the citation it moves (the
                       \* entry is that citation), and the removal names
                       \* the version the entry was written over.  FALSE =
                       \* the mutation: the entry stays at the source, and
                       \* a writer consuming after the move adopts the
                       \* handle at both names (the core model's first run).
  AnsweredRecordsApply,\* TRUE = the design: a removal one writer REFUSED
                       \* still moves the named version out of another tree
                       \* that holds it clean at the source — a refusal is
                       \* one tree's answer, not the document's.  FALSE =
                       \* the mutation, the rule as shipped: every writer
                       \* skipped an answered record, and a tree that had
                       \* adopted the source's write before the rename kept
                       \* it at the old name beside the destination's
                       \* (Inv_OneName; L-117's shape is its one-barrier
                       \* lag, closed by the same rule).
  RepairYieldsToLaterUI,\* TRUE = the design: a citation repair yields to a
                       \* LATER acked UI write the document already cites at
                       \* the path (the UI's own hand; the tree takes it
                       \* through its queue).  FALSE = the mutation, the rule
                       \* as shipped (the rename world's eighth box run,
                       \* Inv_HITLDurable at depth 18): the repair re-cited
                       \* an older adoption over the user's newer write,
                       \* published by a peer, with no record.
  RepairRespectsMoves, \* TRUE = the design (R2): a citation repair never
                       \* re-cites a handle the document cites at another
                       \* path this install keeps (MovedElsewhere).  FALSE =
                       \* the mutation, the rename world's fourth box run: an
                       \* adopter that never saw the removal re-cites the
                       \* moved handle at its old name (Inv_OneName).
  QueueYieldsToSync,   \* 2026-09-23: TRUE = a sync prunes the writer-local queue
                       \* where it moved a path's merge base to a version other
                       \* than the queued one (`sync.rs` step 6, the L-123 fix).
                       \* FALSE = the shape before it: sync never read the queue.
  PendingAdoptionStays \* TRUE = the design: an adoption declined for the
                       \* MOVE ALONE, at the destination of a rename whose
                       \* record still waits at its source, keeps its entry
                       \* in the cell — the collector spares what an entry
                       \* names, and the next barrier of any writer cites it
                       \* once the source has left.  FALSE = the mutation,
                       \* the rule as shipped (the rename world's tenth box
                       \* run, L-119): the entry left the cell with the rest
                       \* of the consumed, nothing but the source's citation
                       \* named the handle, the peer applying the answered
                       \* record removed that, and the collector took it —
                       \* the rename lost with no record (Inv_HITLDurable).

\* A cfg cannot write a sequence literal; it substitutes one of these
\* (`Writers <- TwoWriters`).
TwoWriters   == <<"A", "B">>
ThreeWriters == <<"A", "B", "C">>
\* Trace validation only (W4 phase 2): a storm leg runs six writers, and a
\* replay is driven step by step, so the state space is the trace's length
\* rather than the world's.  No GATE run uses these.
FourWriters  == <<"A", "B", "C", "D">>
FiveWriters  == <<"A", "B", "C", "D", "E">>
SixWriters   == <<"A", "B", "C", "D", "E", "F">>
Syncers == {Writers[i] : i \in DOMAIN Writers}
\* The first writer, the one the stall and the life lease name.
ASSUME Len(Writers) >= 2 /\ Writers[1] = "A" /\ Writers[2] = "B"
Sources == {"none", "cadence", "sentinel"}

VARIABLES
  \* ---- bucket -----------------------------------------------------------
  cellEpoch,   \* subtree lease cell: current epoch (0 = never claimed)
  cellHolder,  \* "A" | "B" | "none"
  cellQueue,   \* tranche 6: the FIFO ticket — a sequence of waiters
  cellHandoff, \* tranche 6: "none" | the syncer a release named
  cellReleased,\* tranche 6: TRUE between a release and the next claim.
               \* HELD = cellEpoch > 0 /\ ~cellReleased; FRESH = epoch 0.
  manSeq,      \* manifest document seq (the CAS token)
  manSrc,      \* the boundary-source stamp on the INSTALLED manifest —
               \* the fleet-visible answer to "which clock installed
               \* this?".  Real bucket state (object metadata), not a
               \* ghost: an operator reads it without the agent's ack.
  manifest,    \* [Paths -> Nat]: cited generation per path (0 = uncited)
  objects,     \* [Paths -> Nat]: current object generation (0 = absent)
  inbox,       \* SUBSET (Paths \X Nat): pending HITL entries
  removals,    \* SUBSET Paths: DECLARED removals pending in the cell
               \* (delete/rename design §3) — recorded from outside the
               \* pod, performed by the syncer at its next consume.
  window,      \* 0 = closed; else the opener's epoch
  \* ---- syncers ---------------------------------------------------------
  sc,          \* [Syncers -> record], fields below
  \* ---- the versioned substrate (tranche 3 product 2) --------------------
  versions,    \* [Paths -> SUBSET Nat]: every generation still STORED for
               \* the path.  `objects[p]` is which one it currently reads
               \* as; a PUT over a versioned bucket destroys nothing, so
               \* the two diverge exactly while work is staged-uncited.
  stage,       \* [Syncers -> [Paths -> Nat]]: the gated pending set —
               \* staged-but-uncited generation per path (0 = none).
  stageBase,   \* [Syncers -> [Paths -> Nat]]: the generation the BASELINE
               \* cited when we staged.  D7's re-validation guard: if the
               \* baseline has moved by citation time, a HITL consume or a
               \* sync landed after we staged, and installing our staged
               \* generation would let work that PREDATES the foreign
               \* bytes win against them.
  withheldDel, \* [Syncers -> SUBSET Paths]: deletes withheld from the
               \* manifest until a citation, so a rename never becomes
               \* reader-visible as gone/absent at an undeclared point.
  \* ---- environment / ghosts --------------------------------------------
  hitlAcked,   \* SUBSET (Paths \X Nat): writes acked to the user
  conflicts,   \* SUBSET (Paths \X Nat): surfaced conflict records
  gh           \* ghost/counter record, fields below

gatedVars == <<stage, stageBase, withheldDel>>
leaseVars == <<cellQueue, cellHandoff, cellReleased>>

vars == <<cellEpoch, cellHolder, cellQueue, cellHandoff, cellReleased,
          manSeq, manSrc, manifest, objects, inbox, removals, window,
          sc, versions, stage, stageBase, withheldDel, hitlAcked,
          conflicts, gh>>

(* sc[s] fields:
     st       "unstarted" | "claiming" | "running" | "stalled" | "dead"
     pc       "idle" | "consumed" | "scanned" | "delDone" | "cased"
              | "waiting" | "claimed"   (tranche 6: the barrier lease —
              uploads done and queued for the cell; cell claimed, the
              commit section from here to Finish)
     epoch    the epoch this incarnation believes it holds (tranche 6:
              the LAST epoch it held; 0 before its first claim)
     expSeq   the manifest seq it will If-Match
     local    [Paths -> Nat]  the live tree (0 = absent)
     baseline [Paths -> Nat]  the persisted baseline snapshot
     known    SUBSET Nat      generations this incarnation recognizes:
                              checkout + own mints + surfaced consumes.
                              Blind adoption (the LOCAL-WINS mutation) does
                              NOT extend it — that is what makes silent
                              destruction attributable.
     instBase [Paths -> Nat]  the manifest view at this incarnation's last
                              install (or checkout): the MERGE BASE.  It is
                              deliberately distinct from baseline — consume
                              advances baseline (the object-ETag guard) but
                              not instBase, so a consumed adoption is not
                              mistaken for a foreign manifest entry.
     instSnap [Paths -> Nat]  the document THIS barrier installed, snapshot
                              at CASInstall.  Finish MUST advance from this
                              snapshot, never from the live manifest — a
                              HITL bump landing between install and finish
                              would otherwise be absorbed into the merge
                              base and clobbered next barrier (the
                              implementation threads `installed` through
                              for exactly this reason).
     instSeq  Nat             the seq THIS barrier installed.
     instSrc  Sources         tranche 6: the clock stamped on THIS
                              barrier's install (BarrierLease only).  With
                              two writers the live manifest's stamp is
                              whoever installed LAST, which is not what
                              this workspace's ack names.
     scanU    SUBSET Paths    upload set frozen at scan
     scanD    SUBSET Paths    delete-eligible set frozen at scan
     scanGen  [Paths -> Nat]  local generations frozen at scan (re-stat guard:
                              the barrier publishes walk-time content; post-
                              scan agent edits are next barrier's dirt)
     upDone   SUBSET Paths    uploaded (or adopted-own) this barrier
     adopted  SUBSET Paths    tranche 6: the subset of upDone that was
                              ADOPTED — cited without a PUT — and so is
                              re-verified under the lease (BarrierLease
                              only; {} otherwise)
     touched  SUBSET Paths    paths the agent REWROTE with the bytes their
                              baseline already cites (`AgentWriteSame`): the
                              walk sees a new stat, so the path is dirty,
                              while the generation — the etag — is the
                              baseline's.  Leaves at Finish once an upload
                              of it is cited; a withheld one stays dirty.
                              {} unless MaxSameBytes > 0
     surfaced SUBSET Paths   the code's consume-dirty SENTINEL (`size ==
                            u64::MAX` on the baseline entry): the baseline
                            names a version this tree SURFACED — the local
                            edit publishes over it knowingly — not one it
                            holds, so the path is never a citation repair
                            (and never a repair's "moves off" either); it
                            clears when the baseline entry is rewritten (an
                            upload, a landed delete, an adoption).  Without
                            it the first run of the core model (LeanCore)
                            re-cited a refused rename's moved handle at the
                            source after the agent deleted its edit there.
     repairMoved SUBSET Paths the last install's DECLINED citation repairs:
                              paths this writer integrated whose key held a
                              newer generation at the CAS (BarrierLease
                              only; {} otherwise) — see BoundaryIncoherent
     fq       SUBSET (Paths \X Gens)  tranche 7, WriterQueue only: the
                              writer-LOCAL foreign queue — <<p, g>> is a
                              change another writer made that this writer's
                              merge carried into the manifest but not yet
                              into the tree; g = 0 is a DELETION.  At most
                              one entry per path.  {} otherwise
     noInst   BOOLEAN         tranche 7, EmptyInstall only: this barrier's
                              commit found the merge equal to theirs and
                              installed nothing (CASInstall to Finish)
     parked   SUBSET Paths    412-parked this barrier
     gcDone   SUBSET Paths    delete-set entries processed this barrier
     gcHeaded SUBSET Paths    tranche 6, ~ConditionalGC only: delete-set
                              entries whose HEAD has been read this barrier
     gcSeen   [Paths -> Nat]  ...and the generation that HEAD saw — what
                              the unconditional DELETE is guarded on,
                              which is not what it deletes
     citeDone SUBSET Paths    which staged paths THIS citation has already
                              installed.  Non-empty and not the whole
                              valid pending set = a reader can see half a
                              logical change; the single-CAS design never
                              produces that state, which is exactly why
                              the split-install mutation stays.
     stageCarried BOOLEAN     this incarnation's pending set survived a
                              lane pass (set at Scan when the stage is
                              already non-empty).  Only under gated; FALSE
                              otherwise, so earlier state spaces are
                              preserved by construction.
     sentTok  Nat             the standing (unconsumed) sentinel file:
                              0 = none, else the touch id.  A second
                              touch OVERWRITES it — the agent's own
                              doing, and not an orphan: the protocol
                              owes an ack for CONSUMED nonces.
     pendN    SUBSET Nonces   the pending record's covered nonce set.
                              Non-empty IS the record's existence
                              (`PendLive`), and its maximum IS the
                              record's covered mtime, because every
                              touch in this model carries a nonce.
     pendDirty SUBSET Paths   the paths that were LOCALLY DIRTY at the
                              consume — the agent's own un-published
                              work, which is what the boundary owes it.
                              A path that was clean at consume time
                              carries no promise: its content came from
                              the remote, and the remote is entitled to
                              move it (an inbox adoption does exactly
                              that, and TLC produced one as a
                              counterexample before this field existed).
     pendMint Nat             the generation MINT WATERMARK at consume:
                              every generation >= this was created
                              after the declaration.  D1's guarantee is
                              at-LEAST ("the published state may include
                              later bytes for a racing file, never
                              earlier ones"), so the promise cannot be
                              stated as snapshot equality — see
                              `BoundaryBroken`.
     pendCov  [Paths -> Nat]  the tree AT CONSUME TIME — D1's at-least
                              guarantee is stated at exactly that
                              instant ("every write visible on disk at
                              consume time is in the published set"),
                              so this is what the ack promises.
     honored  BOOLEAN         a barrier COMPLETED strictly after the
                              latest consume.  Lost on restart (it is
                              in-memory barrier state), which is what
                              makes the uniform crash rule reachable.
     pendReRun BOOLEAN        this pending record survived a restart —
                              the ghost `ProbeAckAfterCrash` names.
     verifiedAt Nat           H2 (FenceAfterLoad = FALSE only): the epoch of
                              the commit section whose one cell read
                              (`VerifyCell`) found it still held.  A claim
                              mints a new epoch, so a stamp from an earlier
                              section never matches.
     carryPaths SUBSET Paths  H10 (AckFromCarrier only): the dirty paths
                              the installs whose barriers began after the
                              latest consume published, journalled with
                              each CAS.  Survives a restart (the intent
                              journal); cleared by the next consume, the
                              ack, the retire and a pod replacement.
     carryDropped SUBSET Paths the declared deletes those installs'
                              merges outranked (their `citeDropped`): a
                              `partial` survives the restart too.
     retire   [Paths -> Nat]  ImmutableObjects only: per path, the handle
                              the document THIS barrier installed stopped
                              citing (0 = none) — computed at the CAS from
                              the document it merged onto, exactly as the
                              code's step 6 would read `current` — and
                              collected by GCCollect.  All 0 otherwise.
     upGone   SUBSET Paths    ImmutableObjects only: the uploads this
                              commit's VerifyUploads found collected (the
                              sweep took them); the CAS withholds them.
     upVerified BOOLEAN       ImmutableObjects only: VerifyUploads has run
                              in this commit section.
     owed     SUBSET Nonces   every nonce this incarnation has CONSUMED.
                              Never shrinks while the pod lives; dies
                              with the pod, because a pod replacement
                              takes the agent and the tree with it.
     ackN     SUBSET Nonces   `.flint/<verb>.ack`'s covered nonce set.
                              Status is deliberately absent: the shipped
                              `ack_matches` does not read it.
     lastDirty SUBSET Paths   the dirt set frozen at the LAST barrier's
                              scan.  Tracked only under SyncEnabled (it
                              stays {} otherwise, so every tranche-1
                              state space is preserved by construction).
                              This is what the refuted sync reads.
   gh fields:
     amputated  BOOLEAN  an acked HITL write silently lost (either stamp site)
     stragglerInstalls, stragglerCas, deposedPuts : Nat
     barriers, done, gc, gcCited, refusals, cited, takeovers, crashes, restarts : Nat
     adoptOwn : Nat      the own-crashed-PUT 412 adoption fired
     stallUsed BOOLEAN
     nextGen, hitl : Nat
     scopedDeferrals : Nat  paths a SCOPED sync saw changed remotely and
                            deliberately left for the inbox flow (the
                            action-written non-vacuity ghost: the probe
                            names the ACTION, never the situation)
     deferredPaths : SUBSET Paths  which ones, still outstanding
     deferredLater : Nat    U16: a deferred out-of-scope path that a LATER
                            consume actually integrated.  `scopedDeferrals`
                            proves the deferral happened; D4's whole
                            loss-avoidance argument is that the entry
                            ARRIVES, and `Inv_NoForeignLost` is a stamp
                            written inside `Sync`, not an eventual-
                            integration property.  Without this the
                            deferral could be a synonym for the loss.
     staged, cites, reaped, withheld, forcedCites, citeSpan : Nat
     carriedCite BOOLEAN    a citation installed a pending set that had
                            survived a lane pass: the durability/visibility
                            split actually ACCUMULATED, rather than every
                            citation happening to follow its own lane
     touches, acks, honors, refusedAcks, coalesced, fastPaths,
     ackAfterRestart : Nat
     fastHonor  BOOLEAN     a pending sentinel was honored by a
                            SKIP-ON-NO-DIFF pass rather than a full
                            barrier — without this the FastPathGuards
                            runs could hold vacuously
     ackEarly   BOOLEAN     an ok ack was written while the agent's own
                            declared work was neither cited, superseded
                            by later bytes, nor surfaced
     ackIncoherent BOOLEAN  an ok ack named a manifest that did not cite
                            everything this workspace had integrated
     fencedOkAck BOOLEAN    an ok ack was written by an incarnation the
                            cell had already deposed
     srcMismatch BOOLEAN    an ok ack named one clock while the manifest
                            it acked carried another.  The ack is a LOCAL
                            file and the manifest is what the FLEET reads,
                            so this is the bucket disagreeing with the
                            agent about the same boundary
     foreignLost BOOLEAN    a sync advanced the merge base for a path it
                            neither applied nor surfaced a conflict for —
                            i.e. it claimed to have integrated a generation
                            it never saw.  That is exactly the silent,
                            permanent loss D4 exists to prevent: the next
                            merge computes `changed = FALSE` for it and it
                            is never queued again.
     ---- tranche 6: the barrier lease (each written by ONE action) ----
     claimed  SUBSET Syncers  who has claimed the cell at least once (Claim)
     interleaved BOOLEAN  an upload LANDED while another syncer held the
                            cell in its commit section (Upload) — the
                            required-reachable probe: two writers really
                            do overlap uploads with a commit
     handoffs 0|1          a claim by the syncer the release NAMED (Claim)
     deposals Nat          a quiet holder was deposed mid-commit (Claim)
     deadSkips 0|1         a quiet handoff was skipped (SkipDeadHandoff)
     enqueues 0|1          a syncer queued for the cell (Enqueue)
     abandoned 0|1         a fenced holder abandoned its barrier and kept
                            running (the fence arms, under BarrierLease)
     adoptWithheld 0|1     a CAS withheld an adopted entry whose object
                            was gone (CASInstall, under the fix)
     sameBytes Nat         `AgentWriteSame`'s budget counter
     uploadWithheld 0|1    a CAS withheld an entry its own LANDED upload
                            added, because the object was gone or moved
                            (CASInstall, under VerifyUploadedCitations)
     staleOverride BOOLEAN a CAS cited its own upload's generation over a
                            citation the key STILL HOLDS, while the key no
                            longer held the upload (CASInstall, BarrierLease
                            only) — see Inv_NoStaleOverride
     hitlRetired SUBSET (Paths \X Nat)  acked UI writes whose object was
                            deleted or overwritten by a party entitled to:
                            a writer that integrated it, or the UI's own
                            later write (GCDelete, Upload, HitlWrite; only
                            under MaxSameBytes > 0) — see Inv_HITLTracked
     ---- tranche 7 (each written by ONE action, read only by its probe) ----
     pullOnlys 0|1        a PULL-ONLY boundary ran (PullOnly)
     emptyInstalls 0|1    a commit installed nothing (CASInstall)
     tombRemoved 0|1      a queued deletion removed a clean copy (Consume)
     tombSuperseded 0|1   a queued deletion was superseded by an object
                            at the key — the fix firing (Consume)
     ---- immutable object handles ----
     swept    Nat         the orphan sweep collected a handle (SweepOrphan;
                            read only by its probe)
     answered SUBSET Paths  the paths with an ANSWERED (refused) removal
                            record standing in the cell — real cell state
                            (`Removal.refused`), superseded by a fresh
                            request for the path
     remOver  [Paths -> Gens] for a rename of a pending entry: the version
                            that entry was written over (`Removal.over`);
                            a tree holding it holds a version the request
                            covers.  0 = none
     uiBase   SUBSET (Paths \X Gens \X Gens)  ImmutableObjects only: for
                            each entry the gateway appended, <<p, g, b>> —
                            the version the UI READ when it wrote g at p
                            (the code's `InboxEntry.cited`, real cell
                            state).  A consume adopts g only while that is
                            still the truth at p: a citation that moved to
                            a later UI write supersedes it, one that moved
                            to a writer's publish makes it a conflict.  A
                            rename's destination entry has base 0. *)

------------------------------------------------------------------------------
(* Helpers *)

Gens == 0..MaxGen

Nonces      == 1..MaxTouches
PendLive(s) == sc[s].pendN # {}
NoPend      == [p \in Paths |-> 0]
\* `ack_matches`: every pending nonce named by the standing ack.  The
\* implementation ALSO requires the ack's covered mtime not to be older
\* than the pending's; here every touch carries a nonce and touch ids
\* are monotone, so the subset test implies it (ledger entry).
AckMatches(s) == sc[s].pendN \subseteq sc[s].ackN

(* WHICH CLOCK a boundary belongs to.  One function, read by BOTH sides:
   the installer stamps it on the manifest and the ack names it to the
   agent.  That is the whole point — the shipped code computed the two
   independently, so a drain could rewrite its ack to `drain` while the
   manifest it installed still said `sentinel`, and the BUCKET (which is
   what an operator reads, and the ack is not) held the wrong one.       *)
\* Read the SAME test the install reads. `honored` is set BY the install,
\* so at stamp time it is still FALSE — asking it there would stamp every
\* sentinel honor "cadence" and the invariant would fire on correct code
\* (the first pilot did exactly that). A live pending record is what makes
\* a boundary a sentinel honor, and it outlives the ack: `AckOk` requires
\* it, and `RetirePending` runs only afterwards.
BoundaryClock(s) == IF SentinelEnabled /\ PendLive(s) THEN "sentinel" ELSE "cadence"

(* What the install actually writes.  The mutation is not "stamps the
   wrong thing" but the subtler shape that shipped: the install goes
   through an UNSTAMPED CAS, so every boundary reads as the default
   clock however it was driven.                                          *)
InstallSource(s) == IF StampBoundarySource THEN BoundaryClock(s) ELSE "cadence"

(* Tranche 6: WHICH DOCUMENT an ack is judged against.  An ok ack names
   a seq (`remote.seq`) — the document this workspace installed, or, on
   the fast path, the one it found unmoved since its last install or
   checkout (`manSeq = expSeq`, and `instSnap` tracks both).  With one
   writer that document IS the live manifest at ack time: nothing else
   could move it between the honor and the ack.  With two, the other
   writer's commit can land in between — TLC's first sentinel run under
   the barrier lease was exactly that, a fast-path honor followed by the
   other writer's delete followed by the ack — and a later install that
   merges from theirs and preserves this workspace's entries is the
   two-writer rule working, not an incoherent ack.  The live manifest
   stays the subject of every durability invariant.                    *)
AckedDoc(s) == IF BarrierLease THEN sc[s].instSnap ELSE manifest
AckedSrc(s) == IF BarrierLease THEN sc[s].instSrc ELSE manSrc


(* ---- tranche 7: the merge's per-path judgements, hoisted out of
   CASInstall so the PULL-ONLY boundary — which merges and installs
   nothing — reads the same rules.  CASInstall's bodies are unchanged;
   see the comments there for why each reads as it does.                *)
(* The MERGE BASE this commit merges onto, which is not always the
   persisted one.  Step 7 rewrites `instBase` AFTER the CAS and the
   collector, so a restart in that window leaves it a generation behind a
   document THIS workspace installed — and then every entry in that
   document reads as somebody else's change: the writer's own publish is
   foreign, its agent's delete is outranked by it (delete/modify resolves
   conservative), and the ack still says ok.  The code recovers exactly
   here, at the merge, from the one record that survives that window:
   `IntentJournal::installed_etag`, written immediately after the CAS
   returns and before the deletes (`barrier.rs`: "If the bucket is still
   at the document THIS workspace installed, that document IS the merge
   base — whatever the persisted one says").  The test is the pointer's,
   not the path's: the seq this writer installed is still the seq the
   pointer carries.  `MineIsNotForeign = FALSE` is the shape without
   it, and `LeanSentinelStaleMergeBase` is the world that refutes it —
   the route above, `Inv_AckImpliesCited` at depth 18.

   It was invisible until 2026-09-21 because the flat `known` hid it: a
   writer recognised its own publish by GENERATION, anywhere, so a stale
   merge base cost nothing.  Asking per path, as the code does, took that
   cover away.                                                          *)
MergeBase(s) ==
  IF MineIsNotForeign /\ sc[s].jSeq # 0 /\ sc[s].jSeq = manSeq
  THEN manifest ELSE sc[s].instBase
\* 2026-09-21: `MineIsNotForeign`'s exemption asks PER PATH, because that
\* is what the code asks.  `manifest.rs::merge` has no exemption at all —
\* changed against the merge base is theirs, full stop — and the one the
\* commit applies lives in its R7 surfacing loop (`barrier.rs`): does my
\* baseline hold THAT handle AT THIS PATH, right now?  It used to read
\* `manifest[p] \notin sc[s].known`, one flat set per writer, which let a
\* peer that held the seed at a rename's SOURCE publish over the renamed
\* destination and surface nothing (`LeanCoreForeignFlat`, depth 20).
\* `sc[s].known` keeps its other jobs — the 412 resume, the GC guard, the
\* adopt — where "this incarnation minted or saw this generation" is the
\* right question and it is not about a path.
ForeignEntry(s, p) ==
  /\ MergeCapable
  /\ manifest[p] # MergeBase(s)[p]
\* H1b: an adoption made from the untracked sweep's entry is provisional —
\* `judged[p]` is the citation the sweep judged the object against, and the
\* repair cites the adoption only while the manifest still cites exactly
\* that.  A citation that moved on voids it (`void_stale_repairs`).
JudgedStands(s, p) == sc[s].judged[p] = 0 \/ manifest[p] = sc[s].judged[p]
\* H1e: the manifest's tombstone names the generation this writer holds —
\* it was published and then removed, knowingly.
Entombed(s, p) == ManifestTombstones /\ manifest[p] = 0 /\ gh.tomb[p] = sc[s].baseline[p]
\* Immutable handles: the ONE question every same-key read used to ask —
\* "does the key still hold the generation I integrated / the entry names?"
\* — becomes "does that handle still exist at the path?".  Under the shipped
\* arm the two are the same test written the old way.
HoldsGen(p, g) == IF ImmutableObjects THEN g \in versions[p] ELSE objects[p] = g
\* A generation number stands for a handle NAME.  Every mint is unique, so
\* two paths hold the same handle only through a rename — a citation move,
\* which keeps the generation (`renamed` records <<p, q, g, g>>).  The seed
\* generation is one NUMBER at every path but a different handle at each
\* (`files/p2@1` is not `files/p1@1`), so retiring or sweeping it at one
\* path never touches another.  The first RetirePerPath run said otherwise
\* at depth 9 with no rename in its trace: the collector was reading the
\* model's numbers as names.
Aliased(p, q, g) == p # q /\ \E r \in gh.renamed : r[3] = g /\ r[4] = g /\ {r[1], r[2]} = {p, q}
SameHandle(p, q, g) == p = q \/ Aliased(p, q, g)
\* The newest tracked version at p, or the citation: what the read door
\* serves (`TrackedGen` reads the same), and, under handles, what the
\* rename and the sync verb read where the shipped model read the slot.
TrackedOrCited(p) ==
  IF \E pr \in inbox : pr[1] = p /\ HoldsGen(p, pr[2])
  THEN CHOOSE g \in {pr[2] : pr \in {x \in inbox : x[1] = p /\ HoldsGen(p, x[2])}} :
         \A h \in {pr[2] : pr \in {x \in inbox : x[1] = p /\ HoldsGen(p, x[2])}} : h <= g
  ELSE manifest[p]
\* Handles: the handle this tree would re-cite at p is cited by the document
\* at ANOTHER path — a rename moved it there (a citation move is the only
\* way one handle reaches two names), and p was its source.  Not p's to
\* re-cite.  The slot expressed this by being collected at the source; a
\* handle kept for the destination is still there to be found (the third
\* box run of the rename world: an adopted UI write, renamed by the UI and
\* performed by a peer, was re-cited at its old name by the adopter's
\* repair, and Inv_RenameAtomic saw one handle under both names).
\* ...unless THIS install moves that other path off the handle: it deletes
\* q (this writer performs the rename, p is its destination, and the source
\* leaves in the same generation — `LeanImmutableProbeRename` and
\* Inv_RenameNoHole are what the rule without this clause broke), uploads
\* another generation at q, or repairs q to another generation (the UI
\* wrote the source again after the move, H4's kept-both-versions shape).
\* An upload the re-read WITHHELD (`upGone`) moves nothing: the merge drops
\* it and q keeps the citation it had.  Reading the scan's set instead said
\* a rename's source had moved off the handle when it had not, and the same
\* install cited the destination's repair beside it — one handle under two
\* names (found in the core model's two-path world, `Inv_OneName` at depth
\* 21, 2026-09-20; the code reads the same thing, a withheld upload leaving
\* `upserts` before `void_stale_repairs` walks it).
KeepsAt(s, q, g) ==
  \* A declared delete only removes the citation if the merge APPLIES it,
  \* and delete/modify resolves conservative: theirs wins where theirs
  \* moved off the merge base.  Reading `scanD` alone said "this install
  \* moves q off the handle" for a delete the install was about to
  \* OUTRANK, so the repair at the source went ahead and one handle was
  \* cited under two names (`LeanImmutableRenameHolds`, `Inv_OneName` at
  \* depth 18, found when the merge stopped exempting versions the tree
  \* had integrated and more deletes began to be outranked).  This
  \* mirrors `inst`, where `foreign(q)` is read BEFORE `q \in scanD`.
  /\ (q \notin sc[s].scanD \/ ForeignEntry(s, q))
  /\ ~(q \in sc[s].scanU \ sc[s].upGone /\ sc[s].scanGen[q] # g)
  \* ...and the THIRD conjunct had the same defect as the other two, which
  \* is why this rule kept being wrong one route at a time: it reads an
  \* OWED REPAIR at q as one that HAPPENS.  `RepairOwed` refuses a path the
  \* scan is already publishing or that is parked, so where q is in `scanU`
  \* or `parked` this install repairs q to NOTHING and q keeps the citation
  \* it had.  Reading the baselines alone said the source of a rename had
  \* moved off the handle when no mechanism moved it — the upload was
  \* WITHHELD (`upGone`) and the repair was blocked by that same upload —
  \* and the destination's repair was cited beside it: one handle under two
  \* names (`LeanImmutableRenameHolds`, `Inv_OneName` at depth 21,
  \* 2026-09-22, a COMPLETE depth-21 graph at 182,220,773 distinct).
  \* Gating on `RepairOwed` itself would not elaborate: it calls
  \* `MovedElsewhere`, which calls this.  These are its two non-recursive
  \* blockers, and neither loses a case — an upload at q that STANDS is
  \* conjunct 2's business, and nothing publishes at a parked path.
  /\ ~(/\ q \notin sc[s].surfaced
       /\ q \notin sc[s].scanU /\ q \notin sc[s].parked
       /\ sc[s].baseline[q] # sc[s].instBase[q] /\ sc[s].baseline[q] # g)
\* By NAME (SameHandle), as the collector and the sweep judge: the seed
\* generation at a third path is another handle, and the sixth box run of
\* the rename world found the rename's own destination declined for it
\* (Inv_RenameNoHole at depth 13).
\* The DESTINATION of a rename that was REFUSED meets this rule only while
\* the source is kept at the handle (L-117, the rename world's seventh box
\* run: the adopted copy declined while the agent's later delete of the
\* source waited under the two-scan guard) — one barrier at most, because
\* an answered record still moves the handle out of the tree once the
\* tree no longer holds an edit at the source (AnsweredRecordsApply).
\* Without the rule at all (RepairRespectsMoves=FALSE, the fourth run's
\* shape) the adopter re-cites the moved handle at its old name: Inv_OneName.
MovedElsewhere(s, p) ==
  /\ RepairRespectsMoves /\ ImmutableObjects
  /\ \E q \in Paths \ {p} : /\ manifest[q] = sc[s].baseline[p]
                            /\ SameHandle(p, q, sc[s].baseline[p])
                            /\ KeepsAt(s, q, sc[s].baseline[p])
\* Handles: the document cites a LATER acked UI write at p than the version
\* this tree adopted — the UI's own hand.  The repair yields; the queue
\* brings the newer version to the tree (the rename world's eighth box run:
\* a repair re-cited an older adoption over it, published by a peer, and
\* Inv_HITLDurable saw the user's newer write retired with no record).
SupersededByUI(s, p) ==
  /\ ImmutableObjects /\ RepairYieldsToLaterUI
  /\ manifest[p] # 0 /\ <<p, manifest[p]>> \in hitlAcked
  /\ manifest[p] > sc[s].baseline[p]
RepairOwed(s, p) ==
  /\ p \notin (sc[s].scanU \cup sc[s].scanD \cup sc[s].parked \cup sc[s].surfaced)
  /\ sc[s].baseline[p] # sc[s].instBase[p]
  /\ HoldsGen(p, sc[s].baseline[p])
  /\ JudgedStands(s, p)
  /\ ~Entombed(s, p)
  /\ ~MovedElsewhere(s, p)
  /\ ~SupersededByUI(s, p)
RepairDeclined(s, p) ==
  /\ p \notin (sc[s].scanU \cup sc[s].scanD \cup sc[s].parked \cup sc[s].surfaced)
  /\ sc[s].baseline[p] # sc[s].instBase[p]
  /\ (\/ ~HoldsGen(p, sc[s].baseline[p]) \/ ~JudgedStands(s, p) \/ Entombed(s, p)
      \/ MovedElsewhere(s, p) \/ SupersededByUI(s, p))
\* L-119, the rename world's TENTH box run.  A decline is not always a
\* verdict that the adoption is gone.  Where the ONLY reason is the move —
\* the handle is live, no tombstone names it, no later UI write took the
\* path, and the document cites it at the SOURCE of a rename whose record
\* is still in the cell — the citation is not lost but EARLY: the source
\* leaves as soon as a tree holding it clean applies the record, and this
\* path is where the handle is going.  So the adoption is PENDING: the
\* tree keeps its copy, the entry stays in the cell (the collector spares
\* what an entry names, and the sweep too), and the next barrier of ANY
\* writer cites it once the source has gone.  Without the rule the entry
\* left with the rest of the consumed, the source's citation was the only
\* thing naming the handle, the peer that applied the answered record
\* removed it, and the collector took the handle: the rename lost with no
\* record at either name (Inv_HITLDurable, depth 18).
\*
\* Judged at the DESTINATION's decline and nowhere else: a handle moved
\* AWAY from the adopted path — the document cites it at a path this
\* install keeps and no record is coming back for it — is gone as before,
\* which is what the move rule (R2) is for.
PendingAdoption(s, p) ==
  /\ PendingAdoptionStays /\ ImmutableObjects
  /\ RepairDeclined(s, p)
  \* declined for the MOVE ALONE: every other reason to decline is absent
  /\ HoldsGen(p, sc[s].baseline[p]) /\ JudgedStands(s, p)
  /\ ~Entombed(s, p) /\ ~SupersededByUI(s, p)
  \* ...at the destination of a rename still WAITING at its source: the
  \* citing path is that source, and its record has not been performed
  \* (`removals`), or was answered and still applies (`gh.answered` — the
  \* code's refused record, which stays in the cell for the human).
  /\ \E q \in Paths \ {p} :
       /\ manifest[q] = sc[s].baseline[p]
       /\ SameHandle(p, q, sc[s].baseline[p])
       /\ KeepsAt(s, q, sc[s].baseline[p])
       /\ q \in removals \cup gh.answered
       /\ \E r \in gh.renamed : r[1] = q /\ r[2] = p

\* What a merge queues for the TREE (`merge_onto`'s `foreign` and `gone`):
\* theirs moved off the merge base at a path this barrier neither uploaded,
\* re-cited nor parked — an upsert — or dropped a path the base had that
\* this barrier neither uploaded, deleted, re-cited nor parked — a deletion.
\* A citation repair is one of the merge's own upserts, so it is neither.
MineInMerge(s) == sc[s].parked \cup (sc[s].scanU \cap sc[s].upDone)
MergeForeign(s) ==
  {<<p, manifest[p]>> : p \in {q \in Paths :
     /\ q \notin MineInMerge(s)
     /\ ~RepairOwed(s, q)
     /\ ForeignEntry(s, q)
     /\ manifest[q] # 0}}
MergeGone(s) ==
  {<<p, 0>> : p \in {q \in Paths :
     /\ MergeCapable
     /\ q \notin MineInMerge(s) \cup sc[s].scanD
     /\ ~RepairOwed(s, q)
     /\ manifest[q] = 0
     /\ \/ MergeBase(s)[q] # 0
        \* H1b: a voided sweep adoption of a path the manifest no longer
        \* cites — the merge base never had it, so nothing else would
        \* queue the deletion that removes the clean copy.
        \/ ((sc[s].judged[q] # 0 \/ Entombed(s, q)) /\ sc[s].baseline[q] # 0)}}
GonePaths(s) == {pr[1] : pr \in MergeGone(s)}
\* What the peer's delete retired: the generation the merge base cited.
\* (Not the baseline's: a consumed UI write not yet re-cited is newer than
\* what a peer who never saw it deleted, and must survive that delete.)
\* For a voided adoption the base has nothing: the adopted generation.
Retired(s, p) == IF MergeBase(s)[p] # 0 THEN MergeBase(s)[p] ELSE sc[s].baseline[p]
\* `state::queue_foreign`: keyed by path, a later change replaces the
\* queued one.  Under the mutation nothing is queued at all.
QueueUpsert(q, new) ==
  IF QueueForeignChanges
  THEN {pr \in q : pr[1] \notin {x[1] : x \in new}} \cup new
  ELSE q
QueuedUpserts(s) == {pr \in sc[s].fq : pr[2] # 0}
QueuedDeletes(s) == {pr[1] : pr \in {x \in sc[s].fq : x[2] = 0}}
\* Review 2026-09-18, H10: the declared paths the acked document does not
\* carry.  Besides this barrier's own drops, under `AckFromCarrier`: what
\* an earlier carrying install dropped, and a carried path whose deletion
\* by another writer waits in this writer's queue — the tree still holds
\* the declared bytes, the acked document does not.
CarrierDropped(s) ==
  IF AckFromCarrier
  THEN sc[s].carryDropped \cup (sc[s].carryPaths \cap QueuedDeletes(s))
  ELSE {}
AckDropped(s) == sc[s].citeDropped \cup CarrierDropped(s)
\* The tombstone pass's rule for ONE queued deletion: does the object at the
\* key supersede it?  `tracked` = an entry the consume honours names that
\* object.  Under the fix (H1) the generation the delete retired does not; a
\* collector that gave way left it there, and the tombstone is about it.
\* Under LeakSupersedesNothing (H1b) a different object supersedes only if
\* something will integrate it — the manifest cites it, or an entry names
\* it; a leak supersedes nothing.  Shared by Consume, where it decides, and
\* Inv_TreesConverged, where a deletion it would supersede AGAIN is not
\* pending work (H1f).
ObjectSupersedes(s, p, tracked) ==
  IF ImmutableObjects
  THEN \* No slot to look at: what supersedes a queued deletion is a
       \* citation of the path again — a DIFFERENT handle than the one the
       \* delete retired — or an entry this consume honours.  A leaked or
       \* orphaned handle is invisible here by construction, which is the
       \* H1/H1b rules with nothing left for them to say.
       /\ TombstoneHeadsKey
       /\ \/ (manifest[p] # 0 /\ manifest[p] # sc[s].fqRetired[p])
          \/ tracked
  ELSE
       /\ TombstoneHeadsKey
       /\ objects[p] # 0
       /\ (~TombstoneNamesRetired \/ objects[p] # sc[s].fqRetired[p])
       /\ (\/ ~LeakSupersedesNothing
           \/ objects[p] = manifest[p]
           \/ tracked)
\* Review 2026-09-18, H1f: a queued deletion is pending work — the budget,
\* not the protocol, stopped it — only if the next consume would APPLY it,
\* or an entry names what supersedes it (that will be integrated or
\* dropped).  One the key's uncited, untracked object would supersede again
\* is the leak rule as shipped FLAPPING: superseded, base restored, queued
\* again at the next install, superseded...  The restore turned the stale
\* copy into a stale copy with a queue entry, and the exception as first
\* written excused it.
DeletionPending(s, p) ==
  /\ p \in QueuedDeletes(s)
  /\ LET tracked == \E e \in inbox : e[1] = p /\ HoldsGen(p, e[2])
     IN ~ObjectSupersedes(s, p, tracked) \/ tracked

Deposed(s)  == cellEpoch > sc[s].epoch
Running(s)  == sc[s].st = "running"

(* ---- tranche 6: the per-barrier lease --------------------------------
   The COMMIT SECTION runs from the claim to the release.  Only there does
   the cell's epoch mean anything to a syncer: before the claim it holds
   nothing, and `Deposed` merely compares against the last epoch it held.
   Under the life lease every post-claim step of the incarnation is in
   the commit section, which is what `DeposedHolder` collapses to.       *)
Holding(s)       == sc[s].pc \in {"claimed", "delDone", "cased"}
DeposedHolder(s) == Deposed(s) /\ (~BarrierLease \/ Holding(s))
Fenced(s)        == EpochCheck /\ DeposedHolder(s)
CellFresh        == cellEpoch = 0
CellHeld         == cellEpoch > 0 /\ ~cellReleased
Quiet(t)         == sc[t].st \in {"stalled", "dead"}
InQueue(s)       == \E i \in 1..Len(cellQueue) : cellQueue[i] = s
Without(q, s)    == SelectSeq(q, LAMBDA t : t # s)
\* Uploads complete: the barrier wants the cell.  Under the life lease
\* this IS `CASReady`; under the barrier lease the claim sits between.
UploadsDone(s)   == sc[s].scanU \subseteq (sc[s].upDone \cup sc[s].parked)
PreCommitReady(s) == sc[s].pc = "scanned" /\ UploadsDone(s)
\* Tranche 7: the PULL-ONLY boundary (`barrier.rs`, before the commit
\* section): nothing uploaded, deleted, consumed from the shared inbox,
\* removed or re-cited — so the merge can only add nothing, and the code
\* never claims for it.  (An adopt is an upload here: scanU = {} rules it
\* out.)  Defined over the same helpers the commit's merge reads.
PullOnlyReady(s) ==
  /\ BarrierLease /\ EmptyInstall
  /\ sc[s].pc = "scanned"
  /\ sc[s].scanU = {} /\ sc[s].scanD = {}
  /\ sc[s].consumed = {} /\ sc[s].declared = {}
  /\ ~\E p \in Paths : RepairOwed(s, p)
WantsCell(s)     == \/ PreCommitReady(s) /\ ~PullOnlyReady(s)
                    \/ sc[s].pc = "waiting"
                    \* A projected replay: the claim's reason may be a path
                    \* this run does not model (see the constant).
                    \/ ProjectedTrace /\ sc[s].pc = "scanned"
\* Every claim bumps the epoch; every claim follows a scan, so the
\* barrier budget bounds it (+2 for the life lease's StartA and ClaimB).
\* Under the liveness abstraction it saturates there instead.
EpochBound       == MaxBarriers + 2
NextEpoch        == IF InfiniteBarriers /\ cellEpoch >= EpochBound
                    THEN cellEpoch ELSE cellEpoch + 1
\* The claim rule (protocol of record §3): a FRESH cell; a RELEASED cell
\* whose handoff is nobody or me; or a HELD cell whose holder has been
\* quiet for the 60 s rule (stalled or dead) — the DEPOSAL, which is the
\* only arm that rotates.
ClaimEnabled(s) ==
  \/ CellFresh
  \/ cellReleased /\ cellHandoff \in {"none", s}
  \/ CellHeld /\ cellHolder # s /\ Quiet(cellHolder)
  \* A projected replay (W4 phase 2): a RELEASED cell is anyone's here,
  \* because the code's waiter does not always hold a ticket — several
  \* arms of `claim_step` answer Waiting without reaching the enqueue, and
  \* an enqueue that loses its CAS takes none either — so the handoff can
  \* name nobody while a writer waits.  The model's Enqueue always
  \* succeeds; that difference is an OPEN question, not a relaxation of
  \* anything the gate checks (no gate cfg sets ProjectedTrace).
  \/ ProjectedTrace /\ cellReleased
\* The 20 s rule on a handoff: the named waiter is quiet, so the released
\* cell is anybody's and the waiter is dropped.
SkipEnabled(s) ==
  /\ DeadHandoffSkip
  /\ cellReleased /\ cellHandoff \notin {"none", s}
  /\ Quiet(cellHandoff)
\* What a release writes: the queue head becomes the handoff (the
\* ticket), or nobody under the mutation.
ReleaseCell ==
  /\ cellReleased' = TRUE
  \* `epoch_handoff` writes the waiter list the holder read at its CLAIM,
  \* minus the head it names — but the write is conditional on the lease's
  \* token, so a ticket taken since forces a 412, a re-read and a retry on
  \* the adopted list (`release`, RELEASE_ATTEMPTS = 8).  Within that budget
  \* the two agree, which is why this is the head of the queue AS IT
  \* STANDS.  Verified against the storm traces, W4 phase 2.
  /\ cellHandoff' = IF Ticket /\ cellQueue # <<>> THEN Head(cellQueue) ELSE "none"
  /\ cellQueue'   = IF Ticket /\ cellQueue # <<>> THEN Tail(cellQueue) ELSE cellQueue
\* What a fence does to the incarnation.  Life lease: the process exits.
\* Barrier lease: the barrier is ABANDONED — its manifest never installed,
\* its uploads standing as uncited generations the next barrier adopts —
\* and the syncer keeps running; the next barrier claims again.
FencedSc(s) ==
  IF BarrierLease
  THEN [sc EXCEPT ![s].pc = "idle",
        ![s].scanU = {}, ![s].scanD = {},
        ![s].scanGen = [p \in Paths |-> 0],
        ![s].upDone = {}, ![s].parked = {}, ![s].gcDone = {}, ![s].gcTook = {},
        ![s].gcHeaded = {}, ![s].gcSeen = [p \in Paths |-> 0],
        ![s].retire = [p \in Paths |-> 0], ![s].upGone = {}, ![s].upVerified = FALSE,
        ![s].adopted = {}, ![s].noInst = FALSE]
  ELSE [sc EXCEPT ![s].st = "dead"]
\* `touched` is dirt the generations cannot show: a rewrite with the bytes
\* the baseline cites (see MaxSameBytes).  {} in every earlier cfg.
Dirty(s)    == {p \in Paths : sc[s].local[p] # sc[s].baseline[p]} \cup sc[s].touched
USet(s)     == {p \in Dirty(s) : sc[s].local[p] # 0}
\* The two-consecutive-scans rule.  Under ~TwoScanDelete this is the
\* one-scan rule every pre-existing cfg was written against, so their
\* state spaces are unchanged by construction.
DSet(s)     == {p \in Dirty(s) : sc[s].local[p] = 0
                                 /\ \/ ~TwoScanDelete
                                    \/ p \notin sc[s].prevScan
                                    \/ DeclaredConfirmsAbsence /\ SentinelEnabled
                                       /\ sc[s].pendN # {}}
CitedGens   == {manifest[p] : p \in Paths} \ {0}

\* The generation an acked pair refers to is destroyed by a syncer that
\* never legitimately learned it, with no surfaced record: the amputation
\* stamp for the destruction site.
Destroys(s, p, cur) ==
  /\ <<p, cur>> \in hitlAcked
  /\ cur \notin sc[s].known
  /\ <<p, cur>> \notin conflicts


------------------------------------------------------------------------------
(* Initial state: a project seeded with every path published at gen 1.     *)

Init ==
  /\ cellEpoch = 0 /\ cellHolder = "none" /\ manSeq = 1
  /\ cellQueue = <<>> /\ cellHandoff = "none" /\ cellReleased = FALSE
  /\ manSrc = "none"
  /\ manifest = [p \in Paths |-> IF p \in FreePaths THEN 0 ELSE 1]
  /\ objects  = [p \in Paths |-> IF p \in FreePaths THEN 0 ELSE 1]
  /\ inbox = {} /\ removals = {} /\ window = 0
  \* Every path starts published at gen 1, so gen 1 is its only version
  \* — except the FreePaths, which start absent.
  /\ versions = [p \in Paths |-> IF p \in FreePaths THEN {} ELSE {1}]
  /\ stage = [s \in Syncers |-> [p \in Paths |-> 0]]
  /\ stageBase = [s \in Syncers |-> [p \in Paths |-> 0]]
  /\ withheldDel = [s \in Syncers |-> {}]
  /\ sc = [s \in Syncers |->
       [st |-> "unstarted", pc |-> "idle", epoch |-> 0, expSeq |-> 0,
        installed |-> FALSE,
        local |-> [p \in Paths |-> 0], baseline |-> [p \in Paths |-> 0],
        scope |-> Paths, prevScan |-> {},
        instBase |-> [p \in Paths |-> 0],
        instSnap |-> [p \in Paths |-> 0], instSeq |-> 0, instSrc |-> "none",
        \* The intent journal's `installed_etag`: the pointer
        \* generation this workspace last INSTALLED.  Not instSeq,
        \* which a checkout and a PULL-ONLY also set — those name
        \* the document an ACK points at, and the code's journal
        \* records CASes only (`clear_intent_keys` leaves
        \* `installed_etag` alone).  Survives a restart: it is a
        \* file in the workspace.
        jSeq |-> 0,
        known |-> {}, scanU |-> {}, scanD |-> {},
        scanGen |-> [p \in Paths |-> 0], upDone |-> {}, parked |-> {},
        gcDone |-> {}, gcTook |-> {}, gcHeaded |-> {}, gcSeen |-> [p \in Paths |-> 0],
        adopted |-> {}, touched |-> {}, repairMoved |-> {},
        lastDirty |-> {}, stageCarried |-> FALSE,
        citeDone |-> {},
        sentTok |-> 0, pendN |-> {}, pendCov |-> [p \in Paths |-> 0],
        pendMint |-> 0, pendDirty |-> {},
        honored |-> FALSE, pendReRun |-> FALSE, owed |-> {}, ackN |-> {},
        citeDropped |-> {},
        carryPaths |-> {}, carryDropped |-> {}, verifiedAt |-> 0,
        retire |-> [p \in Paths |-> 0], upGone |-> {}, upVerified |-> FALSE,
        fq |-> {}, noInst |-> FALSE,
        fqRetired |-> [p \in Paths |-> 0],
        judged |-> [p \in Paths |-> 0],
        declared |-> {}, consumed |-> {}, surfaced |-> {},
        inboxSeen |-> {}, inboxLoaded |-> FALSE]]
  /\ hitlAcked = {} /\ conflicts = {}
  /\ gh = [amputated |-> FALSE,
           stragglerInstalls |-> 0, stragglerCas |-> 0, deposedPuts |-> 0,
           barriers |-> 0, done |-> 0, gc |-> 0, gcCited |-> 0, refusals |-> 0,
           cited |-> 0, takeovers |-> 0, crashes |-> 0, restarts |-> 0,
           adoptOwn |-> 0, stallUsed |-> FALSE, nextGen |-> 2, hitl |-> 0,
           syncs |-> 0, syncApplied |-> 0, syncConflicts |-> 0,
           syncDestroyed |-> FALSE,
           scopedDeferrals |-> 0, foreignLost |-> FALSE,
           deferredPaths |-> {}, deferredLater |-> 0,
           staged |-> 0, cites |-> 0, reaped |-> 0, withheld |-> 0,
           forcedCites |-> 0, citeSpan |-> 0,
           carriedCite |-> FALSE,
           touches |-> 0, acks |-> 0, honors |-> 0, refusedAcks |-> 0,
           coalesced |-> 0, fastPaths |-> 0, ackAfterRestart |-> 0,
           fastHonor |-> FALSE, ackEarly |-> FALSE,
           ackIncoherent |-> FALSE, fencedOkAck |-> FALSE,
           srcMismatch |-> FALSE,
           partialAcks |-> 0, declaredDrops |-> 0,
           narrows |-> 0, narrowed |-> {}, narrowRecited |-> {}, narrowDeleted |-> {}, consumeRegressed |-> FALSE,
           removals |-> 0, removalsApplied |-> 0, removalsRefused |-> 0,
           renamed |-> {}, renamesApplied |-> 0, renameRefused |-> {},
           citedPairs |-> {},
           claimed |-> {}, interleaved |-> FALSE, handoffs |-> 0,
           deposals |-> 0, deadSkips |-> 0, enqueues |-> 0, abandoned |-> 0,
           adoptWithheld |-> 0, sameBytes |-> 0, uploadWithheld |-> 0,
           staleOverride |-> FALSE, hitlRetired |-> {},
           pullOnlys |-> 0, emptyInstalls |-> 0,
           tombRemoved |-> 0, tombSuperseded |-> 0, orphanTracks |-> 0,
           leaked |-> 0, staleAdopt |-> 0,
           retired |-> [p \in Paths |-> 0],
           orphanAt |-> [p \in Paths |-> 0], orphanOutlived |-> 0,
           leakApplied |-> 0, baseRestored |-> 0, tomb |-> [p \in Paths |-> 0],
           carrierAck |-> FALSE,
           remJudged |-> [p \in Paths |-> 0], removalOverreach |-> FALSE,
           swept |-> 0, answered |-> {}, remOver |-> [p \in Paths |-> 0], uiBase |-> {},
           \* L-119: entries a barrier consumed, declined for the move
           \* alone, and left in the cell.  A probe counter — nothing
           \* reads it but the world that must reach the rule.
           pendingKept |-> 0]

------------------------------------------------------------------------------
(* Lifecycle *)

StartA ==
  /\ ~BarrierLease           \* the life lease: claim, then checkout
  /\ sc["A"].st = "unstarted" /\ cellHolder = "none"
  /\ cellHolder' = "A" /\ cellEpoch' = 1
  /\ sc' = [sc EXCEPT
       !["A"].st = "running", !["A"].epoch = 1, !["A"].expSeq = manSeq,
       !["A"].local = [p \in Paths |-> manifest[p]],
       !["A"].baseline = [p \in Paths |-> manifest[p]],
       !["A"].prevScan = IF TwoScanDelete
                            THEN {q \in Paths : manifest[q] # 0} ELSE {},
       !["A"].instBase = [p \in Paths |-> manifest[p]],
       !["A"].known = CitedGens]
  /\ UNCHANGED leaseVars
  /\ UNCHANGED <<manSeq, manSrc, manifest, objects, inbox, removals, window,
                 hitlAcked, conflicts, gh>>

(* Tranche 6: under the barrier lease a syncer starts by CHECKING OUT and
   holds nothing — `checkout` is lease-free, and the cell is claimed
   inside each barrier.  Both syncers start this way; there is no
   takeover.  B starts no earlier than A: pure symmetry breaking (the two
   are interchangeable here, except that only A can stall).             *)
StartLease(s) ==
  /\ BarrierLease /\ sc[s].st = "unstarted"
  /\ \A i \in DOMAIN Writers :
       Writers[i] = s => \A j \in 1..(i - 1) : sc[Writers[j]].st # "unstarted"
  /\ sc' = [sc EXCEPT
       ![s].st = "running", ![s].expSeq = manSeq,
       ![s].local = [p \in Paths |-> manifest[p]],
       ![s].baseline = [p \in Paths |-> manifest[p]],
       ![s].prevScan = IF TwoScanDelete
                          THEN {q \in Paths : manifest[q] # 0} ELSE {},
       ![s].instBase = [p \in Paths |-> manifest[p]],
       \* The document a never-installed writer's fast-path ack names.
       ![s].instSnap = [p \in Paths |-> manifest[p]], ![s].instSeq = manSeq,
       ![s].instSrc = manSrc,
       ![s].touched = {},
       ![s].known = CitedGens]
  /\ UNCHANGED leaseVars
  /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects,
                 inbox, removals, window, hitlAcked, conflicts, gh>>

CrashPod(s) ==
  /\ ~GatedCitation          \* gated replaces this with CrashPodGated
  /\ sc[s].st \in {"running", "stalled"}
  /\ gh.crashes < MaxCrashes
  \* Pod REPLACEMENT: the emptyDir goes, and with it the pending record,
  \* the workspace tree, `.flint/` and the agent that was waiting on it.
  \* Nothing is owed to a process that no longer exists — which is
  \* exactly why `Inv_NoNonceOrphan` is per-incarnation.
  /\ sc' = [sc EXCEPT ![s].st = "dead",
       ![s].sentTok = 0, ![s].pendN = {}, ![s].pendCov = NoPend,
       ![s].pendMint = 0, ![s].pendDirty = {},
       ![s].honored = FALSE, ![s].pendReRun = FALSE, ![s].carryPaths = {}, ![s].carryDropped = {},
       ![s].owed = {}, ![s].ackN = {},
       \* Tranche 7: the writer-local queue is a file in the same emptyDir.
       ![s].fq = {}, ![s].fqRetired = [p \in Paths |-> 0], ![s].noInst = FALSE,
       ![s].declared = {}, ![s].consumed = {}]
  /\ gh' = [gh EXCEPT !.crashes = @ + 1]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts>>

(* Pod REPLACEMENT under gated staging.  §4's substrate rule: `pending`
   lives in the emptyDir, so it DIES with the pod — "pod recreation
   destroys the emptyDir pending record and converts the whole uncited
   window into D9 orphans" (§2.6).  The ungated CrashPod cannot express
   that: stage/stageBase/withheldDel are framed at the Next composition
   (`UNCHANGED gatedVars` over BaseNext), so a crashed incarnation's
   entire staged set survived it — the exact opposite of the design, and
   the reason no gated cfg could safely raise MaxCrashes (review: U13).

   `citeDone` must go WITH it, and that is the half a frame fix alone
   misses.  Clearing only gatedVars leaves a dead syncer's frozen
   citeDone quantified by Inv_BoundaryAtomic against a Valid(s) that
   keeps moving as the inbox changes — a false positive that surfaces
   EARLIER (depth 9) than the one it was meant to remove (depth 16), on
   a STRICT run.  Both, or neither.                                     *)
CrashPodGated(s) ==
  /\ GatedCitation
  /\ sc[s].st \in {"running", "stalled"}
  /\ gh.crashes < MaxCrashes
  /\ sc' = [sc EXCEPT ![s].st = "dead",
       ![s].sentTok = 0, ![s].pendN = {}, ![s].pendCov = NoPend,
       ![s].pendMint = 0, ![s].pendDirty = {},
       ![s].honored = FALSE, ![s].pendReRun = FALSE, ![s].carryPaths = {}, ![s].carryDropped = {},
       ![s].owed = {}, ![s].ackN = {},
       ![s].citeDone = {},
       ![s].declared = {}, ![s].consumed = {}]
  /\ stage' = [stage EXCEPT ![s] = [p \in Paths |-> 0]]
  /\ stageBase' = [stageBase EXCEPT ![s] = [p \in Paths |-> 0]]
  /\ withheldDel' = [withheldDel EXCEPT ![s] = {}]
  /\ gh' = [gh EXCEPT !.crashes = @ + 1]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts, versions>>

(* Container restart in the SAME pod: the emptyDir survives, so local,
   baseline, known, expSeq and the incarnation epoch persist; only the
   in-memory barrier state is lost.  The restart matrix's marker-present
   row: never re-materialize — unless the mutation arm says otherwise.   *)
Restart(s) ==
  /\ Running(s)
  /\ gh.restarts < MaxRestarts
  /\ LET res == \E p \in Paths :
          sc[s].local[p] = 0 /\ manifest[p] # 0 /\ sc[s].baseline[p] # 0
         newLocal ==
           IF RematerializeOnRestart
           THEN [p \in Paths |-> IF sc[s].local[p] = 0 /\ manifest[p] # 0
                                 THEN manifest[p] ELSE sc[s].local[p]]
           ELSE sc[s].local
     IN
       /\ sc' = [sc EXCEPT ![s].pc = "idle",
            \* `honored` is in-memory barrier state and dies here; the
            \* pending record is a FILE in the surviving emptyDir.  That
            \* asymmetry is the uniform crash rule's whole subject.
            ![s].honored = FALSE,
            ![s].pendReRun = IF SentinelEnabled /\ PendLive(s)
                             THEN TRUE ELSE @,
            ![s].local = newLocal,
            ![s].known = IF RematerializeOnRestart THEN @ \cup CitedGens ELSE @,
            ![s].scanU = {}, ![s].scanD = {},
            ![s].scanGen = [p \in Paths |-> 0],
            ![s].upDone = {}, ![s].parked = {}, ![s].gcDone = {}, ![s].gcTook = {},
            ![s].gcHeaded = {}, ![s].gcSeen = [p \in Paths |-> 0],
            ![s].retire = [p \in Paths |-> 0], ![s].upGone = {}, ![s].upVerified = FALSE,
            ![s].adopted = {}, ![s].noInst = FALSE,
            \* `consumed` is in-memory barrier state; `declared` is the
            \* intent journal, a FILE in the surviving emptyDir (and so is
            \* tranche 7's queue, `fq`, which this leaves alone).
            ![s].consumed = {}]
       /\ gh' = [gh EXCEPT !.restarts = @ + 1]
  \* Tranche 6: a restarted container that finds the cell HELD by its own
  \* holder_id releases it at startup — it holds nothing in memory, and
  \* the intent journal replays what the previous container left.
  /\ IF BarrierLease /\ CellHeld /\ cellHolder = s
     THEN ReleaseCell ELSE UNCHANGED leaseVars
  /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts>>

(* A node freeze / partition: the process persists but takes no steps.
   Costs no crash budget — a stall is not a data-loss event (the
   WriterLimbo lesson).  One stall per run bounds the space.            *)
StallA ==
  /\ AllowStall /\ sc["A"].st = "running" /\ ~gh.stallUsed
  /\ sc' = [sc EXCEPT !["A"].st = "stalled"]
  /\ gh' = [gh EXCEPT !.stallUsed = TRUE]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts>>

ThawA ==
  /\ sc["A"].st = "stalled"
  /\ sc' = [sc EXCEPT !["A"].st = "running"]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts, gh>>

(* A deposed incarnation's next successful cell read (heartbeat renew)
   discovers the higher epoch and self-fences.                          *)
RenewDiscover(s) ==
  /\ Running(s) /\ DeposedHolder(s)
  \* D12 x D2.  The heartbeat renewal runs on its own interval,
  \* decoupled from publish cadence, so on deposal it is usually the
  \* FIRST arm to find out — ahead of the floor tick and ahead of a poll
  \* arm with nothing due.  It therefore owes the refused acks: exiting
  \* unsettled here strands the waiting agent with a marker still
  \* advertising live verbs, which is the hole D2 exists to close.
  \* (Shipped code returned from this arm without settling; the model
  \* was being written when the code was read, and the leg for it is
  \* `the_heartbeat_arm_settles_owed_acks_when_it_finds_the_fence`.)
  \* Tranche 6: `renew_if_due` between the commit's long steps finds the
  \* fence.  A fence is no longer a death and no `refused-fenced` ack
  \* exists: the barrier is abandoned and the pending record stands for
  \* the next barrier to honor.
  /\ LET settle == ~BarrierLease /\ SentinelEnabled /\ RefuseOnFence /\ PendLive(s) IN
       /\ sc' = [FencedSc(s) EXCEPT
            ![s].ackN = IF settle THEN @ \cup sc[s].pendN ELSE @,
            ![s].pendN = IF settle THEN {} ELSE @,
            ![s].pendCov = IF settle THEN NoPend ELSE @,
            ![s].pendMint = IF settle THEN 0 ELSE @,
            ![s].pendDirty = IF settle THEN {} ELSE @,
            ![s].honored = FALSE,
            ![s].pendReRun = IF BarrierLease THEN @ ELSE FALSE]
       /\ gh' = [gh EXCEPT !.refusedAcks = @ + (IF settle THEN 1 ELSE 0),
                          !.abandoned = IF BarrierLease THEN 1 ELSE @]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts>>

(* Takeover: B observes the quiet cell (abstracting the 6-poll protocol)
   and claims.  Rotation: the successor CAS-rewrites the manifest
   (seq++, content-identical) BEFORE serving — the straggler fence.     *)
ClaimB ==
  /\ ~BarrierLease           \* the life lease's takeover; see Claim
  /\ sc["B"].st = "unstarted" /\ cellHolder = "A"
  /\ sc["A"].st \in {"stalled", "dead"}
  /\ (Rotation => manSeq < MaxSeq)
  /\ cellHolder' = "B" /\ cellEpoch' = cellEpoch + 1
  /\ manSeq' = IF Rotation THEN manSeq + 1 ELSE manSeq
  \* A rotation is a fence, not a boundary: it publishes nothing, so it
  \* clears the stamp rather than inheriting the deposed holder's.
  /\ manSrc' = IF Rotation THEN "none" ELSE manSrc
  /\ sc' = [sc EXCEPT !["B"].st = "claiming",
                      !["B"].epoch = cellEpoch + 1]
  /\ gh' = [gh EXCEPT !.takeovers = @ + 1]
  /\ UNCHANGED leaseVars
  /\ UNCHANGED <<manifest, objects, inbox, removals, window, hitlAcked, conflicts>>

CheckoutB ==
  /\ sc["B"].st = "claiming"
  /\ sc' = [sc EXCEPT !["B"].st = "running", !["B"].expSeq = manSeq,
       !["B"].local = [p \in Paths |-> manifest[p]],
       !["B"].baseline = [p \in Paths |-> manifest[p]],
       !["B"].prevScan = IF TwoScanDelete
                            THEN {q \in Paths : manifest[q] # 0} ELSE {},
       !["B"].instBase = [p \in Paths |-> manifest[p]],
       !["B"].known = CitedGens]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts, gh>>

------------------------------------------------------------------------------
(* The agent (local edits only — the syncer publishes them later) *)

AgentWrite(s, p) ==
  /\ Running(s) /\ gh.nextGen <= MaxGen
  /\ sc' = [sc EXCEPT ![s].local[p] = gh.nextGen,
                      ![s].known = @ \cup {gh.nextGen}]
  \* Re-creating a narrowed path is the FEATURE (`sync.rs:13-22` names
  \* merge -> inbox -> consume as the designed destination for
  \* out-of-scope changes), so it leaves the narrow ledger — otherwise
  \* Inv_NarrowNeverRecites would fire on legitimate widening and the
  \* invariant would be unsound rather than strong.
  /\ gh' = [gh EXCEPT !.nextGen = @ + 1, !.narrowed = @ \ {p},
                     !.retired = IF WriterQueue THEN [@ EXCEPT ![p] = 0] ELSE @]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts>>

(* Finding 13: the agent writes bytes a version it RECOGNISES already
   has — most simply, deletes a file and writes it back unchanged.  A
   real etag is the MD5 of the bytes, so the write carries THAT version's
   etag, not a fresh one.  Back to the baseline's own generation, the
   path is dirty only by its stat, which `touched` carries.  Restricted
   to recognised generations: bytes that coincide with a version this
   writer never saw would also have to extend `known`, which is the
   amputation stamp's witness, and finding 13 does not need them.      *)
AgentWriteSame(s, p) ==
  /\ BarrierLease /\ Running(s)
  /\ gh.sameBytes < MaxSameBytes
  /\ \E g \in sc[s].known \ {0} :
       /\ sc' = [sc EXCEPT ![s].local[p] = g,
                           ![s].touched = IF g = sc[s].baseline[p]
                                          THEN @ \cup {p} ELSE @]
       /\ gh' = [gh EXCEPT !.sameBytes = @ + 1, !.narrowed = @ \ {p},
                          !.retired = IF WriterQueue THEN [@ EXCEPT ![p] = 0] ELSE @]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts>>

AgentDelete(s, p) ==
  /\ Running(s) /\ sc[s].local[p] # 0
  /\ sc' = [sc EXCEPT ![s].local[p] = 0]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts, gh>>

------------------------------------------------------------------------------
(* The NARROW verb (scoped-read design §4).                                *)

(* §4.2, as a machine-checkable claim.  `classify` reads exactly two
   states a narrow must pass through:

     present in scan, absent from baseline          -> UPLOAD
     present in baseline, absent from scan+prevScan -> DELETE

   so unlink-then-uncite crashes into publishing deletions, and
   uncite-then-unlink crashes into re-uploading identical bytes and
   re-citing everything just dropped.  NEITHER ORDER IS SAFE ALONE.

   The action drops one CLEAN, HELD path from the scope.  Clean because
   the shipped door refuses a narrow over a path with unpublished
   changes; held because dropping what was never held is a no-op.       *)
Narrow(s) ==
  /\ Running(s) /\ sc[s].pc = "idle"
  /\ gh.narrows < MaxNarrows
  /\ \E p \in sc[s].scope :
       /\ sc[s].baseline[p] # 0
       /\ sc[s].local[p] = sc[s].baseline[p]
       /\ sc' = [sc EXCEPT
            ![s].scope    = @ \ {p},
            \* Unlink: the tree half.  Skipped by the uncite-first arm.
            ![s].local    = IF NarrowAtomic \/ NarrowUnlinkFirst
                              THEN [sc[s].local EXCEPT ![p] = 0]
                              ELSE sc[s].local,
            \* Uncite: the held-set half.  Skipped by the unlink-first arm.
            ![s].baseline = IF NarrowAtomic \/ ~NarrowUnlinkFirst
                              THEN [sc[s].baseline EXCEPT ![p] = 0]
                              ELSE sc[s].baseline,
            \* prev_scan goes WITH the citation, never after it.
            \*
            \* THIS HALF IS NOT CHECKED HERE, AND THE GREEN RUN MUST NOT
            \* BE READ AS IF IT WERE.  `Dirty(s)` is `local[p] #
            \* baseline[p]`, so setting `baseline[p] = 0` alone already
            \* makes the path undirty and `prevScan` cannot change any
            \* classification.  MEASURED: deleting this line leaves
            \* LeanNarrowHolds green over 10,823 distinct states (vs
            \* 10,179 with it).  In `scan.rs` the two ARE separate
            \* structures and `classify` consults both, so the shipped
            \* rule has a conjunct this abstraction collapses.  Kept
            \* because the code needs it; recorded because the model is
            \* WEAKER than the code here, which is the safe direction for
            \* a miss and the wrong direction for a claim.
            ![s].prevScan = IF NarrowAtomic THEN @ \ {p} ELSE @]
       /\ gh' = [gh EXCEPT !.narrows = @ + 1, !.narrowed = @ \cup {p}]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts>>

------------------------------------------------------------------------------
(* The gateway, abstracted to its bucket effects *)

(* A HITL (UI) write: object PUT + inbox entry (plan v2), or a direct
   manifest bump (the refuted v1 reading, InboxEnabled = FALSE).  The
   user reads fresh, so the PUT always matches the current object.      *)
HitlWrite(p) ==
  /\ ~ImmutableObjects       \* handles replace this with HitlWriteIO
  /\ gh.hitl < MaxHitl /\ gh.nextGen <= MaxGen
  /\ ~(WindowCheck /\ window # 0)
  /\ HitlOverwritesTrackedOnly =>
       \/ objects[p] = 0
       \/ objects[p] = manifest[p]
       \/ <<p, objects[p]>> \in inbox
  /\ (~InboxEnabled => manSeq < MaxSeq)
  /\ LET g == gh.nextGen IN
       /\ objects' = [objects EXCEPT ![p] = g]
       /\ IF InboxEnabled
          THEN /\ inbox' = inbox \cup {<<p, g>>}
               /\ UNCHANGED <<manifest, manSeq, manSrc>>
          ELSE /\ manifest' = [manifest EXCEPT ![p] = g]
               /\ manSeq' = manSeq + 1
               \* The refuted direct-bump path: a party that holds no
               \* lease installed this, so it carries no syncer clock.
               /\ manSrc' = "none"
               /\ UNCHANGED inbox
       /\ hitlAcked' = hitlAcked \cup {<<p, g>>}
       /\ gh' = [gh EXCEPT !.nextGen = @ + 1, !.hitl = @ + 1,
               !.retired = IF WriterQueue THEN [@ EXCEPT ![p] = 0] ELSE @,
               !.orphanAt = IF OrphanEntryCited THEN [@ EXCEPT ![p] = 0] ELSE @,
               !.hitlRetired = IF MaxSameBytes > 0 /\ <<p, objects[p]>> \in hitlAcked
                               THEN @ \cup {<<p, objects[p]>>} ELSE @]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, window, sc, conflicts, removals>>

(* The refusal the window is FOR (availability shape, bounded to keep the
   space small; the starvation bound is a tranche-2 liveness question).  *)
HitlRefused ==
  /\ WindowCheck /\ window # 0 /\ gh.refusals < 1
  /\ gh' = [gh EXCEPT !.refusals = @ + 1]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, sc, hitlAcked, conflicts>>

(* Tranche 5: a DECLARED removal (delete/rename design §3).  The caller
   outside the pod records intent in the cell and touches no object;
   the syncer performs it at its next consume.  Not window-gated (§12):
   a removal touches nothing when it is recorded.                        *)
Tracked(p) == manifest[p] # 0 \/ \E pr \in inbox : pr[1] = p
\* H4: the version the gateway resolves for a path — the newest tracked UI
\* write, else the citation.
TrackedGen(p) ==
  LET gs == {pr[2] : pr \in {x \in inbox : x[1] = p}}
  IN IF gs = {} THEN manifest[p] ELSE CHOOSE g \in gs : \A h \in gs : h <= g

HitlRemove(p) ==
  /\ gh.removals < MaxRemovals
  /\ p \notin removals /\ Tracked(p)
  /\ removals' = removals \cup {p}
  /\ gh' = [gh EXCEPT !.removals = @ + 1,
                      !.remJudged = [@ EXCEPT ![p] = TrackedGen(p)],
                      !.remOver = [@ EXCEPT ![p] = 0],
                      !.answered = @ \ {p}]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox,
                 window, sc, hitlAcked, conflicts>>

(* A rename is a server-side copy to the destination (a fresh
   generation of the same bytes — create first, §5) and then ONE CAS
   carrying the destination entry and the source removal (§6).  The
   destination is acked as a HITL write is.  Window-gated, because it
   carries an entry.                                                    *)
HitlRename(p, q) ==
  /\ ~ImmutableObjects       \* handles replace this with HitlRenameIO
  /\ gh.removals < MaxRemovals /\ gh.nextGen <= MaxGen
  /\ p # q /\ p \notin removals /\ q \notin removals
  /\ Tracked(p) /\ ~Tracked(q) /\ objects[q] = 0
  /\ ~(WindowCheck /\ window # 0)
  /\ LET g == gh.nextGen IN
       /\ objects' = [objects EXCEPT ![q] = g]
       /\ inbox' = inbox \cup {<<q, g>>}
       /\ removals' = removals \cup {p}
       /\ hitlAcked' = hitlAcked \cup {<<q, g>>}
       \* The triple carries the SOURCE's generation at rename time:
       \* atomicity is about those bytes, not the name — an agent that
       \* re-creates the old name after the unlink has made a new file.
       /\ gh' = [gh EXCEPT !.nextGen = @ + 1, !.removals = @ + 1,
                          !.remJudged = [@ EXCEPT ![p] = TrackedGen(p)],
                          !.retired = IF WriterQueue THEN [@ EXCEPT ![q] = 0] ELSE @,
                          !.orphanAt = IF OrphanEntryCited THEN [@ EXCEPT ![q] = 0] ELSE @,
                          !.renamed = @ \cup {<<p, q, objects[p], g>>}]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, window, sc, conflicts>>

(* Finding 10's candidate fix.  An object sits at a CITED key under a
   generation the manifest does not cite and no inbox entry names: a
   writer's upload whose commit never came.  Any live writer may track it —
   an inbox entry, appended like the gateway's — and
   the consume that follows adopts it (clean) or preserves it (dirty), and
   the next commit cites it. *)
TrackOrphan(p) ==
  /\ BarrierLease /\ OrphanTrack /\ ~ImmutableObjects
  /\ \E s \in Syncers : Running(s)
  \* No window guard.  The append the code would use waits for the window
  \* and admits past a dead barrier's at its deadline (`admits_hitl`); the
  \* model has no deadline, and its first run of this arm parked forever
  \* behind the window of the very writer that died holding the cell.
  \* Safety never rested on the window (LeanNoWindowHolds), so allowing the
  \* append at any time is the stronger check.
  /\ manifest[p] # 0 /\ objects[p] # 0 /\ objects[p] # manifest[p]
  /\ <<p, objects[p]>> \notin inbox
  /\ inbox' = inbox \cup {<<p, objects[p]>>}
  \* No budget: each firing adds a (path, generation) pair the inbox did
  \* not hold, and generations are budgeted, so the arm is finite.  A
  \* budget of one spent itself on a LIVE writer's in-flight upload in the
  \* first run and left the real orphan untracked — the code's sweep runs
  \* again, so the model must too.
  /\ gh' = [gh EXCEPT !.orphanTracks = 1,
       \* H1b: the entry carries the citation it was judged against.
       !.orphanAt = IF OrphanEntryCited THEN [@ EXCEPT ![p] = manifest[p]] ELSE @]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, removals,
                 window, sc, hitlAcked, conflicts>>

(* ---- IMMUTABLE HANDLES: the gateway and the sweep ---------------------- *)
(* A UI write mints a fresh handle at p and REPLACES the cell's entry for
   p (`gateway_append` keeps one entry per path); the entry it replaced
   was the UI's own earlier write, superseded by a party entitled.  The
   entry records the citation the gateway saw (`InboxEntry.cited`), which
   is what the consume judges it against.  No guard on what sits at a key:
   nothing sits at a key, so `hitl_may_overwrite` and the HEAD-to-PUT
   window have nothing to guard.                                         *)
HitlWriteIO(p) ==
  /\ ImmutableObjects
  /\ gh.hitl < MaxHitl /\ gh.nextGen <= MaxGen
  /\ ~(WindowCheck /\ window # 0)
  /\ LET g == gh.nextGen
         old == {e \in inbox : e[1] = p}
     IN
       /\ versions' = [versions EXCEPT ![p] = @ \cup {g}]
       /\ inbox' = (inbox \ old) \cup {<<p, g>>}
       /\ hitlAcked' = hitlAcked \cup {<<p, g>>}
       /\ gh' = [gh EXCEPT !.nextGen = @ + 1, !.hitl = @ + 1,
               !.retired = IF WriterQueue THEN [@ EXCEPT ![p] = 0] ELSE @,
               !.uiBase = @ \cup {<<p, g, manifest[p]>>},
               !.hitlRetired = @ \cup old]
  /\ UNCHANGED leaseVars
  /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, removals,
                 window, sc, conflicts>>

(* A rename is a CITATION MOVE: the destination's entry names the SOURCE's
   handle, registered at the destination too; no bytes move and nothing is
   minted.  The source's removal is recorded exactly as before.          *)
HitlRenameIO(p, q) ==
  /\ ImmutableObjects
  /\ gh.removals < MaxRemovals
  /\ p # q /\ p \notin removals /\ q \notin removals
  /\ Tracked(p) /\ ~Tracked(q)
  /\ ~(WindowCheck /\ window # 0)
  /\ LET src == TrackedGen(p)
         \* The source's PENDING entry is the citation being moved: it
         \* goes with it (RenameMovesEntry), retired by the UI's own hand,
         \* and the removal names what that entry was written over.
         old == IF RenameMovesEntry THEN {<<p, src>>} \cap inbox ELSE {}
         fromEntry == <<p, src>> \in inbox
     IN
       /\ versions' = [versions EXCEPT ![q] = @ \cup {src}]
       /\ inbox' = (inbox \ old) \cup {<<q, src>>}
       /\ removals' = removals \cup {p}
       /\ hitlAcked' = hitlAcked \cup {<<q, src>>}
       /\ gh' = [gh EXCEPT !.removals = @ + 1,
                          !.remJudged = [@ EXCEPT ![p] = src],
                          !.remOver = [@ EXCEPT ![p] = IF fromEntry THEN manifest[p] ELSE 0],
                          !.answered = @ \ {p},
                          !.retired = IF WriterQueue THEN [@ EXCEPT ![q] = 0] ELSE @,
                          !.uiBase = @ \cup {<<q, src, 0>>},
                          !.renamed = @ \cup {<<p, q, src, src>>},
                          !.hitlRetired = @ \cup old]
  /\ UNCHANGED leaseVars
  /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, window, sc, conflicts>>

(* The orphan sweep.  A handle nothing cites, no entry names and no
   conflict record preserves is garbage: a lost writer's upload, a UI
   write's superseded predecessor, a removal's leftover.  It runs inside a
   commit section (SweepUnderLease), which is what makes that commit's
   VerifyUploads and CAS race-free against it; a writer never sweeps its
   own in-flight uploads (the code knows its flush id).  No grace is
   modelled — a green run means the grace is not what keeps anything safe;
   VerifyUploads is (LeanImmutableCasCitesBlind).  Taking an acked write
   nothing has surfaced or retired is the amputation stamp's third site. *)
SweepOrphan(s, p, h) ==
  /\ ImmutableObjects /\ Running(s)
  /\ SweepUnderLease => (Holding(s) /\ ~Fenced(s))
  /\ h \in versions[p]
  \* By name: the handle at p and at any path a rename aliased it to.
  /\ \A r \in Paths : SameHandle(p, r, h) =>
       /\ manifest[r] # h
       /\ SweepSparesTracked => <<r, h>> \notin inbox
       /\ <<r, h>> \notin conflicts
       /\ ~(r \in sc[s].upDone /\ sc[s].scanGen[r] = h)
  /\ versions' = [r \in Paths |-> IF SameHandle(p, r, h) THEN versions[r] \ {h} ELSE versions[r]]
  /\ gh' = [gh EXCEPT !.swept = @ + 1,
            !.amputated = @ \/ (/\ <<p, h>> \in hitlAcked
                                /\ <<p, h>> \notin conflicts
                                /\ <<p, h>> \notin gh.hitlRetired
                                /\ <<p, h>> \notin gh.citedPairs)]
  /\ UNCHANGED leaseVars
  /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, sc, hitlAcked, conflicts>>

------------------------------------------------------------------------------
(* The publish barrier (plan §2.1, seven steps; scan+intent merged, the
   consume->scan gap preserved — that gap is where strict-world parks
   come from) *)

(* Step 1: consume the inbox FIRST.  Clean paths adopt; dirty paths keep
   local (locally-dirty wins) and surface a conflict record; stale
   entries (superseded object) drop.  A barrier never runs against an
   unconsumed inbox.                                                     *)
\* `barrier.rs` step 1: "the cell, read ONCE".  Its own step ONLY under
\* InboxSnapshot, so that the window between the read and the consume —
\* where another writer's window clear empties the shared inbox — is a
\* window the model has too.  Without it the model reads `inbox` at the
\* instant of the consume and cannot take a step the code takes.
LoadInbox(s) ==
  /\ InboxSnapshot
  /\ Running(s) /\ sc[s].pc = "idle" /\ ~sc[s].inboxLoaded
  /\ ~(SentinelEnabled /\ sc[s].honored)
  /\ gh.barriers < MaxBarriers \/ InfiniteBarriers
  /\ sc' = [sc EXCEPT ![s].inboxSeen = inbox, ![s].inboxLoaded = TRUE]
  /\ UNCHANGED leaseVars
  /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox,
                 removals, window, hitlAcked, conflicts, gh>>

Consume(s) ==
  /\ Running(s) /\ sc[s].pc = "idle"
  \* An honored boundary owes its ack BEFORE anything else runs: the
  \* ack write is the last step of the honoring pass, in the same
  \* single-threaded arm, so the loop cannot start another pass in
  \* between.  Without this the model interleaves a consume there and
  \* reports an incoherence the implementation cannot reach — the ack
  \* would be judged against a baseline that moved after the boundary
  \* it names.
  /\ ~(SentinelEnabled /\ sc[s].honored)
  /\ gh.barriers < MaxBarriers \/ InfiniteBarriers
  /\ InboxSnapshot => sc[s].inboxLoaded
  /\ LET
       \* What the cell held when THIS barrier read it (InboxSnapshot), or
       \* what it holds now (the model as it was).
       seen == IF InboxSnapshot THEN sc[s].inboxSeen ELSE inbox
       \* Tranche 7: the writer-LOCAL queue's upserts join the entries (the
       \* code runs them first; with one entry per path and the key holding
       \* one generation, order among them changes nothing here), and an
       \* entry whose etag the baseline already holds is settled BEFORE
       \* every other arm, with no record — `consume_counted`'s "already".
       \* An entry whose object is gone leaves a `consume-object-missing`
       \* record.  Under ~WriterQueue: the rules as they were.
       cand == IF WriterQueue THEN seen \cup QueuedUpserts(s) ELSE seen
       already == IF WriterQueue
                  THEN {pr \in cand : sc[s].baseline[pr[1]] = pr[2]} ELSE {}
       missing == IF WriterQueue
                  THEN {pr \in cand \ already :
                          IF ImmutableObjects THEN ~HoldsGen(pr[1], pr[2])
                          ELSE objects[pr[1]] = 0}
                  ELSE {}
       live0 == {pr \in cand \ already : HoldsGen(pr[1], pr[2])}
       \* Handles: a gateway entry is judged against the citation the
       \* gateway saw when it appended (`InboxEntry.cited`).  A citation
       \* that moved to a LATER UI WRITE supersedes it (dropped, retired by
       \* the UI's own hand); one that moved to a writer's publish makes it
       \* a CONFLICT — the acked bytes stay at their own handle, surfaced,
       \* never adopted over the published version and never dropped in
       \* silence.  A delete (citation 0) is modify-wins, as it always was.
       \* A citation that moved to THE ENTRY ITSELF is a peer's publish of
       \* this very write: the entry is LIVE and the ordinary rules apply
       \* (a clean tree adopts it, a dirty one surfaces it and publishes
       \* over it knowingly).  The first HitlOverAny run under handles read
       \* that as "superseded" and dropped it, and the writer then cited
       \* its own edit over a version it had never learned (depth 18).  A
       \* citation that moved to an EARLIER UI write is live the same way:
       \* this entry is the newer of the two.  "Later" is mint order here;
       \* the code reads it from the handle's name (design doc, R7).
       uiOf(pr) == CHOOSE b \in Gens : <<pr[1], pr[2], b>> \in gh.uiBase
       judgedUI == IF ImmutableObjects
                   THEN {pr \in (live0 \cap seen) \ QueuedUpserts(s) :
                           /\ \E b \in Gens : <<pr[1], pr[2], b>> \in gh.uiBase
                           /\ manifest[pr[1]] \notin {0, uiOf(pr), pr[2]}
                           /\ ~(/\ <<pr[1], manifest[pr[1]]>> \in hitlAcked
                                /\ manifest[pr[1]] < pr[2])}
                   ELSE {}
       superUI == {pr \in judgedUI : <<pr[1], manifest[pr[1]]>> \in hitlAcked}
       staleUI == judgedUI \ superUI
       live == live0 \ judgedUI
       \* Review 2026-09-18, H1b: an entry the untracked sweep appended is
       \* honoured only while the manifest still cites at its path exactly
       \* what the sweep judged the object against.  A citation that moved
       \* on — to the object itself, to a newer one, or to nothing — ends
       \* it, with no record: nobody acked those bytes.  A gateway's entry
       \* carries no such clause (an acked write survives a concurrent
       \* delete: modify wins), and the queue's upserts are not in `seen`.
       outlived == IF OrphanEntryCited
                   THEN {pr \in (live \cap seen) \ QueuedUpserts(s) :
                           /\ gh.orphanAt[pr[1]] # 0
                           /\ manifest[pr[1]] # gh.orphanAt[pr[1]]}
                   ELSE {}
       \* ...and an adoption made from a sweep entry that still stands is
       \* PROVISIONAL: it carries the citation the sweep judged against.
       judgedOf(p) == IF /\ OrphanEntryCited /\ gh.orphanAt[p] # 0 /\ ~ImmutableObjects
                         /\ <<p, objects[p]>> \in seen \ QueuedUpserts(s)
                      THEN gh.orphanAt[p] ELSE 0
       adoptable == {pr \in live \ outlived :
                       /\ sc[s].local[pr[1]] = sc[s].baseline[pr[1]]
                       /\ pr[1] \notin sc[s].touched}
       \* A dirty local copy: local wins, the entry is surfaced, and the
       \* baseline advances past it so the local version publishes over it
       \* knowingly.  A stale UI entry (handles) is surfaced only: the path
       \* is clean at the published version and nothing re-publishes.
       dirtyConf == (live \ outlived) \ adoptable
       conflicted == dirtyConf \cup staleUI
       adoptPaths == {pr[1] : pr \in adoptable}
       surfPaths == IF ConflictSurfacing
                    THEN {pr[1] : pr \in dirtyConf} ELSE {}
       advPaths == adoptPaths \cup surfPaths
       \* Handles: the version a path adopts or advances to is the ENTRY's
       \* — the newest live one at the path (a queued upsert and a current
       \* UI entry can both be live; the UI's is the later mint).  The slot
       \* held exactly that under the shipped arm.
       Cands(p, S) == {pr[2] : pr \in {x \in S : x[1] = p}}
       Newest(S) == CHOOSE g \in S : \A h \in S : h <= g
       GenAt(p) == IF ~ImmutableObjects THEN objects[p]
                   ELSE IF p \in adoptPaths THEN Newest(Cands(p, adoptable))
                   ELSE Newest(Cands(p, dirtyConf))
       local1 == [p \in Paths |->
                    IF p \in adoptPaths THEN GenAt(p) ELSE sc[s].local[p]]
       base1  == [p \in Paths |->
                    IF p \in advPaths THEN GenAt(p) ELSE sc[s].baseline[p]]
       \* ...then the queued DELETIONS, against the tree the entries left
       \* (the code's second loop): nothing on disk settles; a copy that is
       \* dirty — or was never in the baseline — stays and publishes, with
       \* a `consume-foreign-delete-vs-dirty` record; a clean copy goes.
       tAbsent  == {p \in QueuedDeletes(s) : local1[p] = 0}
       \* Under the fix a key that holds an object has superseded the
       \* deletion: settled, nothing removed, no record.
       \* Review 2026-09-18, H1: under the fix the object supersedes the
       \* deletion only when it is NOT the generation the delete retired —
       \* the peer's own leaked object (a store without a conditional
       \* DELETE) is what the tombstone was written about, and applies it.
       \* Review 2026-09-18, H1b: under LeakSupersedesNothing a different
       \* object supersedes only if something will integrate it — the
       \* manifest cites it, or an entry this consume honours names it.
       \* A leak (uncited, untracked) supersedes nothing: the delete applies.
       trackedAt(p) == IF ImmutableObjects
                       THEN \E pr \in live \ outlived : pr[1] = p
                       ELSE <<p, objects[p]>> \in live \ outlived
       tSuper   == {p \in QueuedDeletes(s) \ tAbsent : ObjectSupersedes(s, p, trackedAt(p))}
       tKept    == {p \in QueuedDeletes(s) \ (tAbsent \cup tSuper) :
                      \/ base1[p] = 0
                      \/ local1[p] # base1[p]
                      \/ p \in sc[s].touched}
       tRemoved == QueuedDeletes(s) \ (tAbsent \cup tSuper \cup tKept)
       local2 == [p \in Paths |-> IF p \in tRemoved THEN 0 ELSE local1[p]]
       base2  == [p \in Paths |-> IF p \in tAbsent \cup tRemoved THEN 0 ELSE base1[p]]
       \* ---- the DECLARED removals (tranche 5, design §4-§6) ---------
       \* After the entries, so a rename's destination is in the tree
       \* before its source leaves it (§5).  A rename's removal waits
       \* for its destination to be INTEGRATED AND CLEAN; a destination
       \* the agent had taken (the consume surfaced it, the agent's
       \* version wins) REFUSES the move — the source stays, rather
       \* than surviving only as a conflict copy.  A dirty source
       \* refuses.  A clean or already-absent source is unlinked and
       \* declared.  Refusals leave the cell now, with a record;
       \* performed removals leave it at Finish, after the manifest.
       dstOf(p) == {pr[2] : pr \in {x \in gh.renamed : x[1] = p}}
       \* What the destination reads as: the slot, or under handles the
       \* newest tracked version there, else its citation.
       AtKey(q) == IF ImmutableObjects THEN TrackedOrCited(q) ELSE objects[q]
       dstReady(p) == ~RenameWaitsForDestination
                      \/ \A q \in dstOf(p) : base2[q] = AtKey(q) /\ local2[q] = base2[q]
       \* Handles: a rename's destination entry that is itself STALE (the
       \* path was cited by a writer's publish since) is a taken destination.
       staleAt(q) == \E pr \in staleUI : pr[1] = q
       dstTaken(p) == \E q \in dstOf(p) :
                        \/ q \in surfPaths \/ staleAt(q)
                        \/ (base2[q] = AtKey(q) /\ local2[q] # base2[q])
       \* H4: the generation this tree holds is not the one the removal
       \* named.  Still in the inbox, the named one has not arrived: wait.
       \* Otherwise it was replaced: refuse, and the newer one stays.
       \* Handles: a tree holding the version a moved entry was written
       \* over holds a version the request covers (`Removal.over`).
       moved(p) == /\ RemovalNamesGen /\ base2[p] # 0 /\ base2[p] # gh.remJudged[p]
                   /\ ~(ImmutableObjects /\ base2[p] = gh.remOver[p])
       arriving(p) == <<p, gh.remJudged[p]>> \in inbox
       refused == {p \in removals :
                     \/ (local2[p] # 0 /\ local2[p] # base2[p])
                     \/ dstTaken(p)
                     \/ moved(p) /\ ~arriving(p)}
       \* An ANSWERED record is one tree's answer, not the document's: it
       \* still moves the named version out of a tree that holds it clean
       \* at the source (AnsweredRecordsApply), and is never answered twice.
       applicable == removals \cup (IF ImmutableObjects /\ AnsweredRecordsApply
                                   THEN gh.answered ELSE {})
       applied == {p \in applicable \ refused :
                     /\ (local2[p] = 0 \/ local2[p] = base2[p])
                     /\ dstReady(p)
                     /\ ~moved(p)}
       declaredNow == IF DeclaredSkipsWalk THEN applied ELSE {}
     IN
       /\ sc' = [sc EXCEPT ![s].pc = "consumed",
            ![s].local = [p \in Paths |-> IF p \in applied THEN 0 ELSE local2[p]],
            ![s].baseline = base2,
            ![s].fq = IF WriterQueue THEN {} ELSE @,
            ![s].fqRetired = IF WriterQueue THEN [p \in Paths |-> 0] ELSE @,
            \* H1f: a superseded deletion leaves the copy it named in the
            \* tree, derived from the generation it retired — the merge
            \* base says so again, or the next install onto a manifest
            \* that dropped the path a second time has nothing to diff.
            ![s].instBase = IF SupersedeRestoresBase
                            THEN [p \in Paths |->
                                    IF p \in tSuper /\ sc[s].fqRetired[p] # 0
                                    THEN sc[s].fqRetired[p] ELSE @[p]]
                            ELSE @,
            ![s].judged = [p \in Paths |->
                             IF p \in tAbsent \cup tRemoved \cup applied THEN 0
                             ELSE IF p \in advPaths THEN judgedOf(p) ELSE @[p]],
            ![s].known = @ \cup {GenAt(p) : p \in advPaths},
            \* `baseline.prev_scan.insert(entry.path)`: a consumed path
            \* gets the two-scan protection as if the walk had seen it,
            \* so an agent delete right after the consume is a FIRST
            \* absence.  Gated like Scan's write, for the same reason.
            ![s].prevScan = IF TwoScanDelete
                            THEN (@ \cup adoptPaths) \ (tAbsent \cup tRemoved) ELSE @,
            ![s].declared = @ \cup declaredNow,
            \* What this barrier consumed, to leave the cell at Finish.
            ![s].consumed = IF EarlyInboxDrop THEN {} ELSE seen,
            \* The consume-dirty sentinel: set where a live entry was
            \* SURFACED, cleared where the baseline was rewritten.
            ![s].surfaced = (@ \ (adoptPaths \cup tAbsent \cup tRemoved)) \cup surfPaths,
            \* The next barrier reads the cell again.
            ![s].inboxLoaded = FALSE, ![s].inboxSeen = {}]
       /\ conflicts' = conflicts
            \cup (IF ConflictSurfacing THEN conflicted ELSE {})
            \cup {<<p, local2[p]>> : p \in refused}
            \cup missing
            \cup {<<p, 0>> : p \in tKept}
       \* The rule that shipped cleared the cell here ("durably in the
       \* baseline"); the baseline dies with the pod.  See EarlyInboxDrop.
       /\ inbox' = IF EarlyInboxDrop THEN {} ELSE inbox
       /\ removals' = removals \ refused
       \* U16: the arrival half of D4. A path this workspace deferred
       \* out of scope is integrated HERE, one consume later — which is
       \* the only reason deferring it was not simply losing it.
       /\ gh' = [gh EXCEPT
            !.orphanOutlived = @ + Cardinality(outlived),
            \* H1b: a deletion applied over a DIFFERENT object at the key —
            \* one nothing cites and nothing tracks, i.e. a leak.
            !.leakApplied = @ + Cardinality({p \in tRemoved :
                                               /\ ~ImmutableObjects
                                               /\ objects[p] # 0 /\ objects[p] # sc[s].fqRetired[p]}),
            \* H1f: a superseded deletion actually moved the merge base.
            !.baseRestored = @ + Cardinality({p \in tSuper :
                                                /\ SupersedeRestoresBase
                                                /\ sc[s].fqRetired[p] # 0
                                                /\ sc[s].instBase[p] # sc[s].fqRetired[p]}),
            \* Adopted from the SNAPSHOT an entry the cell no longer holds:
            \* a peer's window clear dropped it between this barrier's read
            \* and this step.  The non-vacuity for the InboxSnapshot world —
            \* without it, "every invariant holds" could mean "the window
            \* never opened".
            !.staleAdopt = @ + Cardinality({pr \in adoptable :
                                              pr \in seen /\ pr \notin inbox}),
            !.deferredLater = @ + Cardinality(advPaths \cap gh.deferredPaths),
            !.deferredPaths = @ \ advPaths,
            !.removalsApplied = @ + Cardinality(applied),
            \* H4's stamp: a removal took a generation it was not judged
            \* against.  Written only with removals in the world.
            !.removalOverreach = @ \/ (MaxRemovals > 0 /\
                                      \E p \in applied : /\ base2[p] # 0 /\ base2[p] # gh.remJudged[p]
                                                         /\ ~(ImmutableObjects /\ base2[p] = gh.remOver[p])),
            !.answered = (@ \cup refused) \ applied,
            \* 2026-09-23: a consume never adopts a version OLDER than the one
            \* the tree already holds (generations are minted in order): the
            \* queued peer change a later sync overtook (`sync.rs` never reads
            \* the writer-local queue).
            !.consumeRegressed = @ \/ \E p \in adoptPaths :
                                   /\ sc[s].baseline[p] # 0 /\ GenAt(p) < sc[s].baseline[p]
                                   \* Mint order is not publish order: a version
                                   \* displaced KNOWINGLY carries a conflict record.
                                   /\ <<p, sc[s].baseline[p]>> \notin conflicts,
            !.removalsRefused = @ + Cardinality(refused),
            !.renamesApplied = @ + Cardinality({pr \in gh.renamed : pr[1] \in applied}),
            !.renameRefused = @ \cup {pr \in gh.renamed : pr[1] \in refused},
            !.tombRemoved = IF tRemoved # {} THEN 1 ELSE @,
            !.tombSuperseded = IF tSuper # {} THEN 1 ELSE @,
            \* Handles: an entry a later UI write superseded, and the version
            \* a DECLARED removal took (a rename's source keeps its handle at
            \* the destination, so no collector will ever say so), are
            \* retired here, by the decision that retired them.
            \* ...and a version this tree had INTEGRATED that a LATER UI
            \* write at the same path replaces here (the UI's own hand,
            \* one consume after the slot's overwrite would have said so).
            !.hitlRetired = @ \cup (IF ImmutableObjects
                                    THEN superUI \cup {<<p, base2[p]>> : p \in applied}
                                         \cup {<<p, sc[s].baseline[p]>> :
                                                 p \in {q \in advPaths :
                                                          /\ <<q, sc[s].baseline[q]>> \in hitlAcked
                                                          /\ \E b \in Gens : <<q, GenAt(q), b>> \in gh.uiBase
                                                          /\ GenAt(q) > sc[s].baseline[q]}}
                                    ELSE {})]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, window,
                 hitlAcked>>

(* Steps 2+3: scan-diff against the persisted baseline and CAS the
   window open (the intent).  A stale window (a lower epoch's) may be
   overridden; an open window at my own or a higher epoch blocks.       *)
Scan(s) ==
  /\ Running(s) /\ sc[s].pc = "consumed"
  \* Tranche 6: the window belongs to the commit section and opens AT
  \* the claim; a scan before the claim neither opens nor waits for it.
  /\ BarrierLease \/ window = 0 \/ window < sc[s].epoch
  /\ sc' = [sc EXCEPT ![s].pc = "scanned",
       \* A declared removal skips the two-scan guard (§4): the guard
       \* protects against absence INFERRED by a walk, and a
       \* declaration is not an inference.  It is NOT a delete, though,
       \* where the agent re-created the path between the removal pass
       \* and this walk: the declaration named the file that is gone,
       \* and what is there now publishes as the agent's own upload
       \* (`barrier.rs`'s scan skips exactly this, "the model's install
       \* gives the upload the same precedence").  Modelled as both, the
       \* path was an upload the re-read could withhold AND a delete,
       \* and a rename's source then kept its citation while the
       \* destination was repaired beside it — one handle, two names
       \* (the core model's two-path world, 2026-09-20).
       ![s].scanU = USet(s),
       ![s].scanD = DSet(s) \cup {p \in sc[s].declared : sc[s].local[p] = 0},
       ![s].lastDirty = IF SyncEnabled THEN USet(s) \cup DSet(s) ELSE {},
       ![s].scanGen = [p \in Paths |-> sc[s].local[p]],
       \* `prev_scan = scanned.keys()`.  Read UNPRIMED above by DSet, so
       \* this scan classifies against the PREVIOUS walk and leaves its
       \* own behind — the whole content of "two consecutive scans".
       \*
       \* Gated on TwoScanDelete so it stays `{}` in every pre-existing
       \* cfg. Writing it unconditionally would add a varying component
       \* to `sc` and GROW all 55 earlier runs' state spaces — which
       \* costs wall clock for nothing and, worse, quietly falsifies the
       \* "earlier state spaces are preserved by construction" claim the
       \* rest of this harness is built on.
       ![s].prevScan = IF TwoScanDelete
                         THEN {q \in Paths : sc[s].local[q] # 0}
                         ELSE @,
       \* The pending set survived a lane pass: the durability/visibility
       \* split actually ACCUMULATED across ticks, which is the claim
       \* ProbeCitationInstalled has to make non-vacuous.
       ![s].stageCarried = \E q \in Paths : stage[s][q] # 0,
       ![s].upDone = {}, ![s].parked = {}, ![s].gcDone = {}, ![s].gcTook = {},
       ![s].retire = [p \in Paths |-> 0], ![s].upGone = {}, ![s].upVerified = FALSE]
  /\ window' = IF BarrierLease THEN window ELSE sc[s].epoch
  \* A walk that reads a path THIS writer narrowed as a delete: the
  \* unlink-first narrow's harm, at the one step that decides it.
  /\ gh' = [gh EXCEPT !.barriers = IF InfiniteBarriers THEN @ ELSE @ + 1,
                      !.narrowDeleted = @ \cup ((DSet(s) \cap gh.narrowed) \ sc[s].scope)]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 hitlAcked, conflicts>>

(* Step 4: guarded per-key upload.  If-Match = the persisted baseline
   generation (If-None-Match:* for creates falls out as baseline = 0).
   The 412 arm: own/known generation => adopt (the crashed-PUT resume);
   foreign => park + surface, or LOCAL-WINS overwrite under the
   mutation.  EpochCheck rejects a deposed writer per-request — the
   syncer takes the rejection as deposal and fences.                   *)
UploadFenced(s) ==
  /\ ~GatedCitation
  /\ Running(s) /\ sc[s].pc = "scanned"
  /\ Fenced(s)               \* unreachable under BarrierLease: no holder uploads
  /\ sc[s].scanU \ (sc[s].upDone \cup sc[s].parked) # {}
  /\ sc' = [sc EXCEPT ![s].st = "dead"]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts, gh>>

(* Tranche 6: under the barrier lease the upload is a NON-HOLDER action —
   every PUT is If-Match on the base etag, S3's own optimistic lock, so
   it needs no lease and is never fenced; `Inv_NoDeposedPut` applies to
   the commit section only (protocol of record, straggler rules).       *)
Upload(s, p) ==
  /\ ~GatedCitation          \* gated replaces this with StagePut
  /\ ~ImmutableObjects       \* handles replace this with UploadIO
  /\ Running(s) /\ sc[s].pc = "scanned"
  /\ p \in sc[s].scanU \ (sc[s].upDone \cup sc[s].parked)
  /\ ~Fenced(s)
  /\ LET cur == objects[p]
         want == sc[s].scanGen[p]
         \* Tranche 6: `upload_one`'s 412 arm adopts ONLY when the object
         \* already holds the bytes being uploaded (CRC match); any other
         \* generation it recognises is SUPERSEDED knowingly, If-Match on
         \* what the HEAD saw.  The life-lease arm below adopts any
         \* recognised generation and then cites the walk's bytes — a
         \* generation no object holds — which `Inv_NoDangling` cannot
         \* see with one writer (the object still exists) and TLC showed
         \* on the first two-writer strict run, once the OTHER writer's
         \* GC removed the adopted object.  The gated lane got this fix
         \* in product 1 x 2; the ungated arm keeps its coarse rule under
         \* the life lease so those state spaces are unchanged.
         supersede == BarrierLease /\ cur \in sc[s].known /\ cur # want
     IN
       IF cur = sc[s].baseline[p] \/ supersede
       THEN \* If-Match passes: the PUT lands
         /\ objects' = [objects EXCEPT ![p] = want]
         /\ sc' = [sc EXCEPT ![s].upDone = @ \cup {p}]
         /\ gh' = [gh EXCEPT !.narrowRecited = @ \cup (({p} \cap gh.narrowed) \ sc[s].scope), !.deposedPuts =
                     @ + (IF DeposedHolder(s) THEN 1 ELSE 0),
                     !.hitlRetired = IF /\ MaxSameBytes > 0 /\ cur # want
                                        /\ cur \in sc[s].known /\ <<p, cur>> \in hitlAcked
                                     THEN @ \cup {<<p, cur>>} ELSE @,
                     \* the required-reachable overlap: this PUT landed
                     \* while another syncer was in its commit section
                     !.interleaved = @ \/ (BarrierLease /\ CellHeld /\ cellHolder # s)]
         /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, inbox, removals,
                        window, hitlAcked, conflicts>>
       ELSE IF cur \in sc[s].known
       THEN \* 412, but the current ETag is one I minted or consumed:
            \* adopt (my own crashed/torn earlier PUT, or content already
            \* integrated).  AdoptOwn convergence.  Tranche 6: remembered,
            \* because nothing was PUT and the object is another writer's
            \* to GC until this barrier's CAS cites it.
         /\ sc' = [sc EXCEPT ![s].upDone = @ \cup {p},
                             ![s].adopted = IF BarrierLease THEN @ \cup {p} ELSE @]
         /\ gh' = [gh EXCEPT !.narrowRecited = @ \cup (({p} \cap gh.narrowed) \ sc[s].scope), !.adoptOwn = @ + 1]
         /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects,
                        inbox, removals, window, hitlAcked, conflicts>>
       ELSE IF ConflictSurfacing
       THEN \* foreign ETag: park the path, surface the conflict, never
            \* overwrite an ETag this syncer did not itself publish.
            \* Under Upload412Preserves the conflict record IS the preserved
            \* copy, and the upload then supersedes the foreign version
            \* knowingly — or parks, when that second PUT races (either).
         \/ /\ sc' = [sc EXCEPT ![s].parked = @ \cup {p}]
            /\ conflicts' = conflicts \cup {<<p, cur>>}
            /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects,
                           inbox, removals, window, hitlAcked, gh>>
         \/ /\ Upload412Preserves
            /\ objects' = [objects EXCEPT ![p] = want]
            /\ sc' = [sc EXCEPT ![s].upDone = @ \cup {p}]
            /\ conflicts' = conflicts \cup {<<p, cur>>}
            /\ gh' = [gh EXCEPT !.narrowRecited = @ \cup (({p} \cap gh.narrowed) \ sc[s].scope),
                        !.deposedPuts = @ + (IF DeposedHolder(s) THEN 1 ELSE 0),
                        !.interleaved = @ \/ (BarrierLease /\ CellHeld /\ cellHolder # s)]
            /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest,
                           inbox, removals, window, hitlAcked>>
       ELSE \* MUTATION: the inherited LOCAL-WINS arbitration — re-read
            \* the ETag and overwrite blind.  known does NOT grow.
         /\ objects' = [objects EXCEPT ![p] = want]
         /\ sc' = [sc EXCEPT ![s].upDone = @ \cup {p}]
         /\ gh' = [gh EXCEPT
              !.amputated = @ \/ Destroys(s, p, cur),
              !.deposedPuts = @ + (IF DeposedHolder(s) THEN 1 ELSE 0)]
         /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, inbox, removals,
                        window, hitlAcked, conflicts>>

(* Immutable handles: the upload is a PUT to a fresh handle — no If-Match,
   no 412, no adopt, no park, nothing to preserve.  Lease-free as before
   and never fenced; `Inv_NoDeposedPut` stays the commit section's.     *)
UploadIO(s, p) ==
  /\ ImmutableObjects
  /\ Running(s) /\ sc[s].pc = "scanned"
  /\ p \in sc[s].scanU \ sc[s].upDone
  /\ LET want == sc[s].scanGen[p] IN
       /\ versions' = [versions EXCEPT ![p] = @ \cup {want}]
       /\ sc' = [sc EXCEPT ![s].upDone = @ \cup {p}]
       /\ gh' = [gh EXCEPT !.narrowRecited = @ \cup (({p} \cap gh.narrowed) \ sc[s].scope),
                          !.deposedPuts = @ + (IF DeposedHolder(s) THEN 1 ELSE 0),
                          !.interleaved = @ \/ (CellHeld /\ cellHolder # s)]
  /\ UNCHANGED leaseVars
  /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts>>

(* Steps 5+6 in the chosen order.  The GC delete (etag-guarded HEAD:
   refuse any ETag the syncer does not recognize).  Under
   DeletesAfterCAS = FALSE (the v1 order) the deletes run BEFORE the
   CAS — the dangling-manifest mutation.  Tranche 6: the deletes are
   commit-section work in either order, so under the barrier lease the
   pre-CAS arm runs from the claim, not from the uploads.               *)
GCPhase(s) ==
  \/ (DeletesAfterCAS /\ sc[s].pc = "cased")
  \/ (~DeletesAfterCAS
      /\ (IF BarrierLease THEN sc[s].pc = "claimed" ELSE PreCommitReady(s)))

(* Tranche 6, ~ConditionalGC: the HEAD half of the shipped two-request
   GC.  Reads the object's generation and remembers it; the DELETE below
   is then guarded on what was SEEN, not on what is there.              *)
GCHead(s, p) ==
  /\ BarrierLease /\ ~ConditionalGC /\ ~ImmutableObjects
  /\ Running(s) /\ GCPhase(s)
  /\ p \in sc[s].scanD \ (sc[s].gcDone \cup sc[s].gcHeaded)
  /\ sc' = [sc EXCEPT ![s].gcHeaded = @ \cup {p},
                      ![s].gcSeen = [@ EXCEPT ![p] = objects[p]]]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects,
                 inbox, removals, window, hitlAcked, conflicts, gh>>

GCDelete(s, p) ==
  /\ ~ImmutableObjects       \* handles replace this with GCCollect
  /\ Running(s)
  /\ GCPhase(s)
  /\ p \in sc[s].scanD \ sc[s].gcDone
  \* Review 2026-09-18, C2: the fence is an OBSERVATION the collector
  \* makes, not a property of the request.  Under the fix it looks
  \* before every delete; as shipped it looked every 200, so a deposed
  \* holder's delete lands.
  /\ GCFencePerDelete => ~Fenced(s)
  \* Two requests (the shipped shape) or one: with If-Match the guard and
  \* the delete are the same request and `cur` is what is there.
  /\ ConditionalGC \/ ~BarrierLease \/ p \in sc[s].gcHeaded
  /\ LET cur == IF ConditionalGC \/ ~BarrierLease THEN objects[p] ELSE sc[s].gcSeen[p]
         now == objects[p]
     IN
       \* v2 (deletes-after-CAS): the delete set is "keys the NEW manifest
       \* no longer references" — a key the merge re-cited (delete/modify
       \* resolved foreign-wins) is NOT garbage.  The v1 order cannot make
       \* this check (no new manifest yet) — that asymmetry is part of the
       \* defect the DeletesAfterCAS mutation pins.
       \* `wouldCollect` is the collector's own decision, kept separate
       \* from CollectorOff so the leak can be COUNTED: a world where the
       \* collector gives way proves nothing unless it gave way on a path
       \* it would otherwise have taken (`ProbeCollectorLeaked`).
       \* "Keys the NEW manifest no longer references" is judged against
       \* the document THIS barrier installed (`installed.entries`,
       \* barrier.rs step 6), not against the live pointer: a holder
       \* deposed after its CAS landed cannot see the successor's
       \* re-citation, which is C2's whole mechanism.  Identical while
       \* the fence is atomic (nobody installs between a holder's CAS
       \* and its deletes); verified by count on the census worlds.
       LET wouldCollect == /\ cur # 0
                           /\ (~GuardedGC \/ cur \in sc[s].known)
                           /\ (~DeletesAfterCAS \/ sc[s].instSnap[p] = 0)
       IN
       IF ~wouldCollect \/ CollectorOff
       THEN \* already absent, still referenced, an unrecognized ETag —
            \* or a store whose conditional DELETE is not enforced, where
            \* the object is LEFT (`barrier.rs`, report.leaked).  Either
            \* way nothing is deleted and p is not in gcTook, so under
            \* BaselineKeepsUncollected the baseline keeps its entry.
         /\ sc' = [sc EXCEPT ![s].gcDone = @ \cup {p}]
         /\ gh' = [gh EXCEPT !.leaked = IF CollectorOff /\ wouldCollect
                                        THEN @ + 1 ELSE @,
              \* RETIREMENT is the collector's DECISION, not the DELETE.
              \* A writer that recognises these bytes and takes the path
              \* out of its boundary has retired the write whether or not
              \* the store carries the delete out — so a leak retires it
              \* exactly as a collection does.  Only the CollectorOff arm:
              \* the other reasons to skip (still referenced, an etag this
              \* writer does not recognise) are not decisions ABOUT these
              \* bytes at all.
              !.hitlRetired = IF /\ CollectorOff /\ wouldCollect
                                 /\ cur \in sc[s].known
                                 /\ <<p, cur>> \in hitlAcked
                              THEN @ \cup {<<p, cur>>} ELSE @]
         /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects,
                        inbox, removals, window, hitlAcked, conflicts>>
       ELSE
         /\ objects' = [objects EXCEPT ![p] = 0]
         /\ sc' = [sc EXCEPT ![s].gcDone = @ \cup {p},
                            ![s].gcTook = IF BaselineKeepsUncollected
                                          THEN @ \cup {p} ELSE @]
         /\ gh' = [gh EXCEPT !.gc = @ + 1,
              !.amputated = @ \/ Destroys(s, p, now),
              \* Gate KEPT here, deliberately.  After a real delete
              \* `objects[p] = 0`, so the invariant's first clause already
              \* covers the pair and this ghost is needed only where a
              \* generation can reappear — same bytes.  Widening a STICKY
              \* excuse that nothing needs would be a relaxation for free.
              \* The leak branch above is the opposite case: the object
              \* stays, so nothing else covers it.
              !.hitlRetired = IF /\ MaxSameBytes > 0 /\ now \in sc[s].known
                                 /\ <<p, now>> \in hitlAcked
                              THEN @ \cup {<<p, now>>} ELSE @]
         /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, inbox, removals,
                        window, hitlAcked, conflicts>>

GCDeleteFenced(s) ==
  /\ GCFencePerDelete
  /\ Running(s) /\ Fenced(s)
  /\ GCPhase(s)
  /\ sc[s].scanD \ sc[s].gcDone # {}
  /\ sc' = FencedSc(s)
  /\ gh' = [gh EXCEPT !.abandoned = IF BarrierLease THEN 1 ELSE @]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts>>

PreDeletesDone(s) ==
  /\ Running(s) /\ ~DeletesAfterCAS
  /\ (IF BarrierLease THEN sc[s].pc = "claimed" ELSE PreCommitReady(s))
  /\ sc[s].scanD \subseteq sc[s].gcDone
  /\ sc' = [sc EXCEPT ![s].pc = "delDone"]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts, gh>>

(* Step 5: the manifest CAS.  Parked paths withhold their entry.  A
   merge-capable writer preserves foreign entries and queues them; the
   whole-rewrite writer (MergeCapable = FALSE) writes the local view and
   re-seeds on 412 — the amputation engine.  A deposed writer is caught
   by EpochCheck (per-request), by Rotation (seq mismatch => cell
   re-read => fence), or — with both arms off — LANDS: the straggler
   install.                                                             *)
CASReady(s) ==
  IF DeletesAfterCAS
  THEN (IF BarrierLease THEN sc[s].pc = "claimed" ELSE PreCommitReady(s))
  ELSE sc[s].pc = "delDone"

(* ---- IMMUTABLE HANDLES: the commit section's two new steps ------------- *)
(* The commit re-reads every citation its own uploads add — one HEAD per
   uploaded handle, the code's `verify_observed_citations` — and withholds
   what the sweep has taken (VerifyUploadedCitations; FALSE is the mutation
   LeanImmutableCasCitesBlind).  Its own step, deliberately: a sweep in
   another writer's commit section cannot land between this and the CAS
   (SweepUnderLease), and the mutation that lets it is one an atomic
   verify-and-install could never show — the C2 lesson, applied.         *)
VerifyUploads(s) ==
  /\ ImmutableObjects
  /\ Running(s) /\ CASReady(s) /\ ~sc[s].upVerified
  /\ sc' = [sc EXCEPT ![s].upVerified = TRUE,
              ![s].upGone = IF VerifyUploadedCitations
                            THEN {p \in sc[s].scanU \cap sc[s].upDone :
                                    ~HoldsGen(p, sc[s].scanGen[p])}
                            ELSE {}]
  /\ UNCHANGED leaseVars
  /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, versions, inbox,
                 removals, window, hitlAcked, conflicts, gh>>

(* Step 6 under handles.  The retired set — every handle the document this
   barrier installed stopped citing, minus what it still cites at another
   path (a rename) and what an inbox entry names — is deleted
   UNCONDITIONALLY, in one batch, with no HEAD, no fence and no lease: a
   retired handle is never re-cited (nothing discovers handles from
   paths), so a deposed straggler's delete is as safe as the holder's.
   RetirePerPath is the mutation that forgets the rename.                *)
GCCollect(s) ==
  /\ ImmutableObjects
  /\ Running(s) /\ sc[s].pc = "cased"
  /\ \/ sc[s].scanD \ sc[s].gcDone # {}
     \/ \E p \in Paths : sc[s].retire[p] # 0
  /\ LET retiredPairs == {<<p, sc[s].retire[p]>> : p \in {q \in Paths : sc[s].retire[q] # 0}}
         \* Kept: the installed document cites the handle at another path
         \* (a rename's destination), or an inbox entry names it.  By NAME
         \* (SameHandle): the seed generation at another path is another
         \* handle.  The first run of the RetirePerPath world found this
         \* collector taking p2's seed for p1's with no rename in the trace
         \* — the refutation stood, but for the rename it names, not for
         \* the trace it showed.
         \* An entry THIS barrier consumed names nothing here: it is judged
         \* (adopted and cited, surfaced, or declined) and leaves the cell
         \* at Finish, so a handle only it names is garbage now, not after
         \* the sweep — the code's `named` excludes the consumed set.
         kept(p, g) == /\ ~RetirePerPath
                       /\ \E q \in Paths : /\ SameHandle(p, q, g)
                                           /\ (\/ sc[s].instSnap[q] = g
                                               \/ <<q, g>> \in inbox /\ <<q, g>> \notin sc[s].consumed)
         R == {pr \in retiredPairs : ~kept(pr[1], pr[2])}
         takes(r) == {pr[2] : pr \in {x \in R : SameHandle(x[1], r, x[2])}}
     IN
       /\ versions' = [r \in Paths |-> versions[r] \ takes(r)]
       /\ sc' = [sc EXCEPT ![s].gcDone = sc[s].scanD, ![s].gcTook = sc[s].scanD,
                           ![s].retire = [p \in Paths |-> 0]]
       /\ gh' = [gh EXCEPT !.gc = @ + Cardinality(R),
                 !.amputated = @ \/ \E pr \in R : Destroys(s, pr[1], pr[2]),
                 \* RETIREMENT is the collector's decision: the pairs this
                 \* install stopped citing, collected or moved.
                 !.hitlRetired = @ \cup retiredPairs]
  /\ UNCHANGED leaseVars
  /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts>>


\* Review 2026-09-18, H2: the shipped commit section's one cell read.
Verified(s) == sc[s].verifiedAt = sc[s].epoch
VerifyCell(s) ==
  /\ ~FenceAfterLoad /\ BarrierLease
  /\ Running(s) /\ CASReady(s) /\ ~Verified(s)
  /\ IF DeposedHolder(s)
     THEN /\ sc' = FencedSc(s)
          /\ gh' = [gh EXCEPT !.stragglerCas = @ + 1, !.abandoned = 1]
     ELSE /\ sc' = [sc EXCEPT ![s].verifiedAt = sc[s].epoch]
          /\ UNCHANGED gh
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts>>

CASFenced(s) ==
  /\ FenceAfterLoad
  /\ Running(s) /\ CASReady(s)
  /\ Fenced(s)
  /\ sc' = FencedSc(s)
  /\ gh' = [gh EXCEPT !.stragglerCas = @ + 1,
                      !.abandoned = IF BarrierLease THEN 1 ELSE @]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts>>

(* The commit section's OTHER exit (2026-09-15, W4 phase 2).  A request    *)
(* the commit makes is refused by the store — S3's 409 on the window-open  *)
(* PUT in the storm leg — so the barrier fails, releases the cell and      *)
(* keeps the pending sentinel; its uploads stand as uncited generations    *)
(* the next barrier adopts, exactly as a fenced barrier's do.  The syncer  *)
(* emits no trace event for this, only prose (`Publish honor failed`).     *)
AbandonBarrier(s) ==
  /\ AbandonOnStoreError /\ BarrierLease
  /\ Running(s) /\ sc[s].pc # "idle"
  /\ sc' = FencedSc(s)
  /\ gh' = [gh EXCEPT !.abandoned = 1]
  \* Holding the cell, the failed barrier hands it back; the failure can
  \* equally happen BEFORE the claim (an upload the store refused), and
  \* then there is nothing to release.
  /\ IF cellHolder = s /\ ~cellReleased
     THEN ReleaseCell /\ window' = 0
     ELSE UNCHANGED leaseVars /\ UNCHANGED window
  /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects,
                 inbox, removals, hitlAcked, conflicts>>

CASMiss(s) ==
  /\ Running(s) /\ CASReady(s)
  /\ IF FenceAfterLoad THEN ~Fenced(s) ELSE Verified(s)
  /\ manSeq # sc[s].expSeq
  /\ IF DeposedHolder(s)
     THEN \* the 412 handler re-reads the cell and discovers deposal
       /\ sc' = FencedSc(s)
       /\ gh' = [gh EXCEPT !.stragglerCas = @ + 1,
                           !.abandoned = IF BarrierLease THEN 1 ELSE @]
       /\ UNCHANGED <<window, conflicts>>
       /\ UNCHANGED leaseVars
     ELSE IF MergeCapable
     THEN \* refresh the token and retry as a three-way merge
       /\ sc' = [sc EXCEPT ![s].expSeq = manSeq]
       /\ UNCHANGED <<window, conflicts, gh>>
       /\ UNCHANGED leaseVars
     ELSE \* the whole-rewrite writer: re-seed and FAIL the barrier;
          \* the next barrier overwrites from the local walk.  Tranche 6:
          \* a commit that fails for a non-fence reason RELEASES.
       /\ sc' = [sc EXCEPT ![s].expSeq = manSeq, ![s].pc = "idle",
            ![s].scanU = {}, ![s].scanD = {},
            ![s].scanGen = [p \in Paths |-> 0],
            ![s].upDone = {}, ![s].parked = {}, ![s].gcDone = {}, ![s].gcTook = {},
            ![s].gcHeaded = {}, ![s].gcSeen = [p \in Paths |-> 0],
            ![s].retire = [p \in Paths |-> 0], ![s].upGone = {}, ![s].upVerified = FALSE,
            ![s].adopted = {}]
       /\ window' = 0
       /\ UNCHANGED <<conflicts, gh>>
       /\ IF BarrierLease THEN ReleaseCell ELSE UNCHANGED leaseVars
  /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 hitlAcked>>

CASInstall(s) ==
  /\ ~GatedCitation          \* gated replaces this with CitePassStep
  /\ Running(s) /\ CASReady(s)
  /\ IF FenceAfterLoad THEN ~Fenced(s) ELSE Verified(s)
  /\ CommitLoadsCurrent \/ manSeq = sc[s].expSeq
  \* Handles: the commit has re-read its own uploads first (VerifyUploads).
  /\ ImmutableObjects => sc[s].upVerified
  /\ LET
       \* Merge semantics: base = instBase (the last-installed view), mine
       \* = the scan-time walk, theirs = the current bucket manifest.  The
       \* merge STARTS FROM THEIRS (untouched paths keep theirs' entry —
       \* writing the walk view instead betrays a foreign entry one
       \* barrier after preserving it, once Finish absorbs it into the
       \* base).  A foreign change (theirs # base) is PRESERVED —
       \* including over a local delete (delete/modify resolves
       \* conservative).  The REPAIR arm re-cites an object this syncer
       \* integrated (consume advanced baseline past the citation),
       \* guarded on the object still holding that generation — the
       \* implementation's citation-repair with its HEAD guard.
       \* An entry this incarnation RECOGNIZES is not a foreign change,
       \* whatever the merge base says.  Step 7 rewrites the merge base
       \* AND the baseline, so a restart between the manifest CAS and
       \* step 7 leaves both behind — and our own freshly installed
       \* entry then reads as somebody else's change at the next merge.
       \* delete/modify resolves conservatively, so the agent's delete
       \* is dropped from the boundary it is about to be acked for, and
       \* the path is queued into the inbox as a phantom conflict
       \* nobody else ever touched.  TLC found this in shipped code.
       \*
       \* `known` stands for two witnesses the implementation already
       \* has and neither of which step 7 can lose: the entry's `epoch`
       \* is the publishing writer's LEASE EPOCH, which is ours across
       \* a container restart (a HITL write carries 0, a successor a
       \* higher one); and the entry's etag can equal what our own
       \* baseline holds for the path.  Two routes, and the model
       \* produced one counterexample for each.
       foreign(p) == ForeignEntry(s, p)
       repair(p) == RepairOwed(s, p)
       \* The same candidate with its HEAD guard failed: the key moved past
       \* what this writer integrated.  The code declines silently ("the
       \* next consume reconciles it"); recorded for the ack's judgement.
       declined(p) == RepairDeclined(s, p)
       \* ...except where the decline is only the MOVE, at the destination
       \* of a rename still waiting at its source (L-119).  That adoption
       \* is PENDING, not gone: its entry leaves this barrier's consumed
       \* set HERE, at the CAS that declined it — before the collector,
       \* which spares what an entry it did not consume names, and before
       \* the window clear, which drops what it did.  The code does the
       \* same, filtering `consumed` on the way out of its CAS loop.
       pendingNow == {pr \in sc[s].consumed : PendingAdoption(s, pr[1])}
       \* Tranche 6: an adopted entry is re-verified HERE, under the
       \* lease — the object must still hold the bytes the adopt found.
       \* If it does not, another writer's GC took it between the adopt
       \* and this CAS; the entry is withheld like a parked one and the
       \* path stays dirty for the next barrier to re-upload.
       \*
       \* Finding 13: an upload that LANDED is no safer.  The other
       \* writer's GC deletes If-Match an etag it recognises, and a real
       \* etag is the content hash — identical bytes PUT by this writer
       \* carry it too (`AgentWriteSame`).  So every citation this
       \* commit adds is re-verified, not only the adopted ones.
       gone == IF ImmutableObjects THEN sc[s].upGone ELSE
               {p \in sc[s].adopted :
                  VerifyAdoptedCitations /\ objects[p] # sc[s].scanGen[p]}
               \cup
               {p \in (sc[s].scanU \cap sc[s].upDone) \ sc[s].adopted :
                  /\ BarrierLease /\ VerifyUploadedCitations
                  /\ objects[p] # sc[s].scanGen[p]}
       \* Handles: the conflict record for a withheld upload names the
       \* handle the sweep took; the slot named the foreign object.
       goneRec == IF ImmutableObjects THEN {<<p, sc[s].scanGen[p]>> : p \in gone}
                  ELSE {<<p, objects[p]>> : p \in gone}
       \* Handles, rule 5: a path this commit uploaded whose citation moved
       \* past what it integrated — a peer's publish it never consumed (the
       \* UI write's entry left the cell before this barrier's consume, or
       \* the peer's own edit).  The shipped arm met this at the PUT: the
       \* slot's If-Match failed, and under Upload412Preserves the foreign
       \* version was surfaced and superseded knowingly.  A fresh handle has
       \* no slot to fail on, so the CAS — the one place the citation is
       \* read — takes the same decision: the foreign handle is SURFACED
       \* (the record is the preserved copy; the handle outlives the CAS
       \* for the fetch, the collector runs after) and the upload is cited
       \* over it.  The first HitlOverAny run under handles had no such
       \* step: an acked write a peer had published was cited over blind,
       \* at depth 18.  ~CommitSurfacesForeign is that shape.
       \* ...an upload OR a citation repair: the code's merge surfaces every
       \* upsert it publishes over a version the tree never integrated (the
       \* rename world's eighth box run found the model surfacing uploads only).
       published == (sc[s].scanU \cap sc[s].upDone) \cup {q \in Paths : repair(q)}
       \* R7's own filter, and it is NOT `foreign`: the code's merge
       \* reports everything it publishes over (`overridden`), and the
       \* CALLER surfaces the ones it never integrated — per path, by the
       \* CURRENT baseline (`barrier.rs`: `baseline.entries.get(path).key
       \* == was.key`).  A version this tree holds at this path needs no
       \* record; every other one does.
       contested == IF ImmutableObjects /\ CommitSurfacesForeign
                    THEN {p \in published \ gone :
                            /\ foreign(p) /\ manifest[p] # 0
                            /\ manifest[p] # sc[s].baseline[p]}
                    ELSE {}
       surfaced == {<<p, manifest[p]>> : p \in contested}
       inst == [p \in Paths |->
         IF p \in sc[s].parked \cup gone THEN manifest[p]
         ELSE IF p \in sc[s].scanU \cap sc[s].upDone THEN sc[s].scanGen[p]
         ELSE IF repair(p) THEN sc[s].baseline[p]
         ELSE IF foreign(p) THEN manifest[p]
         ELSE IF p \in sc[s].scanD THEN 0
         ELSE IF MergeCapable THEN manifest[p]  \* start-from-theirs
         ELSE sc[s].scanGen[p]]                 \* whole-rewrite walk view
       \* Under the liveness abstraction the seq saturates (see the
       \* constant): with nothing to merge the token is never contended.
       \* Tranche 7: a merge equal to theirs installs NOTHING — no CAS, so
       \* no seq, no stamp, and the budget does not bind.
       nothing == EmptyInstall /\ inst = manifest
       seq2 == IF InfiniteBarriers \/ nothing THEN manSeq ELSE manSeq + 1
       foreignQ ==
         IF MergeCapable /\ InboxEnabled /\ ~WriterQueue
         THEN {<<p, manifest[p]>> : p \in
                {q \in Paths :
                   /\ q \notin sc[s].parked \cup (sc[s].scanU \cap sc[s].upDone)
                   /\ foreign(q)
                   /\ manifest[q] # 0}}
         ELSE {}
       inbox2 == inbox \cup foreignQ
       \* An install amputates when it drops the last tracked reference to
       \* an acked generation the installer NEVER LEARNED (pr[2] \notin
       \* known).  A syncer that consumed the write and then published a
       \* delete of it speaks for the workspace — that is integration
       \* followed by ordinary editing, not amputation.
       amp == \E pr \in hitlAcked :
                /\ (manifest[pr[1]] = pr[2]) \/ (pr \in inbox)
                /\ inst[pr[1]] # pr[2]
                /\ pr \notin inbox2
                /\ pr \notin conflicts
                /\ pr \notin surfaced
                /\ pr[2] \notin sc[s].known
       cite == \E pr \in hitlAcked : inst[pr[1]] = pr[2]
       dropped == IF AckHonest THEN {p \in sc[s].scanD : inst[p] # 0}
                  ELSE sc[s].citeDropped
       \* Review 2026-09-18, H10: an install whose barrier began after the
       \* consume (a consume needs `pc = "idle"`, so a pending live here was
       \* consumed before this barrier's own) carries the declaration, and
       \* says so in the journal write that follows its CAS.  A commit that
       \* installed nothing made no CAS and carries nothing.
       carrying == /\ AckFromCarrier /\ SentinelEnabled /\ PendLive(s)
                   /\ ~nothing
     IN
       /\ manSeq < MaxSeq \/ InfiniteBarriers \/ nothing
       /\ manifest' = inst
       /\ manSeq' = seq2
       /\ manSrc' = IF nothing THEN manSrc ELSE InstallSource(s)
       /\ inbox' = inbox2
       /\ window' = 0
       \* A withheld adoption leaves the path dirty (upDone loses it, so
       \* Finish does not advance its baseline) and a record behind.
       /\ sc' = [sc EXCEPT ![s].pc = "cased",
                           ![s].upDone = @ \ gone,
                           \* A delete the merge outranked (foreign(p) is
                           \* tested before scanD in `inst`): the install
                           \* still cites the path, so this boundary does
                           \* not carry the agent's delete.  The syncer's
                           \* `BarrierReport.outranked`; the 2026-09-14 box run
                           \* found the ok ack over it (Inv_AckImpliesCited,
                           \* depth 20).
                           ![s].citeDropped = dropped,
                           ![s].carryPaths = IF carrying
                                             THEN @ \cup sc[s].scanU \cup sc[s].scanD
                                             ELSE @,
                           ![s].carryDropped = IF carrying THEN @ \cup dropped ELSE @,
                           ![s].instSnap = inst, ![s].instSeq = seq2,
                           ![s].jSeq = seq2,
                           \* Handles: what this install stopped citing,
                           \* read from the document it merged onto — the
                           \* code's step 6 reads `current` the same way.
                           ![s].retire = IF ImmutableObjects
                                         THEN [p \in Paths |->
                                                 IF manifest[p] # 0 /\ inst[p] # manifest[p]
                                                 THEN manifest[p] ELSE 0]
                                         ELSE @,
                           ![s].instSrc = IF ~BarrierLease THEN @
                                          ELSE IF nothing THEN manSrc
                                          ELSE InstallSource(s),
                           \* Tranche 7: the other writers' changes go to
                           \* THIS writer's queue, deletions included, in
                           \* the step that moves the merge base past them
                           \* (the code journals them with the CAS and
                           \* queues them at step 7; a restart between
                           \* re-queues from the journal).
                           ![s].fq = IF WriterQueue
                                     THEN QueueUpsert(@, MergeForeign(s) \cup MergeGone(s))
                                     ELSE @,
                           \* Review 2026-09-18, H1: what the peer's delete
                           \* retired — the merge base's citation for the
                           \* path — travels with the tombstone.
                           ![s].fqRetired = IF WriterQueue
                                            THEN [p \in Paths |->
                                                    IF p \in GonePaths(s)
                                                    THEN Retired(s, p) ELSE @[p]]
                                            ELSE @,
                           ![s].noInst = nothing,
                           ![s].consumed = @ \ pendingNow,
                           ![s].repairMoved = IF BarrierLease
                                              THEN {p \in Paths : declined(p)}
                                              ELSE {}]
       /\ conflicts' = conflicts \cup goneRec \cup surfaced
       /\ gh' = [gh EXCEPT
            !.emptyInstalls = IF nothing THEN 1 ELSE @,
            \* L-119's non-vacuity: the world REACHED a pending adoption.
            !.pendingKept = @ + Cardinality(pendingNow),
            !.adoptWithheld = IF gone \cap sc[s].adopted # {} THEN 1 ELSE @,
            !.uploadWithheld = IF gone \ sc[s].adopted # {} THEN 1 ELSE @,
            \* Finding 13's second route: a peer's PUT If-Match the same etag
            \* landed over our identical-bytes upload and the peer COMMITTED
            \* it; citing ours now replaces a citation the key holds with one
            \* it does not, and the peer's committed bytes go uncited.
            !.staleOverride = @ \/
               (BarrierLease /\ ~ImmutableObjects /\ \E p \in (sc[s].scanU \cap sc[s].upDone) \ gone :
                  /\ objects[p] # sc[s].scanGen[p]
                  /\ objects[p] # 0
                  /\ manifest[p] = objects[p])
               \* Handles: the same override read at the CAS — this commit
               \* cites its upload over a citation it never integrated, and
               \* no record says so.  Written only under ~CommitSurfacesForeign.
               \* ...and it asks R7's question, not the merge's: a version
               \* the tree HOLDS at that path is no override, recorded or
               \* not.  `contested` carries the same filter, so under
               \* `CommitSurfacesForeign` this never fires and under the
               \* mutation it fires for exactly the unrecorded overrides.
               \/ (ImmutableObjects /\ \E p \in published \ gone :
                     /\ foreign(p) /\ manifest[p] # 0
                     /\ manifest[p] # sc[s].baseline[p]
                     /\ p \notin contested),
            !.amputated = @ \/ amp,
            \* Review 2026-09-18, H1: a delete this writer PUBLISHES retires
            \* the generation it uncites.  WriterQueue only, so every
            \* earlier state space is preserved by construction (the
            \* resurrection needs the queue's tombstone to be superseded).
            \* A delete another writer has ALREADY contested — its tree is
            \* dirty at the path, or its upload of it is in flight — is not
            \* recorded: that writer's commit re-citing the generation is
            \* modify-wins at the merge, not a resurrection (the C2 control
            \* world found this: a same-bytes upload landed before the
            \* delete's CAS and was cited after it).
            \* H1e: the document names what each delete retired, until the
            \* path is cited again.
            !.tomb = IF ManifestTombstones
                     THEN [p \in Paths |->
                             IF inst[p] # 0 THEN 0
                             ELSE IF manifest[p] # 0 THEN manifest[p]
                             ELSE @[p]]
                     ELSE @,
            !.retired = IF WriterQueue
                        THEN [p \in Paths |->
                                IF /\ p \in sc[s].scanD /\ inst[p] = 0 /\ manifest[p] # 0
                                   \* ...and not by the publisher's own agent either:
                                   \* a re-creation between the scan and the CAS is
                                   \* a write the next barrier will publish.
                                   /\ sc[s].local[p] = 0
                                   /\ ~\E t \in Syncers \ {s} :
                                        \/ p \in Dirty(t) \/ p \in sc[t].scanU
                                        \* ...or holds a generation of p it
                                        \* integrated (a consumed UI write)
                                        \* and has not cited yet: its repair
                                        \* is the modify in delete/modify,
                                        \* and modify wins — the acked write
                                        \* survives, the agent's delete is
                                        \* lost (the README's Crash1 stance).
                                        \* ...unless what it holds IS the
                                        \* generation this delete retires:
                                        \* then it integrated the current
                                        \* citation early, through an entry
                                        \* that was already redundant, and
                                        \* modified nothing.  H1b's no-crash
                                        \* variant hid behind the clause as
                                        \* first written.
                                        \/ /\ sc[t].baseline[p] # sc[t].instBase[p]
                                           /\ sc[t].baseline[p] # manifest[p]
                                THEN manifest[p] ELSE @[p]]
                        ELSE @,
            !.cited = IF cite THEN 1 ELSE @,
            !.citedPairs = @ \cup {pr \in hitlAcked : inst[pr[1]] = pr[2]},
            \* Handles: a writer that INTEGRATED an acked write (its baseline
            \* holds it) and now publishes its own edit or delete of the path
            \* has retired it — integration followed by ordinary editing.  The
            \* slot expressed this by being overwritten; a handle is not, so
            \* the decision is stamped here (the first handles run of the
            \* queue world found the gap: a consumed-then-deleted UI write
            \* left as garbage with no decision recorded).
            !.hitlRetired = @ \cup (IF ImmutableObjects
                                    THEN {<<p, sc[s].baseline[p]>> :
                                            p \in {q \in sc[s].scanU \cup sc[s].scanD :
                                                     /\ sc[s].baseline[q] # 0
                                                     /\ sc[s].baseline[q] \in sc[s].known
                                                     /\ inst[q] # sc[s].baseline[q]}}
                                    ELSE {}),
            !.stragglerCas = @ + (IF DeposedHolder(s) THEN 1 ELSE 0),
            !.stragglerInstalls = @ + (IF DeposedHolder(s) THEN 1 ELSE 0)]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, objects, hitlAcked, removals>>

(* Step 7: rewrite the baseline, clear the barrier state.  The baseline
   advances ONLY for keys whose bytes this syncer integrated (its own
   uploads and its own landed deletes) — never for merge-preserved
   foreign entries, whose bytes arrive at the next Consume.  known
   likewise never absorbs cited-but-unintegrated generations.           *)
Finish(s) ==
  /\ Running(s) /\ sc[s].pc = "cased"
  /\ DeletesAfterCAS => sc[s].scanD \subseteq sc[s].gcDone
  \* Handles: the retired set is collected before the barrier ends (GCCollect
  \* is the code's step 6; it needs no lease, but it is this barrier's work).
  /\ ImmutableObjects => \A p \in Paths : sc[s].retire[p] = 0
  /\ sc' = [sc EXCEPT ![s].pc = "idle",
       \* A barrier that BEGAN after the consume has now completed: this
       \* is the only thing that entitles an ok ack (D2's uniform rule).
       ![s].honored = IF SentinelEnabled /\ PendLive(s) THEN TRUE ELSE @,
       \* Tranche 7: a commit that installed nothing marks no boundary of
       \* its own (`note_boundary` is skipped), so its ack names no clock.
       ![s].installed = ~sc[s].noInst, ![s].noInst = FALSE,
       ![s].baseline = [p \in Paths |->
         IF p \in sc[s].scanU \cap sc[s].upDone THEN sc[s].scanGen[p]
         ELSE IF /\ p \in sc[s].scanD /\ sc[s].instSnap[p] = 0
                 /\ (~BaselineKeepsUncollected \/ p \in sc[s].gcTook)
              THEN 0
         \* L-125 (2026-09-24): a DECLARED removal whose delete the merge
         \* outranked -- the tree has left the version it named, so the
         \* newer one adopts at a clean path (`barrier.rs` step 7).
         ELSE IF /\ OutrankedRemovalLeavesBaseline
                 /\ p \in sc[s].scanD \cap sc[s].declared /\ sc[s].instSnap[p] # 0
              THEN 0
         ELSE @[p]],
       ![s].instBase = sc[s].instSnap,
       ![s].surfaced = @ \ ((sc[s].scanU \cap sc[s].upDone)
                            \cup {p \in sc[s].scanD : sc[s].instSnap[p] = 0}),
       ![s].judged = [p \in Paths |->
         IF p \in sc[s].scanU \cup sc[s].scanD \/ sc[s].instSnap[p] = sc[s].baseline[p]
         THEN 0 ELSE @[p]],
       ![s].expSeq = sc[s].instSeq,
       \* The baseline records the walk's stat for what was cited.  A
       \* same-bytes rewrite AFTER the scan is absorbed here — an
       \* under-approximation, named: the next barrier's own
       \* `AgentWriteSame` reaches the same upload.
       ![s].touched = @ \ (sc[s].scanU \cap sc[s].upDone),
       ![s].scanU = {}, ![s].scanD = {},
       ![s].scanGen = [p \in Paths |-> 0],
       ![s].upDone = {}, ![s].parked = {}, ![s].gcDone = {}, ![s].gcTook = {},
       ![s].gcHeaded = {}, ![s].gcSeen = [p \in Paths |-> 0],
       ![s].upGone = {}, ![s].upVerified = FALSE,
       ![s].adopted = {},
       ![s].declared = {}, ![s].consumed = {}]
  \* The window clear's CAS: what this barrier integrated leaves the
  \* cell now, after the manifest cites it — the consumed entries and
  \* the performed removals.  A PENDING adoption's entry is not among
  \* them: the CAS dropped it from `consumed` when it declined to cite
  \* it for the move alone (L-119), so it stays in the cell for the
  \* barrier that can cite it.
  /\ inbox' = inbox \ sc[s].consumed
  /\ removals' = removals \ sc[s].declared
  /\ gh' = [gh EXCEPT !.done = IF InfiniteBarriers THEN @ ELSE @ + 1,
       !.orphanAt = IF OrphanEntryCited
                    THEN [p \in Paths |->
                            IF \E g \in Gens : <<p, g>> \in (inbox \ sc[s].consumed)
                            THEN @[p] ELSE 0]
                    ELSE @]
  \* Tranche 6: the RELEASE is the last step of the commit section, so a
  \* crash anywhere between the CAS and here leaves the cell HELD by a
  \* dead holder — the deposal's whole subject.  A holder deposed after
  \* its CAS landed releases nothing: the cell is the successor's.
  /\ IF BarrierLease /\ ~Deposed(s) THEN ReleaseCell ELSE UNCHANGED leaseVars
  /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects,
                 window, hitlAcked, conflicts>>

------------------------------------------------------------------------------
(* TRANCHE 6: the per-barrier lease — the cell as a FIFO ticket.           *)
(*                                                                          *)
(* Protocol of record: the writer-lease design §4 and the lease-v2 note.    *)
(* The cell is FRESH, HELD(holder, epoch, waiters) or RELEASED(last holder, *)
(* epoch, waiters, handoff).  A barrier claims AFTER its uploads and        *)
(* releases after its baseline; between barriers nobody holds anything.    *)
(* The abstractions are the life lease's: the 60 s quiet rule on a holder   *)
(* and the 20 s rule on a handoff are each ONE action enabled when the      *)
(* party is stalled or dead (the poll protocol itself is checked in         *)
(* flint's FlintTierEpoch.tla).                                             *)

(* The claim.  Three arms in one action — fresh, released-and-mine, and    *)
(* the DEPOSAL of a quiet holder — because they are one CAS on one object  *)
(* and differ only in whether the manifest is rotated: a released cell is  *)
(* a clean handoff, a deposal is the straggler fence (unchanged).  The     *)
(* window opens HERE, at the claim, not at the scan.                        *)
Claim(s) ==
  /\ BarrierLease /\ Running(s) /\ WantsCell(s)
  /\ ClaimEnabled(s)
  /\ LET deposal == CellHeld /\ cellHolder # s
         handoff == cellReleased /\ cellHandoff = s
         e == IF ClaimMintsEpoch THEN NextEpoch
              ELSE IF cellEpoch = 0 THEN 1 ELSE cellEpoch
     IN
       /\ (deposal /\ Rotation => manSeq < MaxSeq)
       /\ cellEpoch' = e /\ cellHolder' = s
       /\ cellReleased' = FALSE /\ cellHandoff' = "none"
       /\ cellQueue' = Without(cellQueue, s)
       /\ window' = e
       /\ manSeq' = IF deposal /\ Rotation THEN manSeq + 1 ELSE manSeq
       /\ manSrc' = IF deposal /\ Rotation THEN "none" ELSE manSrc
       /\ sc' = [sc EXCEPT ![s].pc = "claimed",
                          ![s].epoch = IF ClaimStampsEpoch THEN e ELSE @]
       /\ gh' = [gh EXCEPT !.claimed = @ \cup {s},
                           !.handoffs = IF handoff THEN 1 ELSE @,
                           !.deposals = @ + (IF deposal THEN 1 ELSE 0)]
  /\ UNCHANGED <<manifest, objects, inbox, removals, hitlAcked, conflicts>>

(* A syncer that cannot claim takes a ticket: one CAS-append, only if     *)
(* absent.  A separate action so the queue is observable.  A waiter that  *)
(* was dropped as a quiet handoff and then thawed re-queues from here.     *)
Enqueue(s) ==
  /\ BarrierLease /\ Running(s) /\ WantsCell(s)
  /\ ~ClaimEnabled(s) /\ ~SkipEnabled(s)
  /\ sc[s].pc = "scanned" \/ ~InQueue(s)
  /\ cellQueue' = IF InQueue(s) THEN cellQueue ELSE Append(cellQueue, s)
  /\ sc' = [sc EXCEPT ![s].pc = "waiting"]
  /\ gh' = [gh EXCEPT !.enqueues = 1]
  /\ UNCHANGED <<cellEpoch, cellHolder, cellHandoff, cellReleased,
                 manSeq, manSrc, manifest, objects, inbox, removals, window,
                 hitlAcked, conflicts>>

(* The handoff is quiet (crashed, or frozen): after two polls anybody may *)
(* acquire the released cell and the named waiter is dropped.  Without    *)
(* this a crashed waiter wedges the cell for every survivor, forever.     *)
SkipDeadHandoff(s) ==
  /\ BarrierLease /\ Running(s) /\ WantsCell(s)
  /\ SkipEnabled(s)
  /\ LET e == NextEpoch IN
       /\ cellEpoch' = e /\ cellHolder' = s
       /\ cellReleased' = FALSE /\ cellHandoff' = "none"
       /\ cellQueue' = Without(cellQueue, s)
       /\ window' = e
       /\ sc' = [sc EXCEPT ![s].pc = "claimed",
                          ![s].epoch = IF ClaimStampsEpoch THEN e ELSE @]
       /\ gh' = [gh EXCEPT !.claimed = @ \cup {s}, !.deadSkips = 1]
  /\ UNCHANGED <<manSeq, manSrc, manifest, objects, inbox, removals,
                 hitlAcked, conflicts>>


------------------------------------------------------------------------------
(* TRANCHE 2: the sync verb (v1, HITL) x the barrier.                       *)
(*                                                                          *)
(* Harness-invoked, never background, serialized against this syncer's own *)
(* barrier (hence pc = "idle").  Sync BEGINS WITH A FULL SCAN: "locally     *)
(* dirty" means dirty per THAT scan against the baseline, never per the     *)
(* last barrier's snapshot — otherwise sync honors a remote delete (or      *)
(* fetches a remote edit) over the agent's un-scanned latest work, which is *)
(* steady-state destruction of live work by the verb itself.  Policy:       *)
(* locally-dirty wins; remote changes apply only to locally-clean paths;    *)
(* every skipped apply is a surfaced conflict, never silent.                *)

Sync(s) ==
  /\ SyncEnabled
  /\ Running(s) /\ sc[s].pc = "idle"
  /\ gh.syncs < MaxSyncs
  \* The agent's scope (D4).  A whole-tree sync is the shipped verb and
  \* is modelled as scope = Paths; the sentinel's scoped form lets TLC
  \* choose any proper non-empty subset, which is stronger than fixing
  \* one — the loss this product exists to catch depends on WHICH path
  \* is left out.
  /\ \E scope \in (IF SyncScope
                   THEN {sub \in SUBSET Paths : sub # {} /\ sub # Paths}
                   ELSE {Paths}) :
     LET
       \* Ground truth, independent of the arm under test.
       trueDirty == Dirty(s)
       \* What THIS arm believes is dirty.
       dirt == IF SyncScanFirst THEN trueDirty ELSE sc[s].lastDirty
       \* Remote truth = the manifest, overlaid by live inbox entries (a
       \* HITL write no barrier has re-cited yet is still remote truth).
       remote(p) == IF ImmutableObjects THEN TrackedOrCited(p)
                    ELSE IF \E pr \in inbox : pr[1] = p /\ objects[p] = pr[2]
                    THEN objects[p] ELSE manifest[p]
       changed == {p \in Paths : remote(p) # sc[s].instBase[p]}
       \* Out-of-scope remote changes are NOT integrated and NOT
       \* advanced: they stay foreign and reach this workspace through
       \* the normal merge -> inbox -> consume path at the next barrier.
       deferred == changed \ scope
       applicable == (changed \ dirt) \cap scope
       conflicted == (changed \cap dirt) \cap scope
       \* Which paths this sync is ENTITLED to advance the merge base
       \* for: the ones it applied, plus the ones it verified unchanged.
       \* A conflicted path is deliberately NOT advanced — its local
       \* bytes won, and the remote generation is still owed to us.
       advanced == applicable \cup (Paths \ changed)
       \* Paths whose manifest version the overlay HID from this sync.
       hidden == {p \in Paths : remote(p) # manifest[p]}
       keep(p) == SyncKeepsHiddenBase /\ p \in hidden
       newInstBase ==
         IF SyncScope /\ ScopedInstBase
         THEN [p \in Paths |->
                IF p \in advanced /\ ~keep(p) THEN manifest[p] ELSE sc[s].instBase[p]]
         ELSE [p \in Paths |-> IF keep(p) THEN sc[s].instBase[p] ELSE manifest[p]]
       \* THE LOSS STAMP.  The merge base moved for a path this sync
       \* neither applied nor surfaced a conflict for, and whose bytes
       \* we do not hold: we have just claimed to have integrated a
       \* generation we never saw.  `foreign(p)` is FALSE at every
       \* subsequent merge, so it is never queued again — silent and
       \* permanent.
       lost == \E p \in Paths :
                 /\ p \notin applicable
                 /\ p \notin conflicted
                 /\ newInstBase[p] # sc[s].instBase[p]
                 /\ sc[s].baseline[p] # remote(p)
       \* A DESTROYING apply: the path was TRULY dirty, sync moved its
       \* local content anyway (a remote fetch or a remote-delete), and
       \* no conflict was surfaced for it.  Under SyncScanFirst this is
       \* unreachable by construction; under the refuted arm it is the
       \* review's finding.
       destroys == \E p \in applicable :
                     /\ p \in trueDirty
                     /\ remote(p) # sc[s].local[p]
     IN
       /\ sc' = [sc EXCEPT
            ![s].local = [p \in Paths |->
              IF p \in applicable THEN remote(p) ELSE @[p]],
            ![s].baseline = [p \in Paths |->
              IF p \in applicable THEN remote(p) ELSE @[p]],
            ![s].instBase = newInstBase,
            ![s].fq = IF QueueYieldsToSync
                      THEN {pr \in @ : ~(/\ newInstBase[pr[1]] # sc[s].instBase[pr[1]]
                                         /\ newInstBase[pr[1]] # pr[2])}
                      ELSE @,
            ![s].touched = @ \ applicable,
            ![s].known = @ \cup {remote(p) : p \in applicable},
            ![s].lastDirty = {}]
       /\ conflicts' = conflicts \cup {<<p, remote(p)>> : p \in conflicted}
       /\ gh' = [gh EXCEPT !.syncs = @ + 1,
            !.syncApplied = @ + Cardinality(applicable),
            !.syncConflicts = @ + Cardinality(conflicted),
            !.syncDestroyed = @ \/ destroys,
            !.scopedDeferrals = @ + (IF SyncScope THEN Cardinality(deferred) ELSE 0),
            !.deferredPaths = @ \cup (IF SyncScope THEN deferred ELSE {}),
            !.foreignLost = @ \/ lost]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked>>

------------------------------------------------------------------------------
(* TRANCHE 3, PRODUCT 2: gated manifest advance — durability split from     *)
(* visibility (boundary-verbs D6/D7/D8/D13).                                *)
(*                                                                          *)
(* Two lanes instead of one fused barrier:                                  *)
(*   - the UPLOAD LANE puts in place, minting a new VERSION and citing       *)
(*     nothing.  The cited generation survives as a noncurrent version —     *)
(*     that is the premise the whole design rests on, and it is what makes   *)
(*     `objects[p]` (what the key reads as) a different question from        *)
(*     `versions[p]` (what is still fetchable).                              *)
(*   - the CITATION LANE installs the entire pending set in ONE CAS, then    *)
(*     applies the withheld deletes and runs the EXACT version reaper.       *)
(*                                                                          *)
(* The lane opens no HITL window; window open/clear belong to the citation.  *)
(* Modelled abstractions, named rather than assumed: the citation and its    *)
(* reaper are one step (the real code holds the HITL window across both, so  *)
(* no foreign write can interleave), and the four citation SOURCES collapse  *)
(* to nondeterminism — a citation is enabled whenever the stage is           *)
(* non-empty, which is strictly more permissive than any of them.            *)

Staged(s) == {p \in Paths : stage[s][p] # 0}

\* D7's re-validation: a staged entry is still installable only if the
\* baseline it staged against has not moved under it.
(* Which staged entries this citation may install.
   D7 ALSO specifies a base-version re-validation — drop a staged entry
   whose BASELINE moved under it.  That guard is deliberately NOT modelled
   as an arm, because the model showed it is UNREACHABLE given the lane's
   own discipline: the lane never advances the baseline, so a staged path
   is by construction locally-dirty, and every route that could move a
   baseline (consume, sync) refuses dirty paths and surfaces a conflict
   instead.  It stays in the implementation as defence in depth; what the
   model says is that it is not what protects anything today, and the
   hazard it was written for arrives by a route it cannot see. *)
Valid(s) ==
  IF CiteDropsInflightHitl
  THEN {p \in Staged(s) : ~\E pr \in inbox : pr[1] = p}
  ELSE Staged(s)

(* The upload lane.  Same guard chain as Upload — If-Match on the
   recognized baseline, AdoptOwn on a known ETag, park on a foreign one —
   but the PUT lands as a new VERSION and no manifest CAS runs.          *)
StagePut(s, p) ==
  /\ GatedCitation
  /\ Running(s) /\ sc[s].pc = "scanned"
  /\ p \in sc[s].scanU \ (sc[s].upDone \cup sc[s].parked)
  /\ ~(EpochCheck /\ Deposed(s))
  /\ LET cur == objects[p]
         want == sc[s].scanGen[p]
     IN
       IF cur = sc[s].baseline[p]
       THEN
         /\ objects' = [objects EXCEPT ![p] = want]
         /\ versions' = [versions EXCEPT ![p] = @ \cup {want}]
         /\ stage' = [stage EXCEPT ![s] = [@ EXCEPT ![p] = want]]
         /\ stageBase' = [stageBase EXCEPT ![s] = [@ EXCEPT ![p] = cur]]
         /\ sc' = [sc EXCEPT ![s].upDone = @ \cup {p}]
         /\ gh' = [gh EXCEPT !.staged = @ + 1,
                     !.deposedPuts = @ + (IF Deposed(s) THEN 1 ELSE 0)]
         /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, inbox, removals,
                        window, withheldDel, hitlAcked, conflicts>>
       ELSE IF cur \in sc[s].known /\ cur = want
       THEN \* our own crashed/torn earlier PUT of THESE bytes: adopt the
            \* current version as the staged one.  The equality matters
            \* and the model was coarser than the code without it —
            \* `upload_one`'s 412 arm adopts only when the object's CRC
            \* is the CRC of the body it is uploading, and otherwise
            \* SUPERSEDES it knowingly (the arm below).  Adopting any
            \* recognized generation stages bytes the agent has already
            \* replaced, which reads as a boundary that lost the
            \* agent's declared write — a counterexample the
            \* implementation cannot produce.
         /\ stage' = [stage EXCEPT ![s] = [@ EXCEPT ![p] = cur]]
         /\ stageBase' = [stageBase EXCEPT ![s] = [@ EXCEPT ![p] = cur]]
         /\ sc' = [sc EXCEPT ![s].upDone = @ \cup {p}]
         /\ gh' = [gh EXCEPT !.adoptOwn = @ + 1]
         /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects,
                        versions, inbox, removals, window, withheldDel, hitlAcked,
                        conflicts>>
       ELSE IF cur \in sc[s].known
       THEN \* our own earlier PUT, OLDER content: supersede it knowingly
            \* (If-Match on what we recognize), which is what the shipped
            \* arm does rather than citing the stale generation.
         /\ objects' = [objects EXCEPT ![p] = want]
         /\ versions' = [versions EXCEPT ![p] = @ \cup {want}]
         /\ stage' = [stage EXCEPT ![s] = [@ EXCEPT ![p] = want]]
         /\ stageBase' = [stageBase EXCEPT ![s] = [@ EXCEPT ![p] = cur]]
         /\ sc' = [sc EXCEPT ![s].upDone = @ \cup {p}]
         /\ gh' = [gh EXCEPT !.adoptOwn = @ + 1,
                     !.deposedPuts = @ + (IF Deposed(s) THEN 1 ELSE 0)]
         /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, inbox, removals,
                        window, withheldDel, hitlAcked, conflicts>>
       ELSE \* foreign ETag: park and surface; never overwrite.
         /\ sc' = [sc EXCEPT ![s].parked = @ \cup {p}]
         /\ conflicts' = conflicts \cup {<<p, cur>>}
         /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects,
                        versions, inbox, removals, window, stage, stageBase,
                        withheldDel, hitlAcked, gh>>

StagePutFenced(s) ==
  /\ GatedCitation
  /\ Running(s) /\ sc[s].pc = "scanned"
  /\ EpochCheck /\ Deposed(s)
  /\ sc[s].scanU \ (sc[s].upDone \cup sc[s].parked) # {}
  /\ sc' = [sc EXCEPT ![s].st = "dead"]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, versions,
                 inbox, removals, window, stage, stageBase, withheldDel, hitlAcked,
                 conflicts, gh>>

(* The lane ends.  Deletes are WITHHELD — a rename r->s must not become
   reader-visible as r-gone/s-absent at a point nobody declared.

   ...and a withheld delete CANCELS any version this stage was still
   holding for that path.  The stage and the tombstone set carry no
   ordering between them, so a citation handed both installs one by
   accident of merge order: the shipped merge applied deletes last
   (right for create-then-delete, which amputates a re-created file),
   and making upserts win instead cites a file the agent deleted.  Only
   the lane knows which it saw last, so the lane is where they cancel.
   TLC found this the first time the sentinel and the citation lane ran
   in one world — against a fix two hours old.                          *)
LaneDone(s) ==
  /\ GatedCitation
  /\ Running(s) /\ sc[s].pc = "scanned"
  /\ sc[s].scanU \subseteq (sc[s].upDone \cup sc[s].parked)
  /\ withheldDel' = [withheldDel EXCEPT ![s] = @ \cup sc[s].scanD]
  /\ stage' = [stage EXCEPT ![s] =
       [p \in Paths |-> IF LaneCancelsStaged /\ p \in sc[s].scanD THEN 0 ELSE @[p]]]
  /\ stageBase' = [stageBase EXCEPT ![s] =
       [p \in Paths |-> IF LaneCancelsStaged /\ p \in sc[s].scanD THEN 0 ELSE @[p]]]
  /\ sc' = [sc EXCEPT ![s].pc = "laneDone"]
  /\ gh' = [gh EXCEPT !.withheld = @ + Cardinality(sc[s].scanD \ withheldDel[s])]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, versions,
                 inbox, removals, window, hitlAcked, conflicts>>

(* No coherent point is due: the tick ends with the bytes DURABLE and the
   manifest un-advanced, and the pending set survives to the next lane.
   This is the mode working, and it is the state every invariant in this
   product has to hold in.                                              *)
LaneOnly(s) ==
  /\ GatedCitation
  /\ Running(s) /\ sc[s].pc = "laneDone"
  /\ sc[s].citeDone = {}
  /\ window' = 0
  /\ sc' = [sc EXCEPT ![s].pc = "idle",
       ![s].scanU = {}, ![s].scanD = {},
       ![s].scanGen = [p \in Paths |-> 0],
       ![s].upDone = {}, ![s].parked = {}, ![s].gcDone = {}, ![s].gcTook = {}]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, versions,
                 inbox, removals, stage, stageBase, withheldDel, hitlAcked, conflicts,
                 gh>>

CiteFenced(s) ==
  /\ GatedCitation
  /\ Running(s) /\ sc[s].pc = "laneDone"
  /\ EpochCheck /\ Deposed(s)
  /\ Valid(s) \ sc[s].citeDone # {}
  /\ sc' = [sc EXCEPT ![s].st = "dead"]
  /\ gh' = [gh EXCEPT !.stragglerCas = @ + 1]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, versions,
                 inbox, removals, window, stage, stageBase, withheldDel, hitlAcked,
                 conflicts>>

(* THE citation.  Under AtomicCitation it installs the whole valid
   pending set in one CAS — the versions already exist, so there is no
   copy phase and no half-boundary.  Under the mutation TLC may install
   any non-empty subset, which is what a two-CAS design looks like from
   a reader's side.                                                     *)
CitePassStep(s) ==
  /\ GatedCitation
  /\ Running(s) /\ sc[s].pc = "laneDone"
  /\ ~(EpochCheck /\ Deposed(s))
  /\ manSeq = sc[s].expSeq
  /\ manSeq < MaxSeq
  /\ Valid(s) \ sc[s].citeDone # {}
  /\ \E sub \in SUBSET (Valid(s) \ sc[s].citeDone) :
       /\ sub # {}
       /\ AtomicCitation => sub = Valid(s) \ sc[s].citeDone
       /\ LET \* §2.4.2's ungated repair, in the lane that never had it.
              \* Same shape and same guard as the fused barrier's arm
              \* (`repair(p)`, in Finish): the object must still hold
              \* the generation this workspace integrated, or the
              \* citation would name bytes it never saw.
              repairG(p) ==
                /\ GatedRepair
                /\ p \notin sub
                /\ sc[s].baseline[p] # sc[s].instBase[p]
                /\ objects[p] = sc[s].baseline[p]
              inst == [p \in Paths |->
                IF p \in sub THEN stage[s][p]
                ELSE IF repairG(p) THEN sc[s].baseline[p]
                ELSE manifest[p]]
              \* This citation names a generation OTHER than the acked
              \* user bytes the key currently holds, and says nothing
              \* about it.  Not "the agent integrated the user's bytes
              \* and then edited" — `known` exempts that case throughout
              \* this model — but work that PREDATES the user's write
              \* winning against it.  Two arms reach it, and each has its
              \* own guard: the write was consumed after we staged (D7's
              \* base re-validation), or it is still in flight in the
              \* inbox (the window the lane deliberately does not open).
              staleWin == \E p \in sub :
                /\ <<p, objects[p]>> \in hitlAcked
                /\ objects[p] # stage[s][p]
                /\ <<p, objects[p]>> \notin conflicts
              forced == \E p \in sub : sc[s].local[p] # stage[s][p]
          IN
            /\ manifest' = inst
            /\ manSeq' = manSeq + 1
            /\ manSrc' = InstallSource(s)
            /\ sc' = [sc EXCEPT ![s].citeDone = @ \cup sub,
                                ![s].expSeq = manSeq + 1,
                                ![s].instSnap = inst,
                                ![s].instSeq = manSeq + 1,
                                ![s].jSeq = manSeq + 1]
            /\ gh' = [gh EXCEPT
                 !.cites = @ + 1,
                 !.amputated = @ \/ staleWin,
                 !.forcedCites = @ + (IF forced THEN 1 ELSE 0),
                 !.citeSpan = IF Cardinality(sub) > @ THEN Cardinality(sub) ELSE @,
                 !.carriedCite = @ \/ (sc[s].stageCarried /\ Cardinality(sub) > 1),
                 !.stragglerCas = @ + (IF Deposed(s) THEN 1 ELSE 0),
                 !.stragglerInstalls = @ + (IF Deposed(s) THEN 1 ELSE 0)]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, objects, versions, inbox, removals, window,
                 stage, stageBase, withheldDel, hitlAcked, conflicts>>

(* The citation completes: withheld deletes land WITH it, the EXACT
   version reaper runs, the baseline advances, the window clears.

   The reaper is flint's own and it is the ONLY reaper that can tell
   cited from uncited.  Lifecycle cannot do this job on `files/`: gated
   staging makes the cited version noncurrent the moment a newer
   generation is staged, so a NoncurrentVersionExpiration rule runs a
   clock against live cited data and never reaches the newest uncited
   bytes, which are current.  That inversion is BackstopExpire.         *)
CiteFinish(s) ==
  /\ GatedCitation
  /\ Running(s) /\ sc[s].pc = "laneDone"
  /\ sc[s].citeDone # {} /\ sc[s].citeDone = Valid(s)
  \* Two different questions, and the shipped code answers them in two
  \* different places: may this boundary UNCITE the path (the manifest
  \* CAS — yes, the agent deleted it), and may it DELETE THE OBJECT (the
  \* GC, which HEADs first and refuses an etag it does not recognize).
  \* Guarding the uncite with the GC's guard, as this model did, means a
  \* foreign write to a path the agent deleted keeps the path CITED —
  \* and an ok ack for a boundary that declared it gone.  TLC reported
  \* that as a defect; the defect was in the model.
  /\ LET uncite == {p \in withheldDel[s] :
                      /\ manifest[p] # 0
                      /\ p \notin sc[s].citeDone}
         dels == {p \in uncite : ~GuardedGC \/ objects[p] \in sc[s].known}
         man2 == [p \in Paths |-> IF p \in uncite THEN 0 ELSE manifest[p]]
         obj2 == [p \in Paths |-> IF p \in dels THEN 0 ELSE objects[p]]
         \* The reaper runs over the paths this citation INSTALLED and
         \* keeps what the INSTALLED DOCUMENT cites — never the writer's
         \* own idea of what it cited.
         scope == sc[s].citeDone
         \* ...plus the CURRENT version, unconditionally.  If current is
         \* not what we just cited then a foreign write landed between
         \* the lane and this citation: live bytes somebody is about to
         \* read, not a generation this workspace superseded.  THE MODEL
         \* FOUND THIS — the rule without this clause deleted an acked
         \* HITL write in shipped code.
         current(p) == IF GCKeepsCurrent /\ obj2[p] # 0 THEN {obj2[p]} ELSE {}
         ver2 == [p \in Paths |->
                    IF p \in scope /\ man2[p] # 0
                    \* FAIL CLOSED: if the installed manifest names no
                    \* version for this path we do not know what is
                    \* cited, and "delete everything unrecognized" would
                    \* reap live data.  Reclaim nothing.
                    THEN (versions[p] \cap {man2[p]}) \cup current(p)
                    ELSE versions[p]]
         dropped == Staged(s) \ Valid(s)
     IN
       /\ manifest' = man2
       /\ objects' = obj2
       /\ versions' = ver2
       /\ stage' = [stage EXCEPT ![s] = [p \in Paths |-> 0]]
       /\ stageBase' = [stageBase EXCEPT ![s] = [p \in Paths |-> 0]]
       /\ withheldDel' = [withheldDel EXCEPT ![s] = @ \ uncite]
       /\ window' = 0
       \* A dropped staged generation is never silently forgotten.
       /\ conflicts' = conflicts \cup {<<p, sc[s].baseline[p]>> : p \in dropped}
       /\ sc' = [sc EXCEPT ![s].pc = "idle",
            ![s].honored = IF SentinelEnabled /\ PendLive(s) THEN TRUE ELSE @,
            ![s].installed = TRUE,
            \* Which paths this boundary does NOT carry.  Kept apart
            \* from `conflicts` on purpose: a conflict record is the
            \* ack's `report.parked` in the FUSED path, which is why
            \* BoundaryBroken exempts it — a correspondence the gated
            \* honor cannot maintain, because the drop happens inside
            \* the citation and the honor writes one ack for the lot.
            ![s].citeDropped = dropped,
            ![s].citeDone = {}, ![s].stageCarried = FALSE,
            ![s].instBase = man2,
            ![s].judged = [p \in Paths |->
              IF p \in sc[s].citeDone \/ p \in uncite \/ man2[p] = sc[s].baseline[p]
              THEN 0 ELSE @[p]],
            ![s].baseline = [p \in Paths |->
              IF p \in sc[s].citeDone THEN stage[s][p]
              ELSE IF p \in uncite THEN 0
              ELSE @[p]],
            ![s].known = @ \cup {stage[s][p] : p \in sc[s].citeDone},
            ![s].scanU = {}, ![s].scanD = {},
            ![s].scanGen = [p \in Paths |-> 0],
            ![s].upDone = {}, ![s].parked = {}, ![s].gcDone = {}, ![s].gcTook = {},
            ![s].declared = {}, ![s].consumed = {}]
       /\ inbox' = inbox \ sc[s].consumed
       /\ removals' = removals \ sc[s].declared
       /\ gh' = [gh EXCEPT !.done = @ + 1,
            !.orphanAt = IF OrphanEntryCited
                         THEN [p \in Paths |->
                                 IF \E g \in Gens : <<p, g>> \in (inbox \ sc[s].consumed)
                                 THEN @[p] ELSE 0]
                         ELSE @,
            !.gc = @ + Cardinality(dels),
            !.gcCited = @ + Cardinality(dels),
            !.reaped = @ + Cardinality(UNION {versions[p] \ ver2[p] : p \in Paths}),
            !.cited = IF \E pr \in hitlAcked : man2[pr[1]] = pr[2]
                      THEN 1 ELSE @,
            !.citedPairs = @ \cup {pr \in hitlAcked : man2[pr[1]] = pr[2]},
            !.declaredDrops = @ + (IF SentinelEnabled /\ PendLive(s)
                                   THEN Cardinality(dropped \cap sc[s].pendDirty)
                                   ELSE 0)]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, hitlAcked>>

(* The noncurrent-retention BACKSTOP.  It is not the reaper and it must
   never be creditable for the reaper's work: on `files/` it cannot tell
   cited from uncited, so when a workspace is abandoned mid-stage it
   reaps the CITED (now noncurrent) version while the uncited current
   one survives.  The manifest then dangles — checkout refuses rather
   than serving a hole, and `recover-staged` re-cites the survivor
   FORWARD.  Enabling this action is a mutation, and the counterexample
   it must find IS the abandoned-mid-stage endgame.                     *)
BackstopExpire(p) ==
  /\ GatedCitation /\ BackstopEnabled
  /\ \E g \in versions[p] :
       /\ g # objects[p]          \* noncurrent only, exactly as S3
       /\ versions' = [versions EXCEPT ![p] = @ \ {g}]
  /\ gh' = [gh EXCEPT !.reaped = @ + 1]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, sc, stage, stageBase, withheldDel, hitlAcked,
                 conflicts>>

GatedNext ==
  \/ \E s \in Syncers, p \in Paths : StagePut(s, p)
  \/ \E s \in Syncers :
       StagePutFenced(s) \/ LaneDone(s) \/ LaneOnly(s) \/ CiteFenced(s)
       \/ CitePassStep(s) \/ CiteFinish(s) \/ CrashPodGated(s)
  \/ \E p \in Paths : BackstopExpire(p)

------------------------------------------------------------------------------
(* TRANCHE 3, PRODUCT 1: the boundary VERB x the barrier x the inbox.      *)
(*                                                                         *)
(* The agent declares a coherent point by touching `.flint/publish`; the   *)
(* syncer consumes it (rename into its own state dir), honors it with a   *)
(* real barrier, writes `.flint/publish.ack`, and retires the pending      *)
(* record.  Four steps, each of which a crash, a restart or a deposal can  *)
(* land between, and all of them racing the inbox and the manifest CAS.    *)
(*                                                                         *)
(* Modelled abstractions, named rather than assumed:                       *)
(*   - The two verbs collapse to ONE.  `sync` differs in what its honor    *)
(*     does (tranche 2/product 4 model that) and not in the consume /      *)
(*     honor / ack / retire protocol, which is what this product searches. *)
(*   - A touch id doubles as the nonce and as the sentinel's mtime clock:  *)
(*     ids are monotone, so "the ack's covered mtime is not older than the *)
(*     pending's" is implied by the nonce subset test in `AckMatches`.     *)
(*   - The bare touch (a sentinel with no nonce) is not modelled; every    *)
(*     touch carries one, which is what lets `pendN # {}` stand in for     *)
(*     "the pending file exists".  The torn-body rule is a battery leg.    *)
(*   - The min-interval and the hourly work budget are OUT of the safety   *)
(*     gate (the house rule for rate limiting): a deferred honor is        *)
(*     modelled as a later honor, which is strictly more permissive.       *)
(*   - The refusal (write the refused ack, retire, flip the marker, exit)  *)
(*     is one step, as is the ack rename.  The crash point that matters —  *)
(*     between the ack and the retire — is modelled, because it is the one *)
(*     the retracted crash matrix got wrong.                               *)

(* The agent's declaration.  A second touch overwrites an unconsumed
   sentinel: one file, one body.  That is the agent's own doing and not
   an orphan — the protocol owes an ack for nonces it CONSUMED.         *)
Touch(s) ==
  /\ SentinelEnabled /\ Running(s)
  /\ gh.touches < MaxTouches
  /\ sc' = [sc EXCEPT ![s].sentTok = gh.touches + 1]
  /\ gh' = [gh EXCEPT !.touches = @ + 1]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts>>

(* The consume: rename the sentinel out of the agent's reach and FOLD it
   into the standing pending record (D2.1).  Folding rather than
   overwriting is the whole rule — a rename onto a live pending record
   clobbers its nonces, and the agents behind them wait forever.

   `honored` is cleared unconditionally: D1's guarantee is that the
   barrier which acknowledges a sentinel BEGINS ITS SCAN strictly after
   consuming it, so a barrier that completed before this consume
   entitles nothing.                                                    *)
TakeSentinel(s) ==
  /\ SentinelEnabled /\ Running(s)
  /\ sc[s].sentTok # 0
  /\ sc[s].pc = "idle"
  /\ LET t == sc[s].sentTok
         fold == FoldPending /\ PendLive(s)
     IN
       /\ sc' = [sc EXCEPT
            ![s].sentTok = 0,
            ![s].pendN = IF fold THEN @ \cup {t} ELSE {t},
            ![s].pendCov = sc[s].local,
            ![s].pendMint = gh.nextGen,
            ![s].pendDirty = Dirty(s),
            ![s].honored = FALSE,
            \* H10: the code matches the carrier on the pending record's
            \* covered mtime, which a fold moves.
            ![s].carryPaths = {}, ![s].carryDropped = {},
            ![s].owed = @ \cup {t}]
       /\ gh' = [gh EXCEPT !.coalesced = @ + (IF fold THEN 1 ELSE 0)]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts>>

(* Skip-on-no-diff (`barrier.rs`): nothing local to publish, no citation
   repair owed, and the remote manifest document where we left it — so
   every local byte is already cited and the barrier returns without a
   window, without a CAS, and without touching the manifest.
   §2.1 prescribes that a pending sentinel DEFEAT this fast path;
   §10.1 records why the shipped code deliberately does not (§7 prices a
   no-diff honor at one HEAD, and defeating it would cost a manifest CAS
   at up to 720/hour/workspace — the exact amplification the budget
   exists to prevent).  That deviation rests on an argument in a
   document.  `FastPathGuards` is that argument, machine-checked: with
   the guards on the strict runs must hold, and with the last two
   dropped the ack must be caught claiming a boundary that is not
   installed.                                                           *)
FastPathClean(s) ==
  /\ USet(s) = {} /\ DSet(s) = {}
  /\ DeclaredConfirmsAbsence => {p \in Dirty(s) : sc[s].local[p] = 0} = {}
  /\ (~FastPathGuards \/ \A p \in Paths : sc[s].baseline[p] = sc[s].instBase[p])
  /\ (~FastPathGuards \/ manSeq = sc[s].expSeq)

FastPath(s) ==
  \* Tranche 7: the shipped skip-on-no-diff runs on EVERY barrier, not only
  \* a sentinel honor — and it also requires that the consume took nothing
  \* from the shared inbox (`consumed.is_empty()`), stale entries included.
  /\ SentinelEnabled \/ (BarrierLease /\ EmptyInstall)
  /\ EmptyInstall => sc[s].consumed = {}
  /\ ~GatedCitation
  /\ Running(s) /\ sc[s].pc = "consumed"
  \* A no-diff pass IS a barrier tick and charges the barrier budget.
  \* Not bookkeeping: without it Consume -> FastPath -> Consume is a
  \* free cycle that consumes nothing, and the state graph's DIAMETER
  \* grows without bound (the pilot ran to depth 148 and 17M states
  \* before this line existed).
  /\ gh.barriers < MaxBarriers \/ InfiniteBarriers
  /\ FastPathClean(s)
  /\ sc' = [sc EXCEPT ![s].pc = "idle",
       ![s].honored = IF SentinelEnabled /\ PendLive(s) THEN TRUE ELSE @,
       \* No boundary was installed, so this honor stamps nothing.
       ![s].installed = FALSE,
       ![s].prevScan = IF DeclaredConfirmsAbsence /\ TwoScanDelete
                       THEN {q \in Paths : sc[s].local[q] # 0} ELSE @,
       ![s].lastDirty = IF SyncEnabled THEN {} ELSE @]
  /\ gh' = [gh EXCEPT !.barriers = IF InfiniteBarriers THEN @ ELSE @ + 1,
                      !.fastPaths = IF InfiniteBarriers THEN @ ELSE @ + 1,
                      !.fastHonor = @ \/ PendLive(s)]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts>>

(* Tranche 7: the PULL-ONLY boundary.  The barrier found nothing of its
   own to publish and the manifest moved (else the fast path took it), so
   the merge can only add nothing: queue the other writers' changes and
   take theirs as the merge base.  No claim, no window, no CAS — the code
   returns before its commit section, which is what took 65 of 191 claims
   out of the writers drill's cell queue.  A sentinel it honors is
   answered against theirs: the ack names `theirs.seq`.                  *)
PullOnly(s) ==
  /\ Running(s) /\ PullOnlyReady(s)
  /\ sc' = [sc EXCEPT ![s].pc = "idle",
       ![s].fq = QueueUpsert(@, MergeForeign(s) \cup MergeGone(s)),
       ![s].fqRetired = [p \in Paths |->
                           IF p \in GonePaths(s) THEN Retired(s, p) ELSE @[p]],
       ![s].instBase = manifest,
       ![s].expSeq = manSeq,
       ![s].instSnap = manifest, ![s].instSeq = manSeq, ![s].instSrc = manSrc,
       ![s].repairMoved = {p \in Paths : RepairDeclined(s, p)},
       ![s].citeDropped = IF AckHonest THEN {} ELSE @,
       ![s].honored = IF SentinelEnabled /\ PendLive(s) THEN TRUE ELSE @,
       ![s].installed = FALSE,
       ![s].scanU = {}, ![s].scanD = {},
       ![s].scanGen = [p \in Paths |-> 0],
       ![s].upDone = {}, ![s].parked = {}, ![s].gcDone = {}, ![s].gcTook = {},
       ![s].gcHeaded = {}, ![s].gcSeen = [p \in Paths |-> 0],
       ![s].retire = [p \in Paths |-> 0], ![s].upGone = {}, ![s].upVerified = FALSE,
       ![s].adopted = {},
       ![s].declared = {}, ![s].consumed = {}]
  /\ gh' = [gh EXCEPT !.pullOnlys = 1]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts>>

(* THE PROMISE, evaluated at the instant the ack is written and stamped
   into a ghost (the house's action-written rule).  D1: "everything
   ordered-before T is a coherent point; publish it", with the at-least
   guarantee stated at CONSUME time — so every path whose consume-time
   content is still the tree's content must be cited by the manifest the
   ack names.  Two exemptions, both of them the protocol working:

     - the AGENT itself moved the path after the consume, so its
       declared bytes are superseded rather than owed.  A DELETE is
       the case that needs this clause on its own: it supersedes
       without minting anything, so the watermark below cannot see it,
       and TLC's third counterexample was exactly an agent deleting
       its own declared file after declaring it.
     - the citation names a generation MINTED AFTER the declaration.
       D1's guarantee is at-LEAST: "the published state may include
       later bytes for a racing file, never earlier ones".  Stating the
       promise as snapshot equality is WRONG, and TLC said so on the
       first strict run of this product — its counterexample was an
       agent that deleted a path, declared, re-created it, let the
       barrier publish the re-creation, then deleted it again, so the
       consume-time snapshot matched the tree again at ack time while
       the manifest legitimately cited later bytes.  The mint watermark
       is what distinguishes "later" from "stale", and it is why
       `pendMint` exists.
     - the path carries a surfaced conflict record — it was answered
       loudly, which is `report.parked` in the ack the implementation
       writes.  "Never a silent winner" is the standing rule; a silent
       LOSER is what this invariant is looking for.

   The two exemptions overlap and neither subsumes the other, which is
   why both are here and each has a counterexample behind it: an agent
   can move a path away and back (write, delete, write) so that the
   tree matches the declaration again at ack time while the manifest
   legitimately cites later bytes — the watermark is what covers that —
   and it can supersede by deleting, which mints nothing at all — the
   tree comparison is what covers that.  What neither covers is an
   agent restoring byte-identical content, which this model cannot
   express (mints are unique) and a real filesystem can: ledger entry,
   and harmless, because the boundary then names bytes equal to the
   declared ones.

   Note what the conflict clause does NOT excuse: a citation of a
   generation minted BEFORE the declaration and different from the
   declared one is stale whichever direction it points — an unpublished
   write (manifest older than the agent's bytes) and an unpublished
   DELETE (the agent declared the path gone, the manifest still cites
   its old generation) are the same defect and the same test.          *)
BoundaryBroken(s) ==
  \E p \in sc[s].pendDirty :
    /\ AckedDoc(s)[p] # sc[s].pendCov[p]
    /\ AckedDoc(s)[p] < sc[s].pendMint
    /\ sc[s].local[p] = sc[s].pendCov[p]
    \* The conflict exemption reads the ack's `report.parked`.  A path
    \* the CITATION dropped is in no such field — the gated honor
    \* writes one ack for the whole boundary — so its record excuses
    \* nothing here.  That is the exemption holding the finding's own
    \* combined world vacuously green until it was narrowed.  Note the
    \* shape: the drop DEFEATS the exemption, it does not exclude the
    \* path from the search.  Writing it as a plain conjunct excuses
    \* exactly the case the clause exists to catch.
    /\ (p \in AckDropped(s) \/ ~\E pr \in conflicts : pr[1] = p)

(* The OTHER half of what an ok ack asserts, and it is not the same
   claim.  `BoundaryBroken` asks whether the agent's own declared work
   survived; this asks whether the point the ack names is a coherent
   one AT ALL: every generation this workspace has integrated — its
   persisted baseline, which includes the inbox writes it adopted and
   the foreign entries it merged — is cited by the manifest the ack
   points at.  When it is not, a reader resolving that manifest gets
   bytes this workspace has already superseded, and a re-checkout would
   MATERIALIZE them over the newer ones.

   This is what `repairs_pending` defends in the shipped fast path, and
   why the two halves need separate invariants: TLC's second
   counterexample was an inbox adoption whose citation repair was still
   owed — no work of the agent's was at risk, and the boundary was
   still not the point the ack claimed.  Parked paths are exempt:
   their conflict record is the ack's `report.parked`.               *)
BoundaryIncoherent(s) ==
  \E p \in Paths :
    /\ sc[s].baseline[p] # AckedDoc(s)[p]
    /\ ~\E pr \in conflicts : pr[1] = p
    \* Under the barrier lease a PEER's lease-free upload can supersede, at
    \* the key, a generation this writer integrated before its commit
    \* re-cited it, and the repair's HEAD guard then rightly declines.  The
    \* harm this stamp names cannot follow: a reader of the acked document
    \* is sent to a key that holds neither the superseded generation nor
    \* the cited one, so its conditional read fails into the NEWER object.
    \* Exempt exactly the paths the install declined for that reason, at
    \* that CAS — a repair skipped while the key still held the integrated
    \* generation (the fast-path finding) is not exempt.  The first run of
    \* the two-writer sentinel world with HitlOverwritesTrackedOnly found
    \* this in 16 steps (README, tranche 6).
    /\ p \notin sc[s].repairMoved
    \* Tranche 7, the third refinement: the acked document is AHEAD of the
    \* tree at p by exactly a change another writer made that waits in THIS
    \* writer's queue for its next consume.  A reader of that document gets
    \* the newer bytes, not bytes this workspace superseded, so the stamp's
    \* harm runs the other way (the 2026-09-13 box run's depth-19 trace).
    \* Only the queued generation is excused: the doc ahead by anything the
    \* queue does not hold still fires, and the QueueForeignChanges mutation
    \* is the run that proves it.
    /\ ~(WriterQueue /\ <<p, AckedDoc(s)[p]>> \in sc[s].fq)

AckOk(s) ==
  /\ SentinelEnabled /\ Running(s) /\ sc[s].pc = "idle"
  /\ PendLive(s) /\ ~AckMatches(s)
  /\ ~(RefuseOnFence /\ DeposedHolder(s))
  /\ (AckFromInstall => sc[s].honored)
  \* D1, at the one place a gated boundary can break it: a citation
  \* that dropped a declared path installed a point that does not
  \* carry it, and `ok` would assert the opposite.
  /\ (AckHonest => sc[s].pendDirty \cap AckDropped(s) = {})
  /\ sc' = [sc EXCEPT ![s].ackN = @ \cup sc[s].pendN, ![s].honored = FALSE,
       ![s].installed = FALSE, ![s].citeDropped = {}, ![s].carryPaths = {}, ![s].carryDropped = {}]
  /\ gh' = [gh EXCEPT
       !.acks = @ + 1,
       !.honors = @ + (IF sc[s].honored THEN 1 ELSE 0),
       !.ackAfterRestart = @ + (IF sc[s].pendReRun THEN 1 ELSE 0),
       !.ackEarly = @ \/ BoundaryBroken(s),
       !.ackIncoherent = @ \/ BoundaryIncoherent(s),
       !.fencedOkAck = @ \/ DeposedHolder(s),
       \* Only an ack that claims its OWN install can disagree with the
       \* stamp; an ack that installed nothing names no clock.
       \* Scoped to an honor that actually INSTALLED. A no-diff honor
       \* installs no boundary, so its ack names the VERB that ran while
       \* the stamp still names whoever last installed — two different
       \* questions, and only a real install owes them the same answer.
       \* (The first pilot conflated them and fired on correct code.)
       !.srcMismatch = @ \/ (sc[s].honored /\ sc[s].installed
                             /\ AckedSrc(s) # BoundaryClock(s))]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts>>

(* The honest answer when the boundary does not carry the declared
   point: the agent is still ANSWERED — a partial ack names the nonces
   and the dropped paths — but nothing claims the point landed.  An
   agent that treats it as failure and re-touches is behaving
   correctly, and the next boundary carries the path the ordinary way
   (the racing write is queued in the inbox; the lane consumes it, the
   local file is still dirty, and the conflict rule publishes it).

   `Inv_NoNonceOrphan` is what makes this an ANSWER rather than a
   silence, and it is checked over this action like any other.        *)
AckPartial(s) ==
  /\ SentinelEnabled /\ AckHonest /\ Running(s) /\ sc[s].pc = "idle"
  /\ PendLive(s) /\ ~AckMatches(s)
  /\ ~(RefuseOnFence /\ DeposedHolder(s))
  /\ sc[s].pendDirty \cap AckDropped(s) # {}
  /\ sc' = [sc EXCEPT ![s].ackN = @ \cup sc[s].pendN, ![s].honored = FALSE,
       ![s].installed = FALSE, ![s].citeDropped = {}, ![s].carryPaths = {}, ![s].carryDropped = {}]
  /\ gh' = [gh EXCEPT !.acks = @ + 1, !.partialAcks = @ + 1,
       \* H10's non-vacuity: the journalled carrier made this ack partial —
       \* the barrier's own drops alone would have said ok.
       !.carrierAck = @ \/ (sc[s].pendDirty \cap sc[s].citeDropped = {})]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts>>

(* Retire AFTER the ack rename.  Splitting these two is not ceremony:
   the crash between them is the one the draft's crash matrix answered
   wrongly, and it is the only reachable way to observe a pending record
   that a standing ack already answers.                                 *)
RetirePending(s) ==
  /\ SentinelEnabled /\ Running(s) /\ sc[s].pc = "idle"
  /\ PendLive(s) /\ AckMatches(s)
  /\ sc' = [sc EXCEPT ![s].pendN = {}, ![s].pendCov = NoPend,
       ![s].pendMint = 0, ![s].pendDirty = {},
       ![s].honored = FALSE, ![s].pendReRun = FALSE, ![s].carryPaths = {}, ![s].carryDropped = {}]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts, gh>>

(* D2's refused ack: deposal must never strand a waiting agent.  Write
   the refusal naming every covered nonce, retire, flip the marker, and
   exit fenced — one step here.                                         *)
AckRefused(s) ==
  /\ SentinelEnabled /\ Running(s)
  \* Tranche 6: no `refused-fenced` ack exists under the barrier lease —
  \* a fence abandons the barrier and the next one honors the record.
  /\ ~BarrierLease
  /\ PendLive(s) /\ RefuseOnFence /\ DeposedHolder(s)
  /\ sc' = [sc EXCEPT ![s].ackN = @ \cup sc[s].pendN,
       ![s].pendN = {}, ![s].pendCov = NoPend, ![s].pendMint = 0,
       ![s].pendDirty = {},
       ![s].honored = FALSE, ![s].pendReRun = FALSE, ![s].carryPaths = {}, ![s].carryDropped = {},
       ![s].st = "dead"]
  /\ gh' = [gh EXCEPT !.refusedAcks = @ + 1]
  /\ UNCHANGED leaseVars /\ UNCHANGED <<cellEpoch, cellHolder, manSeq, manSrc, manifest, objects, inbox, removals,
                 window, hitlAcked, conflicts>>

SentinelNext ==
  \E s \in Syncers :
    Touch(s) \/ TakeSentinel(s) \/ FastPath(s) \/ AckOk(s)
    \/ AckPartial(s) \/ RetirePending(s) \/ AckRefused(s)

------------------------------------------------------------------------------
------------------------------------------------------------------------------
(* Under gated, ANY action that moves an object mints a version: the
   bucket is versioned, so a PUT destroys nothing and a delete leaves
   every prior version fetchable (S3 writes a delete marker).  Composing
   this once at the Next level rather than threading it through twenty
   actions is also what keeps every pre-gated state space intact — with
   GatedCitation = FALSE, `versions` is frozen at Init and adds no
   distinct states at all.                                             *)
VersionsFollow ==
  IF GatedCitation
  THEN versions' = [p \in Paths |->
         IF objects'[p] = 0 THEN versions[p]
         ELSE versions[p] \cup {objects'[p]}]
  ELSE versions' = versions

(* Immutable handles: the actions that write the handle set themselves,
   composed OUTSIDE `VersionsFollow` (which would freeze it).            *)
ImmutableNext ==
  \/ \E s \in Syncers, p \in Paths : UploadIO(s, p)
  \/ \E p \in Paths : HitlWriteIO(p)
  \/ \E p, q \in Paths : HitlRenameIO(p, q)
  \/ \E s \in Syncers : VerifyUploads(s) \/ GCCollect(s)
  \/ \E s \in Syncers, p \in Paths, h \in Gens : SweepOrphan(s, p, h)

BaseNext ==
  \/ StartA
  \/ \E s \in Syncers : CrashPod(s) \/ Restart(s) \/ RenewDiscover(s)
  \/ StallA \/ ThawA \/ ClaimB \/ CheckoutB
  \/ \E s \in Syncers :
       StartLease(s) \/ Claim(s) \/ Enqueue(s) \/ SkipDeadHandoff(s)
  \/ \E s \in Syncers, p \in Paths :
       AgentWrite(s, p) \/ AgentWriteSame(s, p) \/ AgentDelete(s, p) \/ Upload(s, p)
       \/ GCDelete(s, p) \/ GCHead(s, p)
  \/ \E s \in Syncers : Narrow(s)
  \/ \E p \in Paths : HitlWrite(p) \/ HitlRemove(p) \/ TrackOrphan(p)
  \/ \E p, q \in Paths : HitlRename(p, q)
  \/ HitlRefused
  \/ \E s \in Syncers :
       LoadInbox(s) \/ Consume(s) \/ Scan(s) \/ UploadFenced(s) \/ GCDeleteFenced(s)
       \/ PreDeletesDone(s) \/ VerifyCell(s) \/ CASFenced(s) \/ CASMiss(s) \/ CASInstall(s)
       \/ Finish(s) \/ Sync(s) \/ PullOnly(s) \/ AbandonBarrier(s)
  \/ SentinelNext

Next ==
  \/ (BaseNext /\ VersionsFollow /\ UNCHANGED gatedVars)
  \/ GatedNext
  \/ (ImmutableNext /\ UNCHANGED gatedVars)

Spec == Init /\ [][Next]_vars

\* Gated mode is frozen and not supported under the barrier lease (design
\* §4.3, D3): its upload lane runs outside any barrier.
ASSUME ~(BarrierLease /\ GatedCitation)
\* `touched` is cleared where a barrier or a sync rewrites the baseline,
\* not at a narrow's uncite or a declared removal — keep them apart.
ASSUME MaxSameBytes > 0 => BarrierLease /\ MaxNarrows = 0 /\ MaxRemovals = 0
\* Tranche 7: the queue and the empty install are the barrier lease's code.
ASSUME WriterQueue => BarrierLease /\ MergeCapable /\ InboxEnabled
ASSUME EmptyInstall => WriterQueue
ASSUME ~QueueForeignChanges => WriterQueue
\* Review 2026-09-18: the tombstone's retired generation is the queue's.
ASSUME TombstoneNamesRetired => TombstoneHeadsKey /\ WriterQueue
\* Review 2026-09-18, H2: the shipped fence position is the barrier lease's.
ASSUME ~FenceAfterLoad => BarrierLease /\ EpochCheck
\* Immutable handles are the barrier lease's code, on the inbox, with the
\* deletes after the CAS; gated mode and the sweep's predecessor are gone
\* under them; a same-bytes write cannot alias a handle, so its budget is 0;
\* the narrow verb is not modelled over handles (its worlds are life-lease).
ASSUME ImmutableObjects =>
  /\ BarrierLease /\ InboxEnabled /\ DeletesAfterCAS /\ ~GatedCitation
  /\ ~OrphanTrack /\ MaxSameBytes = 0 /\ ~InfiniteBarriers

(* ---- tranche 6: FAIRNESS, for the liveness runs only -------------------
   Weak fairness on each syncer's OWN barrier step — not on "some syncer
   takes a step", which would let one writer discharge the other's
   obligation.  Under `Ticket` the queue head's claim is continuously
   enabled from the release until it fires, so WF is enough; under the
   mutation the claim is enabled only between one release and the next
   claim, WF asks nothing, and one writer claims forever.               *)
BarrierStep(s) ==
  \/ /\ \/ LoadInbox(s) \/ Consume(s) \/ Scan(s) \/ Claim(s) \/ Enqueue(s) \/ SkipDeadHandoff(s)
        \/ \E p \in Paths : Upload(s, p) \/ GCDelete(s, p) \/ GCHead(s, p)
        \/ PreDeletesDone(s) \/ CASMiss(s) \/ CASInstall(s) \/ Finish(s)
        \/ CASFenced(s) \/ VerifyCell(s) \/ GCDeleteFenced(s) \/ RenewDiscover(s) \/ PullOnly(s)
        \/ FastPath(s)
     /\ VersionsFollow /\ UNCHANGED gatedVars
  \* Immutable handles: the barrier's own steps that write the handle set.
  \/ /\ \/ \E p \in Paths : UploadIO(s, p)
        \/ VerifyUploads(s) \/ GCCollect(s)
     /\ UNCHANGED gatedVars

FairSpec == Spec /\ \A s \in Syncers : WF_vars(BarrierStep(s))

\* Every live writer that queued for the cell eventually holds it.  A
\* waiter that dies or freezes is released from the claim (a frozen
\* waiter needs `ThawA`, which is not fair, and a dead one needs nothing).
Waiting(s) == sc[s].pc = "waiting" /\ Running(s)
NoStarvation ==
  \A s \in Syncers : [](Waiting(s) => <>(Holding(s) \/ ~Running(s)))

------------------------------------------------------------------------------
(* Invariants *)

TypeOK ==
  /\ cellEpoch \in 0..EpochBound /\ cellHolder \in Syncers \cup {"none"}
  /\ cellQueue \in Seq(Syncers) /\ Len(cellQueue) <= Cardinality(Syncers)
  /\ \A i, j \in 1..Len(cellQueue) : cellQueue[i] = cellQueue[j] => i = j
  /\ cellHandoff \in Syncers \cup {"none"} /\ cellReleased \in BOOLEAN
  /\ manSeq \in 1..MaxSeq+1 /\ manSrc \in Sources
  /\ manifest \in [Paths -> Gens] /\ objects \in [Paths -> Gens]
  /\ inbox \subseteq (Paths \X Gens) /\ window \in 0..EpochBound
  /\ hitlAcked \subseteq (Paths \X Gens) /\ conflicts \subseteq (Paths \X Gens)
  /\ versions \in [Paths -> SUBSET Gens]
  /\ stage \in [Syncers -> [Paths -> Gens]]
  /\ stageBase \in [Syncers -> [Paths -> Gens]]
  /\ \A s \in Syncers : sc[s].scope \subseteq Paths /\ sc[s].prevScan \subseteq Paths
  /\ removals \subseteq Paths
  /\ \A s \in Syncers : sc[s].declared \subseteq Paths
                       /\ sc[s].consumed \subseteq (Paths \X Gens)
                       /\ sc[s].surfaced \subseteq Paths
                       /\ sc[s].repairMoved \subseteq Paths
                       /\ sc[s].touched \subseteq Paths
                       /\ sc[s].fq \subseteq (Paths \X Gens)
                       /\ \A x, y \in sc[s].fq : x[1] = y[1] => x = y
                       /\ sc[s].fqRetired \in [Paths -> Gens]
                       /\ sc[s].judged \in [Paths -> Gens]
                       /\ sc[s].carryPaths \subseteq Paths
                       /\ sc[s].verifiedAt \in 0..EpochBound
                       /\ sc[s].carryDropped \subseteq Paths
                       /\ sc[s].retire \in [Paths -> Gens]
                       /\ sc[s].upGone \subseteq Paths
                       /\ sc[s].upVerified \in BOOLEAN
  \* Handles: there is no slot, and nothing may write one.  A shipped-arm
  \* update that slipped past its `~ImmutableObjects` guard fails here.
  /\ ImmutableObjects => objects = [p \in Paths |-> IF p \in FreePaths THEN 0 ELSE 1]
  /\ gh.uiBase \subseteq (Paths \X Gens \X Gens)
  /\ gh.retired \in [Paths -> Gens]
  /\ gh.orphanAt \in [Paths -> Gens]
  /\ gh.tomb \in [Paths -> Gens]

\* §4.2: A NARROW IS AN UNWATCH, NEVER AN ABSENCE.  No path a narrow
\* dropped may lose its object — a workspace that stops holding a file
\* must not take the bucket's copy with it.  This is what the
\* unlink-first arm violates: the citation survives the unlink, the
\* next scan classifies the path delete-eligible, and GC publishes it.
Inv_NarrowNeverDeletes ==
  \* 2026-09-23: was `\A p \in gh.narrowed : the object at p lives`, which
  \* a PEER's legitimate delete of a path this writer narrowed violates
  \* (the handles narrow world, 14 steps: the collector takes what the
  \* peer's CAS retired).  Narrowing is one writer's scope, so the claim
  \* is that the narrowing writer never classifies such a path as a
  \* delete — which is how the unlink-first order destroyed it.
  gh.narrowDeleted = {}

\* The other half.  A narrowed path must not be re-uploaded and
\* re-cited BY THE WRITER THAT NARROWED IT (2026-09-23): narrowing is a
\* writer's scope, so a peer that still watches the path uploads it
\* legitimately; the stamp sites count only an upload of a path outside
\* the uploader's own scope (the handles narrow world found the global
\* form firing on a peer's edit in 8 steps).  Originally:
\* re-cited, which is what the uncite-first arm does: the file survives
\* the uncite, the next scan reads present-and-not-in-baseline as a
\* local ADD, and the barrier silently undoes the narrow.  A path the
\* agent legitimately re-creates leaves `gh.narrowed` at AgentWrite, so
\* this never fires on widening.
Inv_NarrowNeverRecites == gh.narrowRecited = {}

Inv_ConsumeNeverRegresses == ~gh.consumeRegressed

\* Non-vacuity: the verb actually fires.  Probed via a ghost only
\* Narrow writes — probe the ACTION, never the situation.
ProbeNarrow == gh.narrows = 0

\* An acked HITL write is never silently lost: its bytes are never
\* destroyed by a writer that did not legitimately learn them, and no
\* manifest install drops its last tracked reference without a conflict
\* record.  (Both stamp sites feed gh.amputated.)
Inv_HITLDurable == ~gh.amputated

\* Every cited manifest entry has a live object behind it: the barrier
\* order (uploads -> CAS -> deletes) keeps checkouts satisfiable.  On the
\* same-key shape the question is whether the KEY exists (its bytes may be
\* a later generation's: a UI write over a cited key is that shape's
\* accepted loss, `Inv_HITLTracked`'s subject, not a dangling citation).
\* Handles: the cited handle still exists at the path (the gated tranche's
\* `Inv_CitedVersionLives`, which is the same question asked of a
\* versioned substrate — and under handles the only question).
Inv_NoDangling == \A p \in Paths : manifest[p] # 0 =>
  IF ImmutableObjects THEN HoldsGen(p, manifest[p]) ELSE objects[p] # 0
\* No commit replaces a citation the key still holds with a generation of
\* its own upload the key no longer holds (finding 13's second route).
\* `Inv_NoDangling` cannot see it — an object exists — and the loss is the
\* PEER's: its committed bytes stay at the key, cited by nothing.
Inv_NoStaleOverride == ~gh.staleOverride

\* A deposed writer's manifest CAS never lands.
Inv_NoStragglerInstall == gh.stragglerInstalls = 0
\* Review 2026-09-18, H4: a declared removal removes the version it named.
Inv_RemovalNamesItsVersion == ~gh.removalOverreach

\* A deposed writer's data PUT never lands.
Inv_NoDeposedPut == gh.deposedPuts = 0

\* A container restart never resurrects an unpublished delete.
\* S4: a restart never republishes a delete the agent made.  An ACTION
\* property, not a stamp (H9, 2026-09-19): no step that is a restart creates
\* a local file — the checkout runs only on an empty tree, and a restart
\* over a live tree materialises nothing (`checkout.rs`).  The invariant it
\* replaces read a ghost written only under the mutation constant, so its
\* strict runs were tautologies; this one reads the step.  The rematerialise
\* mutation (LeanRematerialize) is the step that does, and must violate it.
NoResurrectionStep ==
  \A s \in Syncers, p \in Paths :
    (sc[s].local[p] = 0 /\ sc'[s].local[p] # 0) => gh'.restarts = gh.restarts
Prop_NoResurrection == [][NoResurrectionStep]_vars

\* The sync verb never destroys genuinely-dirty local work without
\* surfacing it (tranche 2).
Inv_SyncNeverDestroysDirty == ~gh.syncDestroyed

\* D4 (boundary-verbs plan §2.2).  A sync never advances the MERGE BASE
\* for a path it did not integrate and did not surface.  Violating this
\* is not a stale read — it is permanent: `foreign(p)` at every later
\* merge compares theirs against the base we just falsified, computes
\* "unchanged", and the entry is never queued into the inbox again.
Inv_NoForeignLost == ~gh.foreignLost

\* ---- tranche 3, product 2: version lifetime (D7/D8) ---------------------

\* ---- tranche 3, product 1: the boundary verb (D1/D2/D12) ----------------

\* THE invariant of this product.  An ok ack asserts that the coherent
\* point the agent declared is INSTALLED — not durable, not queued:
\* cited by the manifest, at the seq the ack names.  Stamped at the ack
\* rather than checked over states, because the promise is about the
\* instant the agent is told "done" and nothing later can un-tell it.
Inv_AckImpliesCited == ~gh.ackEarly

\* The second half, and the one the plan's draft called
\* `Inv_AckNotEarly`: the boundary an ok ack names is a coherent point,
\* citing every generation this workspace has integrated.  A citation
\* repair still owed at ack time means a reader — or this workspace's
\* own next checkout — resolves to bytes already superseded here.
Inv_AckBoundaryCoherent == ~gh.ackIncoherent

\* Every CONSUMED nonce is still named by something: the pending record
\* that will answer it, or the ack that already did (ok or refused).
\* Consuming is the commitment point — the rename takes the sentinel out
\* of the agent's reach, so nothing else can ever answer it.  Per
\* incarnation, because a pod replacement takes the agent and the tree
\* with the pending file.
Inv_NoNonceOrphan ==
  \A s \in Syncers : sc[s].owed \subseteq (sc[s].pendN \cup sc[s].ackN)

\* One boundary, ONE clock.  The agent reads the ack; the fleet reads the
\* manifest's stamp; an operator asking "did my agent's publish land, or
\* was that the floor?" is a different process from the agent, often in a
\* different cluster, and it has only the bucket to ask.  Shipped code
\* computed the two independently and they disagreed — with the bucket
\* holding the wrong one, which is the worse half.
\* Scoped to acks that claim their own install: a no-diff honor installs
\* nothing, and its ack is answering "your point is already true" rather
\* than naming a new boundary.
Inv_BoundaryNamesItsClock == ~gh.srcMismatch

\* A deposed incarnation never tells an agent its boundary landed.  The
\* plan calls this `Inv_RefusedNeverInstalled`; it is stated here as the
\* ack side, which is the side the agent reads and the only side a
\* fenced incarnation still controls.
Inv_NoFencedOkAck == ~gh.fencedOkAck

\* ---- tranche 6: the per-barrier lease -----------------------------------

\* D1, the safety half of the lease: ONE writer in the commit section at
\* a time.  A deposed straggler may still BELIEVE it is in its commit
\* section — that is what the fences are for — so the claim is over the
\* holders the cell still recognises.  True under the life lease too.
Inv_CommitExclusive ==
  \A s, t \in Syncers :
    (Holding(s) /\ Holding(t) /\ s # t) => (Deposed(s) \/ Deposed(t))

\* Model coherence, pinned so a wrong claim arm cannot hide: a HELD cell's
\* holder is in its commit section at the cell's epoch — alive, frozen or
\* dead there.  A restart releases, a failed commit releases, a fence
\* yields; nothing else may leave a held cell behind a syncer that is not
\* committing.
\* FINDING 10, as a CONVERGENCE property a safety run can check: once
\* nothing at all can move (every budget spent, every writer idle), each
\* object at a cited key is the citation or is tracked by the inbox — no
\* bytes are left that the manifest, a fresh checkout and the live trees
\* disagree about.  A pod replaced between its upload and its commit
\* violates it as shipped; `OrphanTrack` is the candidate fix.
\* "Nothing can move" is the SYNCERS' progress, not `Next`: an agent can
\* always delete a file, and a budget-bounded world ends with barriers, not
\* with agents.
SyncerProgress ==
  \/ \E s \in Syncers :
       \* A writer that has not started yet can still start: its first
       \* run of this check called that quiescence and reported a world
       \* whose only live writer had not checked out.
       \/ StartLease(s)
       \/ BarrierStep(s)
       \/ PullOnly(s) \/ FastPath(s) \/ TakeSentinel(s)
       \/ AckOk(s) \/ AckPartial(s) \/ RetirePending(s)
  \/ \E p \in Paths : TrackOrphan(p)
  \* Handles: a sweep still owed is progress, so quiescence means swept.
  \/ \E s \in Syncers, p \in Paths, h \in Gens : SweepOrphan(s, p, h)
Inv_QuiescentConverged ==
  ~ENABLED SyncerProgress =>
    \A p \in Paths :
      IF ImmutableObjects
      THEN \* Handles: once nothing can move, every live handle is cited by
           \* some path or named by some entry — a lost writer's uploads
           \* have been SWEPT, not adopted, and nothing is left that a
           \* checkout, the manifest and the trees could disagree about.
           \A g \in versions[p] :
             \E r \in Paths : SameHandle(p, r, g) /\ (manifest[r] = g \/ <<r, g>> \in inbox)
      ELSE
      \/ objects[p] = manifest[p]
      \/ objects[p] = 0
      \* An object at a key the manifest does not cite is garbage no
      \* checkout serves — a delete's CAS whose GC never ran (the crash
      \* between them) — a leak, not the disagreement this is about.
      \/ manifest[p] = 0
      \/ \E pr \in inbox : pr = <<p, objects[p]>>

\* Review 2026-09-18, H1b: A PEER'S PUBLISHED DELETE REACHES EVERY LIVE TREE.
\* Once nothing can move — and not because the barrier budget ran out — no
\* running writer keeps a CLEAN copy of a path the manifest no longer
\* cites.  A dirty copy is the agent's and publishes.  What it saw: a leaked
\* generation this tree never integrated superseded the tombstone (which
\* named the older one the tree had), and the clean copy stayed forever.
Inv_TreesConverged ==
  ~ENABLED SyncerProgress =>
    \A s \in Syncers : Running(s) =>
      \A p \in Paths :
        (/\ sc[s].local[p] # 0 /\ sc[s].local[p] = sc[s].baseline[p]
         /\ manifest[p] = 0
         \* ...and this writer has merged onto a manifest without the path
         \* (one that never ran a barrier after the delete is not stale, it
         \* is behind — the budget, not the protocol, stopped it).
         /\ sc[s].instBase[p] = 0)
          \* ...unless the writer still holds the work that removes it and
          \* the budget, not the protocol, is what stopped it: a queued
          \* deletion the next consume would apply (H1f: not one a leak
          \* would supersede again), or a repair it is owed (a consumed UI
          \* write not yet re-cited: modify wins, the copy is right to stay).
          => DeletionPending(s, p) \/ RepairOwed(s, p)

\* Review 2026-09-18, H1: A PUBLISHED DELETE STAYS PUBLISHED until somebody
\* writes the path again.  `gh.retired[p]` is the generation a writer's own
\* delete uncited at its CAS; every agent or UI write of p clears it.  A
\* manifest that cites that generation again with no write in between has
\* resurrected the delete.  A delete that was already contested when it
\* published — another writer dirty at the path, uploading it, or holding
\* an integrated, not-yet-cited generation of it (its repair is the
\* "modify" of delete/modify) — is not recorded: that writer's re-cite is
\* modify-wins, the acked write surviving over the agent's delete.  Stated over the
\* manifest and ONE history variable, not over the action that does it —
\* the collector-off flap
\* (a leaked object supersedes the peer's tombstone; the citation repair
\* re-cites what the baseline kept) is the route that found it, and it is
\* not the only one the predicate would catch.  Written only under
\* WriterQueue, where the tombstone exists.
Inv_NoDeleteResurrected ==
  \A p \in Paths : manifest[p] = 0 \/ manifest[p] # gh.retired[p]

Inv_CellHeldByHolder ==
  BarrierLease /\ CellHeld =>
    (Holding(cellHolder) /\ sc[cellHolder].epoch = cellEpoch)

------------------------------------------------------------------------------
(* Non-vacuity probes — each names an ACTION via a ghost that only that
   action writes, and TLC is REQUIRED to violate it (the A2 probe rule:
   probe the action, never the situation).                              *)

ProbeBarrierDone      == gh.done = 0
ProbeHITLCited        == gh.cited = 0
ProbeTakeover         == gh.takeovers = 0
ProbeStragglerAttempt == gh.stragglerCas = 0
ProbePark             == conflicts = {}
ProbeGC               == gh.gc = 0
ProbeRefusal          == gh.refusals = 0
ProbeAdoptOwn         == gh.adoptOwn = 0
ProbeRestart          == gh.restarts = 0
ProbeSyncApplied      == gh.syncApplied = 0
ProbeSyncConflict     == gh.syncConflicts = 0
\* Action-written (Sync's own ghost): a SCOPED sync actually deferred a
\* remote change, rather than the scoped arm never having fired.
ProbeScopedDeferral   == gh.scopedDeferrals = 0
\* U16, MEASURED AND OPEN (2026-08-26). This probe does NOT fire, and
\* that is the finding rather than a missing cfg. `gh.deferredPaths`
\* becomes non-empty (the deferral happens), but
\* `deferredPaths # {} /\ inbox # {}` is UNREACHABLE across the full
\* state space at MaxBarriers = 3 (6.2M states) and again at 4 (13.5M
\* states) — so the deferred path is never queued into the inbox while
\* the deferral stands, and no consume can integrate it.
\*
\* D4's loss-avoidance argument is precisely that the deferred entry
\* ARRIVES through merge -> inbox -> consume. `Inv_NoForeignLost` and
\* `ProbeScopedDeferral` are both stamps written INSIDE `Sync`: they
\* prove the deferral, never the arrival. So the model currently cannot
\* distinguish "deferred" from "lost", which is exactly what the review
\* alleged. NOT wired into check.sh: a must-fail run that does not fail
\* would turn the gate red over an unbuilt artifact rather than a
\* regression. The instrumentation stays because it is what a fix needs.
ProbeOutOfScopeLater  == gh.deferredLater = 0

\* ---- tranche 3, product 2 ------------------------------------------------
\* One CAS installed >= 2 paths from a pending set that had SURVIVED a
\* lane pass.  Both halves matter: without the size the split is
\* untested, and without the carry every citation might simply be
\* following its own lane, which is hybrid wearing gated's name.
\* A pod replacement actually happened IN THE GATED WORLD. Without this
\* the crash-matrix run is green over a state space that never crashed
\* — the vacuity that let MaxCrashes=0 stand in all 19 gated cfgs
\* while §10.1c deferred the citation's crash matrix to product 1,
\* whose own cfgs never crash either (review: U12).
ProbeGatedCrashReachable == gh.crashes = 0
\* U41: `Inv_NoResurrection` was listed as checked by LeanGatedHolds
\* while that cfg ran MaxRestarts = 0, and `Restart` is the ONLY writer
\* of the state the invariant tests — so the line read as coverage and
\* was unfalsifiable by construction. It matters here more than
\* anywhere: gated mode WIDENS the resurrection window, because a
\* delete stays cited until a citation, which is exactly the
\* local[p]=0 /\ manifest[p]#0 /\ baseline[p]#0 shape `res` tests.
\* Restarts are now ON in the gated world (127k states, 2 s), and this
\* is the probe that keeps the fix honest — without it, enabling the
\* knob and never reaching a restart would look identical.
ProbeGatedRestartReachable == gh.restarts = 0
ProbeCitationInstalled == ~gh.carriedCite
\* A delete was actually withheld from the manifest until a citation.
ProbeWithheldDelete    == gh.withheld = 0
\* U15: `ProbeWithheldDelete` counts `gh.withheld`, bumped in `LaneDone`
\* when a delete is WITHHELD — never in `CiteFinish` when it is APPLIED.
\* So `LeanGatedHolds` can hold with `dels = {}` at every citation, and
\* the delete-application half of the gated design — manifest entry
\* removed, object deleted, version reaped — is never shown reachable.
\* That is the one step where `Inv_CitedVersionLives` and
\* `Inv_NoUncitedGC` (the gated lane's invariants, retired 2026-09-19 with
\* it — H9) were most at risk, so its reachability is not something to
\* assume. `gcCited` is bumped ONLY by `CiteFinish`, so
\* unlike a `ProbeGC` re-run this cannot be satisfied by the cadence
\* GC path.
ProbeGatedGC           == gh.gcCited = 0
\* A citation actually fired mid-change (a staged path had already been
\* edited again locally) — the lag/backlog caps' shape, and the reason
\* the source is stamped bucket-visibly.
ProbeForcedCite        == gh.forcedCites = 0
\* REQUIRED-REACHABLE, deliberately.  §3 residual 11: a reader that does
\* not resolve through the manifest sees mid-logical-change bytes where
\* it previously saw the last boundary.  This probe proves the exposure
\* is PRESENT rather than assumed away — and a future design that
\* quietly closes it must fail this probe and force the residual to be
\* rewritten.  It names a state rather than an action on purpose: the
\* exposure IS a state, and there is no action that "does" it.
\* ---- tranche 3, product 1 ------------------------------------------------
\* An ack was actually written off a REAL barrier install (not merely
\* written): without this the strict runs could hold with the honor path
\* never having fired.
ProbeSentinelHonored == gh.honors = 0
\* The refusal fired: deposal answered a waiting agent.
ProbeRefusedAck      == gh.refusedAcks = 0
\* An ack was written for a pending record that SURVIVED A RESTART —
\* the uniform crash rule's own path, exercised.
ProbeAckAfterCrash   == gh.ackAfterRestart = 0
\* Two touches actually coalesced into one pending record.  Product 2's
\* lesson, applied: the orphan mutation checks a state space that never
\* contained two live nonces unless this fires.
ProbeCoalescedAck    == gh.coalesced = 0
\* A pending sentinel was honored by the SKIP-ON-NO-DIFF pass rather
\* than a full barrier.  This is what makes the FastPathGuards runs
\* non-vacuous: without it, "the fast path is sound" could hold because
\* the fast path never ran.
ProbeFastPathHonor   == ~gh.fastHonor

\* ---- tranche 3, product 1 x 2: the sentinel over the CITATION lane ------
\* A gated citation actually DROPPED a path the agent had declared.  The
\* honesty rule is vacuous without it: "an ok ack never claims a dropped
\* path" holds trivially in a world where nothing is ever dropped.
ProbeDeclaredDrop == gh.declaredDrops = 0
\* ...and the partial ack — the honest answer — actually fired, so the
\* agent is ANSWERED rather than left waiting on a boundary that will
\* never be claimed.
ProbePartialAck   == gh.partialAcks = 0

\* U20, OPEN (assessed 2026-08-26). This is a STATE PREDICATE over
\* `objects` vs `manifest`, not an action-written ghost — it breaks
\* this model's own house rule ("the probe names the ACTION, never the
\* situation") because there IS no reader action to name.
\*
\* §4 requires two that were never built: `PinnedReader` (with its own
\* invariant — never materializes post-boundary bytes under
\* pre-boundary citations) and `RawReader`, plus product 2's
\* `ProbeDanglingCitation`. The only reader in the module is the
\* checkout embedded in the barrier, which copies `manifest[p]` into
\* `local` without consulting `versions` or `objects` at all. So the
\* model cannot express the hazard D13 exists to prevent — a gated
\* checkout 412ing and S3-wins-adopting `current[p]` — nor the
\* endgame: after `BackstopExpire` reaps a cited version
\* `Inv_CitedVersionLives` fires, but nothing shows a checkout REFUSING
\* rather than serving a hole.
\*
\* Both are currently carried by the Rust battery
\* (`pinned_reads_never_adopts_current`, and as of 2026-08-26
\* `sync_under_pinned_reads_resolves_the_cited_version_not_the_current_one`)
\* and by drill legs B23/B24. That is real evidence, but it is not the
\* model, and §10.1c's "not modelled" list does not name the readers.
\* Building them is a tranche — a reader action over the `versions`
\* substrate plus an invariant — not a probe, and it is deliberately
\* NOT faked here with a predicate that would read as coverage.
ProbeRawReaderSeesUncited ==
  \A p \in Paths : objects[p] = manifest[p] \/ manifest[p] = 0

\* ---- tranche 5: DECLARED removals ----------------------------------------

\* Every acked HITL write is TRACKED by something in the world until it
\* is legitimately superseded or was once CITED: in the cell, surfaced
\* as a conflict, integrated into a LIVE incarnation's baseline, or
\* published in some generation — after which a later deletion is the
\* workspace's own editing (the crash between a delete's CAS and its
\* GC leaves an orphan object, not a lost write).  What the early drop
\* violated: consumed, then the pod replaced, and the write was acked,
\* durable, and known to nothing — never cited, never to be.
Inv_HITLTracked ==
  \A pr \in hitlAcked :
    \* Handles: a handle that is GONE is never an excuse on its own — nothing
    \* overwrites one, so "destroyed" is either the collector's decision
    \* (`hitlRetired`, stamped by GCCollect, a later UI write, a consume
    \* that saw it superseded) or a loss.
    \/ ~ImmutableObjects /\ objects[pr[1]] # pr[2]
    \/ manifest[pr[1]] = pr[2]
    \/ pr \in gh.citedPairs
    \/ pr \in inbox
    \/ pr \in conflicts
    \/ \E s \in Syncers : sc[s].st # "dead" /\ sc[s].baseline[pr[1]] = pr[2]
    \* RETIRED: a writer that had integrated these bytes took the path out
    \* of its boundary.  The first clause says that for unique generations
    \* whenever the object is actually destroyed — but "destroyed" is the
    \* wrong test twice over, which is why this clause exists and why it is
    \* written at the collector's DECISION:
    \*   * under MaxSameBytes an agent re-creating the write's exact bytes
    \*     carries the same generation, so the key reads as it again (TLC's
    \*     first same-bytes runs in BLWORLD stopped on exactly that twice);
    \*   * on a store with no conditional DELETE the collector GIVES WAY
    \*     (`CollectorOff`, `conformance.rs`) and the object is never
    \*     destroyed at all, so a write a published delete properly retired
    \*     would read as untracked forever.
    \/ pr \in gh.hitlRetired
    \* RECOVERABLE: the acked bytes are the object at a key the manifest
    \* cites.  That is exactly the untracked sweep's condition — it tracks
    \* an object at a CITED key whose etag the manifest does not cite, and
    \* passes over uncited keys — and exactly what a fresh checkout's
    \* S3-wins arm adopts.  So the write is reachable and will be
    \* integrated, not lost.  Gated on `OrphanTrack` because that is the
    \* mechanism: a world without the sweep has no such promise, and
    \* crediting a recovery that world cannot perform would be the
    \* relaxation this clause is trying not to be (SAFETY.md §4, the crash
    \* arm; `untracked.rs`, finding 10).
    \/ /\ OrphanTrack /\ ~ImmutableObjects
       /\ objects[pr[1]] = pr[2]
       /\ manifest[pr[1]] # 0

\* A rename that was PERFORMED is one manifest generation: no reader
\* of the manifest ever sees the moved BYTES under both names (§4, §6)
\* — the old name citing the generation that was moved while the new
\* name is cited.  A refused rename legitimately leaves both — an extra
\* file, never a hole (§5) — and an agent that re-creates the old name
\* after the unlink has made a NEW file, which is cited as its own.
\* Handles: the destination cites the SOURCE's handle, so the claim reads
\* "the same handle is never cited under both names".  The shipped form's
\* "the new name is cited by anything" is unreachable there — a rename lands
\* while another writer's create of the destination is in flight (the
\* gateway cannot see a handle nobody cites or tracks), the install cites the
\* agent's file, and the rename's entry is then a conflict, its source refused.
Inv_RenameAtomic ==
  \A r \in gh.renamed \ gh.renameRefused :
    ~(manifest[r[1]] = r[3] /\ (IF ImmutableObjects THEN manifest[r[2]] = r[4]
                                ELSE manifest[r[2]] # 0))

\* ...and never neither: the old name stays cited until the new name
\* has been cited (or is still tracked in the cell for the barrier
\* that will cite it).  Once the destination was cited, whatever the
\* workspace does to either name afterwards is its own editing.  A
\* REFUSED rename is answered, not performed: the source's fate is
\* then the agent's (it may have deleted it before the request even
\* arrived), and the copy survives under the conflict record.
Inv_RenameNoHole ==
  \A r \in gh.renamed \ gh.renameRefused :
    \/ manifest[r[1]] # 0
    \/ manifest[r[2]] # 0
    \/ <<r[2], r[4]>> \in gh.citedPairs
    \/ \E e \in inbox : e[1] = r[2]
    \* The copy was overwritten by a later write to the new name before
    \* any barrier cited it: that writer read the name, and the bytes
    \* it replaced are its to have replaced.
    \/ ~ImmutableObjects /\ objects[r[2]] # r[4]
    \* ...and the same case under handles, which the entry clause above
    \* was assumed to cover and does not.  A later write REPLACES the
    \* entry, so while the entry waits the clause holds — but once a
    \* writer has CONSUMED it the entry is gone, and if that writer's
    \* agent then deletes the path and publishes the delete, neither
    \* name is cited and nothing in the cell names the destination.
    \* That is not a hole: the human superseded the rename's own version
    \* at the destination, by hand, before any barrier cited it, and the
    \* delete after it is the agent's to make.  `hitlRetired` is the
    \* stamp for exactly "this acked version was retired KNOWINGLY" —
    \* by a later UI write at the same name, or by a tree that
    \* integrated it and then edited or deleted it.  A destination LOST
    \* (the crash the `RenameWaitsForDestination` mutation opens) is
    \* stamped by nobody, so `LeanRenameNoDestinationGuard` still
    \* violates this.  Found 2026-09-21 by `LeanImmutableRenameHolds` at
    \* depth 19, 108M states.
    \/ ImmutableObjects /\ <<r[2], r[4]>> \in gh.hitlRetired

\* Handles: one handle, one name — unconditionally, in every installed
\* document.  A performed rename drops the source in the generation that
\* cites the destination; a refused one leaves the destination a COPY under
\* moved OUT of the tree by the answered record (AnsweredRecordsApply,
\* L-117), and the moved entry never reaches a tree at the old name
\* (RenameMovesEntry); an adopter that never saw the
\* removal has its repair declined (MovedElsewhere — RepairRespectsMoves=FALSE
\* is the mutation).  The seed generation is one number at every path but a
\* handle at each (SameHandle), so only an aliased pair counts.
Inv_OneName ==
  ImmutableObjects =>
    \A p, q \in Paths :
      p # q /\ manifest[p] # 0 /\ manifest[p] = manifest[q] => ~SameHandle(p, q, manifest[p])

ProbeRemovalApplied == gh.removalsApplied = 0
ProbeRemovalRefused == gh.removalsRefused = 0
ProbeRenameApplied  == gh.renamesApplied = 0
\* L-119: a barrier declined an adoption for the move alone, at the
\* destination of a rename still waiting at its source, and left the entry
\* in the cell.  The rule's own reachability — the world that checks the
\* rule's absence (PendingAdoptionStays=FALSE) proves nothing unless the
\* shipped world reaches the rule at all.
ProbePendingKept == gh.pendingKept = 0

\* ---- tranche 6: the per-barrier lease -----------------------------------
\* REQUIRED-REACHABLE: an upload landed while the other writer was in
\* its commit section.  The house rule — never prove a guarantee by the
\* attack's absence: the lease's claim is that two writers OVERLAP and
\* only the commit serialises.  Written by Upload.
ProbeWritersInterleave == ~gh.interleaved
\* A claim by the syncer the release NAMED actually happened (Claim).
ProbeHandoffFired      == gh.handoffs = 0
\* A quiet holder in its commit section was deposed by the other writer
\* (Claim's deposal arm).
ProbeDeposalMidCommit  == gh.deposals = 0
\* A quiet handoff was skipped and the cell taken by a survivor.
ProbeDeadHandoffSkipped == gh.deadSkips = 0
\* A syncer actually queued for the cell — without this the strict runs
\* could hold with the ticket never exercised.
ProbeEnqueued          == gh.enqueues = 0
\* A fenced holder abandoned its barrier and KEPT RUNNING (a fence is
\* not a death).  Written only by the fence arms under BarrierLease.
ProbeFenceAbandoned    == gh.abandoned = 0
\* The fix actually fired: a CAS under the lease found an adopted object
\* gone and withheld the entry.  Without this the strict runs could hold
\* with the race never reached — which is exactly how it hid until now.
ProbeAdoptWithheld     == gh.adoptWithheld = 0
\* Finding 13's fix actually fired: a CAS found the object under one of
\* its own LANDED uploads gone or moved and withheld the entry.
ProbeUploadWithheld    == gh.uploadWithheld = 0
\* Finding 10's candidate fix fires.
ProbeOrphanTracked     == gh.orphanTracks = 0
\* H1b's fix fires: a sweep entry whose citation moved on was dropped.
ProbeOrphanOutlived    == gh.orphanOutlived = 0
\* H1b's leak rule fires: a tombstone applied over a leaked generation.
ProbeLeakApplied       == gh.leakApplied = 0
ProbeBaseRestored     == gh.baseRestored = 0
\* H10: an ack went partial on the journalled carrier alone.
ProbeCarrierAck       == ~gh.carrierAck
\* Non-vacuity for the CollectorOff world: the collector actually gave way
\* on a path it would otherwise have deleted.  Without this, "every
\* invariant holds" could mean "the collector was never asked".
ProbeCollectorLeaked   == gh.leaked = 0
ProbeStaleInboxAdopt   == gh.staleAdopt = 0
\* Immutable handles: the orphan sweep actually collected a handle (or a
\* handles world that "converges" never had anything to converge from).
ProbeSwept             == gh.swept = 0

\* ---- tranche 7: model the implementation -------------------------------
\* Each new arm is REQUIRED-REACHABLE in the world whose strict run leans
\* on it: a pull-only boundary, a commit that installed nothing, a queued
\* deletion that removed a clean copy, and one the key superseded.
ProbePullOnly          == gh.pullOnlys = 0
ProbeEmptyInstall      == gh.emptyInstalls = 0
ProbeTombstoneApplied  == gh.tombRemoved = 0
ProbeTombstoneSuperseded == gh.tombSuperseded = 0

------------------------------------------------------------------------------
(* GHOST-STATE REDUCTION (2026-09-15).  Two fingerprint reductions the cfgs
   opt into; neither changes an action, and neither is read by one.

   `StrictView` is the state as TLC should DISTINGUISH it in a run that
   checks no probe.  Most of `gh` is non-vacuity bookkeeping: counters a
   probe reads and nothing else does.  In a strict or must-fail run two
   states that differ only there have identical futures and identical
   invariant values, and TLC explored both — `LeanBarrierLeaseAdoptVerified`
   was 641,858 states with them and is 320,184 without.  The view keeps
   every `gh` field an ACTION reads (budgets, `nextGen`, `renamed`, ...)
   and every field an INVARIANT reads (the sticky stamps, `citedPairs`,
   `hitlRetired`, ...), and drops `sc`'s `pendReRun` and `stageCarried`,
   which only feed probe counters.

   That is sound only while it stays true, and a guard added next month
   that reads a dropped counter would make it silently unsound — so it is
   not a comment's claim: `view-census.py` (run first by `check.sh`) fails
   the gate when any field outside `StrictGh` is read anywhere but a probe
   definition or its own (or another dropped field's) update.  A probe cfg
   never gets the view: the field it names must be distinguished.

   `PathSym`: nothing in the module names a path, so the paths are
   interchangeable wherever they START interchangeable (`FreePaths` is {}
   or all of `Paths`).  Symmetry is unsound for liveness, so the FairSpec
   cfgs never get it.                                                     *)
StrictGh ==
  [amputated |-> gh.amputated,
   stragglerInstalls |-> gh.stragglerInstalls, deposedPuts |-> gh.deposedPuts,
   barriers |-> gh.barriers, crashes |-> gh.crashes, restarts |-> gh.restarts,
   stallUsed |-> gh.stallUsed, nextGen |-> gh.nextGen, hitl |-> gh.hitl,
   refusals |-> gh.refusals, syncs |-> gh.syncs,
   syncDestroyed |-> gh.syncDestroyed, foreignLost |-> gh.foreignLost,
   touches |-> gh.touches, ackEarly |-> gh.ackEarly,
   ackIncoherent |-> gh.ackIncoherent, fencedOkAck |-> gh.fencedOkAck,
   srcMismatch |-> gh.srcMismatch, narrows |-> gh.narrows,
   narrowed |-> gh.narrowed, narrowRecited |-> gh.narrowRecited,
   narrowDeleted |-> gh.narrowDeleted,
   consumeRegressed |-> gh.consumeRegressed,
   removals |-> gh.removals, renamed |-> gh.renamed, remJudged |-> gh.remJudged,
   answered |-> gh.answered, remOver |-> gh.remOver,
   renameRefused |-> gh.renameRefused, citedPairs |-> gh.citedPairs,
   sameBytes |-> gh.sameBytes, staleOverride |-> gh.staleOverride,
   removalOverreach |-> gh.removalOverreach, uiBase |-> gh.uiBase,
   hitlRetired |-> gh.hitlRetired, retired |-> gh.retired,
   orphanAt |-> gh.orphanAt, tomb |-> gh.tomb]
StrictSc ==
  [s \in Syncers |-> [sc[s] EXCEPT !.pendReRun = FALSE, !.stageCarried = FALSE]]
StrictView ==
  <<cellEpoch, cellHolder, cellQueue, cellHandoff, cellReleased,
    manSeq, manSrc, manifest, objects, inbox, removals, window,
    StrictSc, versions, stage, stageBase, withheldDel, hitlAcked,
    conflicts, StrictGh>>
PathSym == Permutations(Paths)

==============================================================================
