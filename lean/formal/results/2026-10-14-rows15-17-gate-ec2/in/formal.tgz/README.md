# The lean formal models

TLA+/TLC models for **flint-lean** (checkout/publish + gateway — plan of
record: `docs/plans/flint-lean-plan.md`). Model BEFORE code, the
FlintExtents posture: the module was written against plan v2 and the
review's confirmed counterexamples, and the syncer implementation
(`lean/syncer/`, the flint-lean crate) is written to it.

**Deliberately separate from `formal/`** (the flint corpus and its
196-run gate): lean is a separate system that consumes `tier::store` as
a library. Nothing here is wired into `scripts/check-tla.sh`.

## The shipped shape: LeanP1.tla (step 5, 2026-09-25)

**Read this first.** Since simplification step 5 the code is modelled by
`LeanP1.tla`: the gateway commits each UI verb (P2), a writer's baseline is
its merge base and what its tree is owed is derived at each consume
(P1-lite, with the cheap path as state: `derived`, `skipped` — the scan trigger), a delete over
theirs applies and theirs is recorded (M3), and a commit's retirements are
collected only after the retire age G (M1, with a reader ghost).
`../PROTOCOL.md` is written from it. Everything below this section —
`LeanSubtree.tla`, `LeanCore.tla`, the 182-run `check.sh` gate — models the
shape before step 5 (the inbox cell's entries and removals, the writer-local
queue, citation repairs; the cell itself stays, carrying only the two
verb requests) and is the record of what was checked on it.

```
./gen-leanp1.sh                                   # the worlds' cfgs (WORLDS-LeanP1.tsv)
python3 leanp1-gate.py --compile --jobs 2         # the gate on tla-mc (--only/--skip a subset)
./trace/trace-check-core.sh                       # the code's traces against it
```

**The claims are proved (TLAPS, 2026-10-14)** for every path count, writer
count and bound under the shipped rules: `results/2026-10-07-tlaps-m5/`
(NOTES.txt, the m5c/, m5d/ and m6/ modules) over the split proof of
`LeanP1Proof.tla`, and the liveness claim in
`results/2026-10-14-tlaps-live/LeanP1ProofL1.tla` — 19,235 obligations in
all (`../SAFETY.md` §3.3). The theorems: `TypeInvariant`
(`Spec => []TypeOK`), `OneHolder`, `DeleteSettles`, `NarrowNeverDeletes`,
`CitationsLive`, `OneName`, `ShortcutSound`, `ReaderSound`,
`ReaderFetches`, `NoSilentRevert`, `NoRegress` (NR5), `AckedNamed` (AN5),
`AgentWorkKept`, `ScopeRespected`, and `UISaveCompletes`
(`LSpec => Prop_UISaveCompletes`). `LeanP1Proof.tla` is generated
(`results/2026-10-07-tlaps-m5/gen-proof.py`, which chains the earlier
milestones' generators) and split by `split-proof.py`; edit the
generators, never the output. Two of the original claims were FALSE once the gateway
may remove three times, and stay in `LeanP1.tla` as the record:
`Inv_AckedNamed` (restated as `AN5`) and `Inv_NoRegress` (restated as the
action property `NR5`). The gate checks the restatements, and since
2026-10-14 also:
- `Rem3` and `Rem3Age`: three removals, with and without the retire age —
  the worlds where the originals fail;
- the model mutations `MN2Rem3` (a delete not acknowledged: NR5 must break)
  and `MA1Rem3Age` (a delete recording nothing: AN5 must break), built by
  `gen-leanp1-mutants.py` in a scratch copy (WORLDS-LeanP1.tsv's fourth
  column), never over the module;
- the scripted traces `MCLeanP1Trace*.tla`: hand-found behaviours too deep
  for BFS (26-31 steps in worlds of billions), each step a Next step. Each
  must reach its end with the claims holding (`HReach`), and break what it
  was found against: the old Edit base (`EditBase` mutant) for E27, E31,
  E33; `Inv_NoRegress` for E29; `Inv_AckedNamed` for E38, E39.

Expectations were written before any run (`WORLDS-LeanP1.tsv`). The trace
check accepts 41/41 (`results/2026-09-25-tracecore-on-leanp1/`). **The gate
passed 2026-10-14 on the restated claims** (`results/2026-10-14-leanp1-gate-ec2/`,
SUMMARY.txt): 68 of 69 worlds as expected — 12 hold, 54 fire, 2 recorded —
and `LeanP1LiveHolds`, which no checker has finished (Holds's 1.66B states
with a liveness graph), is decided by the proof instead. It passed first on
2026-10-04 (49/49, `results/2026-10-04-leanp1-gate/`). Its first run
(2026-09-25) had reported `Inv_ShortcutSound` violated in both shipped
worlds; that was settled before 2026-10-04.

The runner's large worlds need a big box: on one c8g.48xlarge (192 vCPU,
371 GB) phase 1 (62 worlds, 24 at a time, 4 workers each) took 31 min and
the six large worlds 60 min at 192 workers. Its `--out` holds tla-mc's
metadirs while a world runs (tens of GB each): a sync of it must exclude
`meta-*` and `cache-*`.

## Running

```
./check.sh              # the 141-run gate (runs view-census.py first)
./gen-cfgs.sh           # regenerate the cfg matrix
./trace/trace-check.sh  # the model against syncer traces (below)
```

A hundred and eighty-two runs, ALL required: 51 strict (must hold), 74 mutations
(must find their designated counterexample — a model that cannot
rediscover its bug classes proves nothing), 57 probes (must be violated
— each names an ACTION via a ghost only that action writes; probe the
action, never the situation). The three numbers are `grep -c "^strict_run "`,
`grep "^mutation_run " | grep -vc Probe` and `grep "^mutation_run " |
grep -c Probe` in `check.sh` — they had drifted from the script twice,
so they are stated as a recipe rather than a claim. (And `EXPECT` itself
drifted once: gated mode's removal took 23 runs out and left it at 92
over 69 real calls, so the gate at that commit failed its own count
check — which is what the check is for.) `LeanSubtreeDeep.cfg` is the
rich-budget breadth run — an opt-in overnight job, not in the gate — and
`LeanBarrierLeaseSameBytesDeep.cfg` is the same-bytes write in the richest
barrier-lease world, also opt-in: it does not fit a laptop (it HOLDS —
382,678,936 distinct states, depth 39, two hours on an i4i.2xlarge).

## The module: LeanChunkGC.tla

Chunk garbage collection against a concurrent publisher and a reader
(`docs/plans/flint-lean-chunked-manifest-design.md` §8.1). Separate from
LeanSubtree because the manifest there is ONE object per generation, so
every object had exactly one referent and "delete what the live pointer
does not name" was sound. **Chunks are shared between generations**, and
that single change is what makes the old reasoning not carry over.

Written before the reaper exists, and it earned its keep immediately: it
**refuted the design's own ordering rule on the first run**. §8.1 said
"list candidates, then union the retained pointers"; the counterexample
holds that order and still deletes a live chunk, because what matters is
that the reference set was read before a CAS the delete came after. The
corrected rule has four independently necessary clauses, one mutation
each.

The second finding was subtler: **adoption must rewrite what it adopts**.
An adopted chunk is an aged object no pointer references — exactly what
the orphan sweep hunts — so referencing it without touching it leaves the
age sensor lying. Reaching that config at all required adding a CRASH
action; the first version of the module reported it HOLDING because
without a crash it could not produce an orphan, which is the entire
subject of the section. The abstraction was the bug, again.

| Invariant | Claim | Mutation that must violate it |
| --- | --- | --- |
| `Inv_LiveComplete` | every chunk the live pointer names is present | `LeanChunkGCStaleRefs` / `LeanChunkGCRefsFirst` (refs read before a CAS the delete follows), `LeanChunkGCNoGrace`, `LeanChunkGCRacyGrace` (grace shorter than the publish), `LeanChunkGCAdoptSkips` (adoption without the rewrite) |
| `Inv_RetainedComplete` | every retained generation is still readable | the same set |
| `Inv_NoTornRead` | a reader never finds a chunk its pointer named, absent | `LeanChunkGCSlowReader` (the reader does not revalidate). Holds at an UNCHANGED `Retain = 1`: the fix is that a reader which finds a chunk gone re-reads the POINTER, and restarts onto the current generation if it moved — a hole under an unchanged pointer is the only true corruption (§8.2). No timing assumption, no wider window |

## The module: LeanChunkMerge.tla

The chunked three-way merge (chunked-manifest design §6). The
entry-level merge is LeanSubtree's and is not re-derived; this checks
the level chunking adds. A writer that 412s must merge, and the
tempting optimisation is to reuse the other writer's chunk list and
substitute only the chunks its own change touched — making the merge
O(changed) as well.

It loses foreign entries. `base = {}`, A adds `{1}`, B adds `{1,2}`:
A's chunking is `{{1}}` and B's is `{{1,2}}`, the same range under
different boundaries, so substituting A's chunk for B's drops key 2.

The property is a REFINEMENT — whatever the chunked path publishes must
be exactly the key set the whole-document merge produces — so the
strategy is checked against a definition rather than against a restated
version of itself.

Worth knowing WHY this can happen at all: with boundaries determined by
the key alone, a key's chunk is a function of the key, splicing is
trivially safe, and there is nothing to check. `MinRun` breaks that, and
that is the entire subject. §3 calls min/max "where the pure-function
property leaks"; this module is what that leak costs.

| Invariant | Claim | Mutation that must violate it |
| --- | --- | --- |
| `Inv_ChunkedMergeMatches` | the chunked merge publishes exactly the whole-document merge's key set | `LeanChunkMergeSplice` (reuse theirs, substitute mine) |

## The module: LeanSubtree.tla

One subtree; syncers A (first holder) and B (takeover successor); the
gateway abstracted to its bucket effects; the bucket substrate: lease
cell, manifest (seq + per-path citation), whole-file objects
(generation = ETag), the inbox/window cell. Generations model ETags;
If-Match is equality on them; whole-PUT is atomic.

Invariants:

| Invariant | Claim | Mutation that must violate it |
| --- | --- | --- |
| `Inv_HITLDurable` | an acked HITL write is never silently lost | `LeanAmputation` (direct manifest bump + whole-rewrite writer), `LeanLocalWins` (the inherited flush.rs LOCAL-WINS 412 arm), `LeanGCUnguarded` (unguarded GC delete); with TWO LIVE WRITERS `LeanBarrierLeaseHitlOverUncited` (a UI write over a writer's uncited upload — a FINDING, tranche 6) |
| `Inv_NoDangling` | every cited manifest entry has a live object | `LeanDanglingOrder` (v1 order: upload→delete→CAS); under the barrier lease `LeanBarrierLeaseGCUnconditional` (the shipped HEAD-then-DELETE GC against a second writer's supersede) and `LeanBarrierLeaseAdoptBlind` (an adopted entry cited without re-verification under the lease) — both FINDINGS, tranche 6; and `LeanBarrierLeaseSameBytesUnverified` (a LANDED upload of identical bytes, whose etag the other writer's GC recognises — finding 13, found by the live drill first) |
| `Inv_NoStaleOverride` | no commit replaces a citation the key still holds with a generation of its own upload the key no longer holds (barrier lease) | `LeanBarrierLeaseSameBytesOverride` (finding 13's second route: a peer's new bytes land If-Match an identical-bytes upload's etag and are committed; nothing dangles, so `Inv_NoDangling` cannot see it) |
| `Inv_NoStragglerInstall` | a deposed writer's manifest CAS never lands | `LeanNoRotate` (no takeover rotation); `LeanBarrierLeaseNoRotate` (the same, deposal mid-commit) |
| `Inv_NoDeposedPut` | a deposed writer's data PUT never lands | `LeanNoEpochCheck` (rotation alone — proves rotation does NOT cover the data path). Under the barrier lease this is vacuous by design: uploads precede the claim and are never fenced (protocol of record, straggler rules) |
| `Prop_NoResurrection` (an ACTION property since 2026-09-19, H9: no step that is a restart creates a local file; it replaced `Inv_NoResurrection`, a ghost written only under the mutation constant, whose strict runs were tautologies) | a container restart never resurrects an unpublished delete | `LeanRematerialize` (re-checkout over a live tree) |
| `Inv_SyncNeverDestroysDirty` | the sync verb never destroys genuinely-dirty local work without surfacing it | `LeanSyncStaleDirt` (sync judging dirt from the last barrier's snapshot) |
| `Inv_NoForeignLost` | a sync never advances the merge base for a path it did not integrate or surface (D4) | `LeanScopedSyncWholeBase`; and with TWO LIVE WRITERS the shipped rule itself: `LeanBarrierLeaseSyncOverlayStale` (a FINDING, tranche 6; its control `LeanBarrierLeaseSyncOverlayHolds` moves `SyncKeepsHiddenBase` alone) |
| `Inv_CommitExclusive` | one writer in the commit section at a time (D1, the lease's safety half) | none needed yet: it is what every deposal run checks, and it held in every world |
| `Inv_CellHeldByHolder` | model coherence: a HELD cell's holder is in its commit section at the cell's epoch | — (pins the claim arms; a wrong arm fails it first) |
| `NoStarvation` (liveness, `FairSpec`) | every live writer that queued for the cell eventually holds it | `LeanBarrierLeaseRandomArbitration` (no ticket: one writer claims forever), `LeanBarrierLeaseDeadHandoffWedge` (no dead-handoff skip: a crashed waiter wedges the cell) |

Deliberate strict-HOLDS runs (machine-checked design findings, the
FlintClaimsNoLeader idiom):

- `LeanNoWindowHolds` — with the inbox + the 412-park + the GC guard
  in place, the WINDOW carries no safety at whole-PUT atomicity: its
  value is availability/UX (refuse-vs-queue semantics) and defense in
  depth below the model's atomicity floor. Do not cite the window as a
  safety mechanism.
- `LeanEpochOnlyHolds` — per-request epoch validation alone fences the
  straggler's manifest CAS; rotation remains as defense for any write
  path that bypasses the gateway's validation.

## What the model already caught (worth not re-learning)

0. **THE INBOX IS LOAD-BEARING — merge alone is NOT sufficient.** The
   planned `LeanDirectMergeHolds` strict run was REFUTED (now the
   `LeanDirectMergeInsufficient` mutation): a merge-capable writer
   preserves a direct-bumped foreign entry, but preservation without
   INTEGRATION is one barrier deep — Finish absorbs the entry into the
   merge base, and a later local delete then destroys the user's
   citation with no record (depth-12 trace: bump → preserve → absorb →
   delete). Only the inbox's consume path (integrate-or-surface) makes
   HITL durable against subsequent local operations.
1. **The amputation stamp needed a legitimacy term.** A syncer that
   CONSUMED a user's upload and then published a delete of it is doing
   integration + ordinary editing, not amputation. Legitimacy rides on
   the `known` set (generations learned via checkout, own mints, and
   surfaced consumes — blind adoption deliberately does not extend it).
2. **The GC delete set must be derived from the INSTALLED manifest, not
   the scan** — "keys the NEW manifest no longer references." After a
   delete/modify conflict the merge re-cites the foreign entry, and the
   scan-time delete set would GC a key the manifest still references.
   The v1 order structurally cannot make this check (no new manifest at
   delete time) — that asymmetry is part of what `LeanDanglingOrder`
   pins.
3. **`baseline` and `instBase` are different objects.** The If-Match
   baseline (what I believe the bucket objects hold AND have
   integrated) advances at consume; the merge base (the manifest view
   at my last install) does not — collapsing them makes a syncer
   mistake its own consumed adoption for a foreign entry.

## Tranche 2 (2026-08-25): the sync verb × the barrier

`Sync(s)` joins the module behind `SyncEnabled` (FALSE in every
tranche-1 cfg, and `lastDirty` is only tracked under it, so those state
spaces are preserved by construction). The verb is modelled as the
implementation serializes it: harness-invoked, at `pc = "idle"`,
against remote truth = the manifest overlaid by live inbox entries.

`SyncScanFirst` is the arm. TRUE = the shipped rule (dirt is judged by
sync's OWN scan); FALSE = the refuted design (dirt is whatever the last
barrier's scan froze). **The A/B is genuinely attributive**, which the
corpus insists on before believing a mutation: with scan-first ON the
destroying case is *unsatisfiable* — `applicable = changed \ trueDirty`,
so `p ∈ applicable ∧ p ∈ trueDirty` cannot hold — and
`LeanSyncHolds` carries the invariant green in exactly the same world
where `LeanSyncStaleDirt` violates it. The counterexample is the
review's finding in four steps: agent writes p after the last barrier
(or before any barrier), a HITL write lands on p, sync judges p
"clean" from the stale snapshot, and the remote version overwrites the
agent's un-scanned latest work with no conflict record.

Two probes keep the strict run honest: `ProbeSyncApplied` (sync really
does apply a remote change) and `ProbeSyncConflict` (it really does
surface a dirty-path conflict) — both must be violated.

## Tranche 3, product 4 (2026-08-25): the SCOPED sync verb × the merge base

The boundary-verbs plan's D4 rewrites the per-path semantics of
`instBase` — the object this model has refuted naive designs on twice —
so it is modelled before the rule is trusted. `SyncScope` is FALSE in
every tranche-1/2 cfg (scope collapses to `Paths`), so those state
spaces are preserved by construction.

`ScopedInstBase` is the arm. TRUE = D4: a scoped sync advances the merge
base only for paths it applied or verified in scope. FALSE = the
mutation: it advances the whole base to bucket-current, so every
out-of-scope foreign entry reads as already-integrated at the next
merge, `foreign(p)` is FALSE forever after, and the entry is never
queued into the inbox again. `Inv_NoForeignLost` is the stamp; the loss
is *silent and permanent*, which is why it is a safety invariant rather
than a staleness note.

**The world note, and it cost a wrong cfg before it was written down.**
The D4 loss needs an out-of-scope change that lives in the MANIFEST, not
in the inbox: an inbox-overlaid change survives a wholesale `instBase`
advance untouched, because the entry itself is still queued. In this
design the only legitimate foreign manifest installer is a takeover
successor — so these runs need `AllowStall` and a second barrier. With
`MaxBarriers=1` and no stall arm the hazard is UNREACHABLE and the
mutation runs green against a state space that never contained the bug.
The first hand-written Rust test for this rule was vacuous for exactly
the same reason: it used a HITL inbox entry as the out-of-scope change
and passed with the hazard reintroduced.

**Budget, verified as a pilot before being locked in** (the plan's
affordability obligation): `MaxGen=2` + `MaxHitl=0`, the takeover cfgs'
depth-buying trick. At that budget the strict run completes in ~9 s AND
both the mutation and the probe still fire — the strict run is not
checking a smaller world than the bug lives in. At `MaxGen=3`/`MaxHitl=1`
the strict run passed 30M states without terminating.

`ProbeScopedDeferral` is action-written (Sync's own ghost counts the
paths it deliberately deferred), per the house rule that a probe names
the ACTION and never the situation.

## Tranche 3, product 2 — gated citation × version GC × the backstop

Nine runs (27 → **36**, at the time), behind `GatedCitation`, which is FALSE in every
pre-existing cfg: the gated actions are disabled and `versions`, `stage`,
`stageBase` and `withheldDel` are frozen at their Init values, so those
state spaces are preserved by construction. `VersionsFollow` composes the
version-minting rule once at the `Next` level rather than threading it
through twenty actions — under gated, *any* action that moves an object
mints a version, which is what a versioned bucket does.

**The substrate is the point.** Generations are unique mints, so a
generation already IS a version id and `manifest[p]` already cites one.
What the product adds is `versions[p]` — what is still STORED, which on
a versioned bucket is a different question from what the key reads as.
`Inv_NoDangling` ("the object exists") was the right question until D7;
gated staging makes the CITED version noncurrent, so an object can
exist, read as newer uncited bytes, and have nothing behind its
citation. `Inv_CitedVersionLives` was the corrected question. It retired
with the gated lane (2026-09-19, H9): under handles `Inv_NoDangling`
asks exactly that of `versions[p]`, and the core's `Inv_CitationsLive`
says it over state (`SAFETY.md` §3.1).

**It found a live defect on its first strict run, in shipped code.**
The reaper's rule was *"delete every version of a touched key except the
one the installed manifest cites"*. The upload lane opens no HITL window
— deliberately, since a lane that fenced HITL out every floor tick would
refuse admission essentially forever between citations — so a UI write
can land on an already-staged path. The citation's base-version check
cannot see it (that check reads the BASELINE, and the citation lane
consumes nothing), so the citation cited our staged version, and the
reaper then deleted the user's version. **It was current, it was acked,
and the inbox entry 412s on its next consume and is dropped as
superseded.** Two rules close it, both now in the code and both modelled:
the reaper never reclaims the CURRENT version, and a staged path with a
live inbox entry is dropped from the boundary rather than cited over
(the window CAS has already loaded the inbox — zero added requests).

**And it retired a guard that protects nothing.** D7 also specifies a
base-version re-validation: drop a staged entry whose baseline moved
under it. The model showed that arm is UNREACHABLE given the lane's own
discipline — the lane never advances the baseline, so a staged path is
by construction locally-dirty, and every route that could move a
baseline (consume, sync) refuses dirty paths and surfaces a conflict
instead. It stays in the implementation as defence in depth; what the
model says is that it is not what protects anything today, and that the
hazard it was written for arrives by a route it could not see. That is
the second-order return on modelling after the fact: not only "here is a
bug" but "here is a guard you believed in for the wrong reason".

**Defence in depth, pinned as such.** `LeanGatedReapsCurrent` turns off
BOTH the keep-current rule and the inbox guard, because with the inbox
guard in place removing keep-current changes nothing — the reaper's
scope never reaches the path. The Rust battery hit exactly the same wall
and needed a second leg (an out-of-band writer, §3 residual 11's
population) to isolate the rule. A one-arm cfg here would have been a
green mutation dressed as a passing test.

**Budget:** `MaxGen=3`, `MaxHitl=1`, `MaxBarriers=2`, no crashes or
restarts — ~19k distinct states, ~2 s for the strict run. `MaxHitl=1` is
load-bearing rather than breadth: the whole product turns on a foreign
write arriving between the lane and the citation, and at `MaxHitl=0`
that interleaving does not exist and every mutation checks a state space
its bug cannot live in.

**Not modelled, named rather than omitted silently:**
`Inv_ManifestKeysUnderFiles` (this module has no control namespace; D0.2
is carried by the Rust battery's scan/classify/checkout legs), and the
citation's own crash matrix (product 1's territory — the citation and
its reaper are ONE step here, which is faithful only because the real
code holds the HITL window across both).

## Deliberate abstractions (tranche 1 — residuals, not coverage)

- The scan is ATOMIC: the rename-vs-walk race and the
  two-consecutive-scans deletion rule are UNREPRESENTABLE here. The
  implementation carries the rule; only the drill can exercise it.
- The 6-quiet-poll takeover observation is one `ClaimB` action; the
  poll protocol itself is machine-checked in flint's
  `FlintTierEpoch.tla`, and lean's claim loop mirrors it.
- Checkout ignores hydrate's 412/S3-wins divergence arm.
- Multi-subtree layout (P2/P3), partial checkout, preStop timing, and
  every perf axis (Phase 0b/0c) are out of scope. (The sync verb moved
  IN — see tranche 2 above; it is atomic there, which is faithful to
  the quiescent contract but leaves an agent writing DURING sync
  unmodelled.)
- `conflicts` is a set of records: the implementation obligation is
  that a conflict record preserves the BYTES (conflict-suffixed key —
  `lean/syncer/src/barrier.rs` does this), not just the reference.
- Multi-gateway is collapsed into the cell semantics: replicas are
  stateless by design, so the window cell IS the coordination — a
  per-replica model adds states, not behaviors, at this abstraction.

## Tranche 3, product 1 — the boundary VERB × the barrier × the inbox

Thirteen runs (36 → **49**, at the time), behind `SentinelEnabled`, FALSE in every
pre-existing cfg: every sentinel action is disabled, the skip-on-no-diff
fast path is unreachable, and the seven new `sc[s]` fields stay at their
empty Init values, so those state spaces are preserved by construction.

**It found two defects in shipped code, both on strict runs, before a
single mutation was applied** — and it rejected two of my own invariant
formulations first, which is the more useful lesson.

**The promise took three tries to state, and each wrong try was a real
behaviour.** An ok ack asserts that the coherent point the agent
declared is INSTALLED. Stating that as *snapshot equality* is wrong,
because D1's guarantee is at-LEAST — "the published state may include
later bytes for a racing file, never earlier ones". TLC's answers, in
order: (1) an agent that deleted a path, declared, re-created it, let
the barrier publish the re-creation and deleted it again, so the
consume-time snapshot matched the tree again at ack time while the
manifest legitimately cited later bytes — hence `pendMint`, a
generation watermark; (2) an inbox adoption of a HITL write that landed
before checkout, where the agent had no work on the path at all — hence
`pendDirty`, so the promise covers only what was locally dirty at the
consume; (3) an agent deleting its own declared file after declaring,
which supersedes while minting nothing — hence the tree-comparison
clause the watermark cannot replace. All three exemptions are in
`BoundaryBroken` with the counterexample that forced them.

**Two invariants, not one.** Counterexample (2) also showed that "the
agent's own work survived" and "the point the ack names is coherent at
all" are different claims: a citation repair still owed at ack time
risks no work of the agent's and still means a reader — or this
workspace's own next checkout — resolves to bytes already superseded
here. `Inv_AckImpliesCited` and `Inv_AckBoundaryCoherent` each have
their own mutation, and neither fires the other's.

**Defect one: a restart between the manifest CAS and step 7 ate the
agent's delete.** The merge base and the baseline are both rewritten at
step 7 — after the CAS, after the GC deletes. A container restart in
that window leaves the bucket holding a document this workspace wrote
and the persisted merge base one generation behind it, so at the next
merge our own entries read as somebody else's change; delete/modify
resolves conservatively by design, so the agent's delete is dropped
from the boundary it is about to be acked for and the path is queued
into the inbox as a conflict nobody else ever touched. TLC produced it
by two different routes — an adopted inbox write and our own upload —
which is what killed the first fix (an entry-`epoch` test, fooled by an
in-place foreign edit that leaves the epoch field alone; the battery's
`local_delete_loses_to_foreign_modify` said so within seconds). The fix
that holds is document identity: `IntentJournal::installed_etag`,
written immediately after the CAS. Pinned as `MineIsNotForeign`.

**Defect two was found by reading for the model, not by running it**:
the D12 heartbeat renewal arm returned on `Fenced` without settling
owed acks. Both honor arms settle; the heartbeat — decoupled from
publish cadence, and therefore usually the FIRST arm to discover
deposal — did not. `RenewDiscover` models the fixed rule.

**§10.1's deliberate deviation is now machine-checked rather than
argued.** §2.1 prescribes that a pending sentinel defeat the
skip-on-no-diff fast path; the shipped code lets it through, because
defeating it would cost a manifest CAS at up to 720/hour/workspace. The
argument was that the fast path only fires when every local byte is
already cited. `FastPathGuards=FALSE` drops the two guards that carry
it — no citation repair owed, and the remote manifest where we left it
— and `Inv_AckBoundaryCoherent` must fall. `ProbeFastPathHonor` is what
keeps the strict side from holding because the fast path never ran.

**A budget note that cost a pilot.** The fast path must charge the
barrier budget. Without it `Consume → FastPath → Consume` is a free
cycle that consumes nothing, and the state graph's DIAMETER grows
without bound — the pilot ran to depth 148 and 17M states before that
line existed. And `MaxGen=3` with `MaxRestarts=1` does not fit: the two
worlds are split — `MaxGen=3/MaxRestarts=0` for breadth,
`MaxGen=2/MaxRestarts=1` for the crash matrix, and `MaxGen=2/MaxHitl=0`
with one touch for the stall/takeover world (at `MaxGen=3` the deposal
run passed 1.3 GB of TLC scratch without terminating: two live syncers,
each with its own sentinel, pending record and ack, is a different scale
from one) — and every mutation runs in the smaller world its
counterexample needs.
`MaxTouches=2` is load-bearing exactly as `MaxHitl=1` was for product 2:
the orphan hazard needs a second consume landing on a live pending
record, and `ProbeCoalescedAck` is what proves that is reached.

**The harness earned its keep on this tranche.** One mutation's world
lost the arm its counterexample needs — a cfg override that silently did
not apply, leaving `MaxRestarts=0` on the run whose whole subject is a
crash between the CAS and step 7. It completed a full 1.3M-state search
and reported no error, which reads exactly like a pass. `mutation_run`
treats rc=0 as a FAILURE for precisely this reason: a mutation that
cannot rediscover its bug proves nothing, and the only way to tell that
from a fix is to demand the counterexample by name.

Not modelled, named rather than omitted: the two-consecutive-scans
delete rule (still unrepresentable here — the battery isolates it with
five mutations after it produced its own shipped defect this session),
the bare touch, the min-interval and hourly budget (rate limiting stays
out of the safety gate), and an agent restoring byte-identical content,
which unique mints cannot express.

## Product 1 × product 2: the sentinel over the citation lane (6 runs)

Both products were already green, each in a world where the other was
switched OFF — so the citation-lane honor, the one path where a boundary
can be *installed* and still not carry what its ack claims, had never
been evaluated at all. `CiteFinish` sets `honored` under
`SentinelEnabled`; the module could always express it, the cfg matrix
never asked.

What the pairing cost and what it bought, in order:

- It refuted a fix that was two hours old. `LaneCancelsStaged` — a
  withheld delete cancels the version the stage still holds, and vice
  versa — went in because delete-then-recreate amputated a live file;
  the model showed that resolving the overlap the other way cites a file
  the agent DELETED. Neither set carries the ordering, so `merge` cannot
  arbitrate it in either direction; the lane can, and does.
- It found C2's gap as a model artifact (`GatedRepair`): the citation
  lane had no citation-repair, so an ok ack named a manifest that did
  not cite a HITL write the workspace had already integrated.
- Three of the four defects it reported first were **in the model**, and
  saying so is the point of writing them down: `dels` guarded the UNCITE
  with the GC's own guard (the code uncites in the CAS and lets the GC
  refuse the object separately); `Consume` could interleave between the
  citation and the ack, which a single-threaded honor cannot; and the
  adopt-own arm staged any recognized generation, where `upload_one`
  adopts only when the object holds the bytes it is uploading and
  otherwise supersedes them knowingly.
- `BoundaryBroken`'s conflict exemption had to be NARROWED: a conflict
  record is the ack's `report.parked` in the fused path, which is why it
  excuses a path there — a correspondence the gated honor cannot
  maintain, because the drop happens inside the citation and the honor
  writes one ack for the lot. Written as a plain conjunct it excuses
  exactly the case it exists to catch; it is a disjunct with the
  exemption for a reason.
- And `ProbeDeclaredDrop` found a hole in the runs that came BEFORE it.
  The in-flight drop needs four mints (a second staged path — without
  one no citation fires at all — the dropped path's generation, the HITL
  generation, and the declaration's watermark), and no gated world had
  the budget. So **`CiteDropsInflightHitl`, product 2's rule, has never
  had a positive reachability probe**: its mutation fires through an
  unrelated shape, and the state the rule actually guards was
  unreachable in its own world. One probe, in an already-green gate.

Not modelled here, named rather than omitted: what the drop-inflight
rule guards in shipped code — a HITL write landing between the lane's
consume and the citation's window — is not expressible, because the
gated lane reuses `Scan`, which OPENS the window, while the shipped lane
deliberately opens none. Making the gated lane window-free is the
fidelity fix and it is not free.

## Tranche 6 (2026-09-13): the PER-BARRIER lease × the FIFO ticket

Design of record: `docs/plans/flint-lean-writer-lease-and-gated-assessment.md`
§4–§8 and the lease-v2 protocol note. The cell is held for ONE barrier's
commit section — claim after the uploads, release after the baseline —
with a FIFO ticket, instead of for the pod's life. Twenty-one runs
(69 → **90**), behind `BarrierLease`, FALSE in every pre-existing cfg:
`StartA`/`ClaimB` keep the life lease, `Scan` opens the window, every
fence kills, and `cellQueue`/`cellHandoff`/`cellReleased` stay frozen at
Init. **Preserved by construction, verified by number**: four strict
worlds re-run on the new module against the HEAD module's counts —
`LeanRemovalHolds` 332,847, `LeanSentinelHolds` 1,208,901,
`LeanSubtreeTakeover` 1,365,619, `LeanSentinelDeposal` 3,484,752 distinct
states, all identical.

What the module gained, and which action writes each thing:

| new | kind | meaning |
| --- | --- | --- |
| `cellQueue`, `cellHandoff`, `cellReleased` | variables | the ticket: waiters in FIFO order, who the last release named, and whether the cell is HELD (`cellEpoch > 0 /\ ~cellReleased`) or RELEASED |
| `StartLease(s)` | action | both syncers start by checking out, holding nothing (B no earlier than A: symmetry breaking only) |
| `Claim(s)` | action | fresh cell, released cell whose handoff is nobody/me, or the DEPOSAL of a quiet holder (stalled/dead — the 60 s rule, the same abstraction `ClaimB` uses); only the deposal rotates; the window opens HERE |
| `Enqueue(s)` | action | a syncer that cannot claim takes a ticket (pc `waiting`) — separate so the queue is observable |
| `SkipDeadHandoff(s)` | action | the 20 s rule: a quiet handoff is dropped and the released cell is anybody's |
| `Finish(s)` | changed | releases as its LAST step (handoff = queue head); a crash between CAS and Finish leaves the cell HELD by a dead holder, which the deposal covers; a deposed holder releases nothing |
| `Restart(s)` | changed | a restarted container that finds the cell held by its own id releases it |
| the fence arms | changed | `FencedSc`: under the barrier lease a fence ABANDONS the barrier and the syncer keeps running; no `refused-fenced` ack exists (`AckRefused` is life-lease only) |
| `Holding(s)`, `DeposedHolder(s)`, `Fenced(s)` | helpers | `Deposed` means something only inside the commit section; every fence and every straggler stamp now reads `DeposedHolder`, which collapses to `Deposed` under the life lease |
| `Upload(s, p)` | changed | a NON-holder action, never fenced; `gh.interleaved` is the required-reachable probe |
| `GCHead(s, p)`, `gcHeaded`/`gcSeen` | action/fields | the shipped two-request GC, under `~ConditionalGC` (finding 1) |
| `adopted`, `VerifyAdoptedCitations` | field/arm | an adopted entry is re-verified inside the commit section (finding 2) |
| `AgentWriteSame(s, p)`, `MaxSameBytes`, `touched` | action/budget/field | the agent writes a generation it RECOGNISES — identical bytes, one etag; back to the baseline's own, the path is dirty by its stat alone (`Dirty` reads `touched`; Consume does not adopt over it; Sync and Finish clear it where they rewrite the baseline) (finding 5) |
| `VerifyUploadedCitations` | arm | CASInstall re-verifies every citation its own LANDED uploads add, not only adoptions (finding 5, the 79e7dac9 fix) |
| `gh.staleOverride`, `Inv_NoStaleOverride` | ghost/invariant | stamped in CASInstall when a commit cites its own upload's generation over a citation the key still holds (finding 5's second route) |
| `AckedDoc(s)`, `AckedSrc(s)`, `instSrc` | helpers/field | under the barrier lease the three ack stamps (`BoundaryBroken`, `BoundaryIncoherent`, `srcMismatch`) are judged against the document the ack NAMES (`instSnap` at `instSeq`, seeded at checkout for a never-installed writer) and its clock, never against the live manifest — see "the ack under two writers" below |
| `InfiniteBarriers`, `FairSpec`, `NoStarvation` | liveness | see below |
| `gh.claimed/interleaved/handoffs/deposals/deadSkips/enqueues/abandoned/adoptWithheld/uploadWithheld` | ghosts | one probe each, each written by exactly one action |

**The liveness property, and what it took.** `NoStarvation ==
\A s : [](Waiting(s) => <>(Holding(s) \/ ~Running(s)))` under `FairSpec
== Spec /\ \A s : WF_vars(BarrierStep(s))` — weak fairness on each
writer's OWN barrier step, never on "some writer steps". The first
obstacle was not the two symmetric writers, it was the budgets: every
counter a no-change barrier moves (`gh.barriers`, `manSeq`, the epoch,
`gh.done`) is monotone, so under budgets the state graph has no cycle
and "claims forever" is not a behaviour TLC can exhibit — the FALSE arm
was GREEN, because after the last budgeted barrier the waiter's claim is
continuously enabled and WF fires it. `InfiniteBarriers` is the
abstraction: those counters saturate instead of stopping the world, one
path, no writes, no crashes. No third syncer and no biased choice were
needed once the loop could cycle. Results, each ~5 s:

- `LeanBarrierLeaseLive` (`Ticket`): HOLDS, 24,465 states.
- `LeanBarrierLeaseRandomArbitration` (`Ticket = FALSE`): VIOLATED —
  the lasso is A `Claim → CASInstall → Finish(release, handoff none) →
  Consume → Scan → Claim …` ("Back to state 33") with B parked at
  `waiting` in `cellQueue = <<"B">>` throughout: B's `Claim` is enabled
  only between A's release and A's next claim, WF asks nothing of an
  action that is not continuously enabled, and A claims forever. With
  the ticket, A's release names B and A's own next claim is DISABLED
  until B holds, so B's claim is continuously enabled and WF forces it.
- `LeanBarrierLeaseLiveCrash` (a crash, `DeadHandoffSkip`): HOLDS,
  103,448 states — a dead holder is deposed, a dead handoff is skipped.
- `LeanBarrierLeaseDeadHandoffWedge` (`DeadHandoffSkip = FALSE`):
  VIOLATED — B queues, crashes; A's release names the dead B; A queues
  behind a handoff that will never claim, and stutters there forever.

**Five findings, all two-writer, none reachable under the life lease** —
four found by the model, and a fifth it could not see until an
abstraction was taken back (below).
The rule was: a real counterexample in the protocol is not "fixed" in
the model; it is pinned as the must-fail it is, and the fix — where one
belongs to this protocol — is modelled as an arm so the rest can be
checked against it (the `MineIsNotForeign` pattern).

1. **The GC delete is a HEAD then an unconditional DELETE**
   (`barrier.rs` step 6). Under the life lease the lease covered that
   window; under the barrier lease the other writer's uploads hold no
   lease, and its supersede landing between A's HEAD and A's DELETE
   leaves B's citation dangling. The module's atomic `GCDelete` had
   always hidden this; `ConditionalGC = FALSE` makes it two steps and
   `LeanBarrierLeaseGCUnconditional` finds it in 86,771 states, no stall,
   no crash, no HITL. The fix is a conditional delete (If-Match on the
   recognised etag — S3 supports it on DeleteObject; `flint-store`'s
   trait has only `delete(key)` today). Strict runs use the conditional
   delete; that is what they certify.
2. **An adopted entry is cited blind.** A barrier that restarts between
   its CAS and its baseline re-uploads next time and finds its own bytes
   already there; `upload_one` adopts (CRC match, no PUT — the correct
   rule, and the model's ungated arm was made to follow it under the
   barrier lease: it used to adopt ANY recognised generation and cite
   the walk's bytes, which is how the first four strict runs dangled
   before the real race was reached). Between the adopt and the
   adopter's CAS the other writer's commit uncites the path and its GC —
   HEAD-guarded on an etag it learned at checkout — deletes the object;
   the adopter's merge then upserts a citation over nothing. TLC found
   it at depth 28 of the first stall run (5.0M states); the restart
   world (`LeanBarrierLeaseAdoptBlind`) reaches it without a stall. A
   same-bytes re-PUT would not help — a real etag is the content hash,
   so the recognised-etag guard cannot tell the re-PUT from the
   original. The one race-free place to look is the commit section,
   because GCs run only under the lease: `VerifyAdoptedCitations`
   re-verifies adopted entries at the CAS and withholds what is gone
   (parked, with a record; the path stays dirty). `LeanProbeAdoptWithheld`
   proves the arm fires; `LeanBarrierLeaseAdoptVerified` is the control.
3. **D4 does not survive a second live writer.** The sync verb's remote
   truth is the manifest overlaid by live inbox entries (`sync.rs` step
   2: "an inbox entry is a write the manifest has not re-cited yet").
   With two writers the entry B's own merge queued (A's install) can be
   OLDER than the manifest: A deletes the path afterwards while the
   entry's object still exists, so B's scoped sync "verifies" the path
   unchanged against the overlay and advances the merge base to the
   manifest — the silent, permanent loss `Inv_NoForeignLost` names. One
   writer cannot produce it: the only party that could move a manifest
   past its own queued entry is dead. Pinned as
   `LeanBarrierLeaseSyncOverlayStale` (817,765 states, 25 s). The fix is
   the sync verb's — advance the base only to what was VERIFIED, never to
   a manifest the overlay hid — and was built the same day (`sync.rs`
   step 5, with a repro test that fails without it). Modelled as
   `SyncKeepsHiddenBase` (FALSE in every earlier cfg, so their state
   spaces are unchanged); `LeanBarrierLeaseSyncOverlayHolds` is the same
   world with that one constant moved, and HOLDS (1,493,045 states,
   104 s).

   Two things the code now does that this module does NOT yet model,
   named so the gap is not mistaken for coverage. The code no longer
   queues merge-preserved entries in the SHARED inbox — a peer's consume
   dropped them as "already integrated" and the writer that needed them
   never converged — but keeps them, with the peer's DELETIONS as
   tombstones, in a writer-local queue; the module's `foreignQ` still
   joins the shared `inbox` at install. And a barrier whose merge adds
   nothing to theirs installs nothing (two idle writers traded empty
   generations). Both are convergence properties, invisible to the
   safety invariants here; modelling them is a liveness tranche of its
   own. Until then the overlay finding's trace (a stale merge-preserved
   entry) is a path the code no longer takes — the stale overlay it now
   guards against is a consumed HITL entry between a commit's CAS and
   its window clear, which the repro test drives.
4. **A UI write over an uncited upload is lost** — found by the gate,
   not by review: the first full run under the three fixes above
   violated `Inv_HITLDurable` in the two-writer sentinel world. The
   window now opens at the claim, so nothing holds the gateway off
   while a writer uploads, and the gateway's PUT is If-Match the key's
   CURRENT etag — which may be A's upload, not yet cited. B consumes the
   UI write, cites it and drops the entry; A's commit then re-cites its
   own generation over it. The UI's acked write is uncited, untracked
   and preserved nowhere, and the manifest cites bytes the key no longer
   holds. No writer-side rule can see this: A's upload and the UI's PUT
   both succeeded on their own conditions. The fix is the gateway's — a
   HITL write overwrites only a version the workspace TRACKS (the
   manifest's citation, or one an inbox entry names) and otherwise gets
   a retryable 409; an untracked object older than
   `UNTRACKED_GRACE_SECS` is fair game (a second escape, "no live
   writer", went with the writer heartbeat)
   (`flint_lean::inbox::hitl_may_overwrite`, used by `put_file` and
   `promote_draft`, with a syncer repro and a gateway test, both failing
   without it). Modelled as `HitlOverwritesTrackedOnly`, a guard on
   `HitlWrite` (`objects[p] = 0 \/ objects[p] = manifest[p] \/
   <<p, objects[p]>> \in inbox`), TRUE in `BLWORLD` and `BLSENT`
   (`LeanBarrierLeaseHolds`, `LeanBarrierLeaseSentinel`) and FALSE in
   every other cfg. `LeanBarrierLeaseHitlOverUncited` is `BLSENT`
   with that constant alone moved: VIOLATED, 18,939,222 distinct states,
   622 s. The grace and no-live-writer escapes are not modelled: the
   guard refuses every untracked overwrite, stricter than the code,
   which is the safe direction for a durability claim and says nothing
   about whether those escapes are themselves safe.

   **They are, since finding 5's fix** (2026-09-14). The commit re-reads
   every citation its own uploads add, so a UI write over an uncited
   upload no longer lets the uploader re-cite over it: its commit
   withholds. `LeanBarrierLeaseHitlOverAnyVerified` lets the gateway
   overwrite ANY current object — a superset of both escapes — in
   `BLSENT` with the sentinel off, and HOLDS `Inv_HITLDurable`,
   `Inv_NoDangling`, `Inv_NoStaleOverride` and `Inv_HITLTracked`:
   15,528,749 distinct states, depth 36, six minutes on a laptop.
   `LeanBarrierLeaseHitlOverAnyUnverified`, the same world without the
   re-read, is finding 4 again (depth 16). So the tracked-only rule is
   now defense in depth, and the writer heartbeat — which the
   no-live-writer escape read — carried no safety; it was removed the
   same day, escape and all, leaving only the grace.
5. **Identical bytes share an etag — found by the LIVE DRILL, not the
   model** (runcv A3, `churn/p14.txt`; syncer finding 13). S3's etag for a
   whole PUT is the MD5 of the bytes. A deletes a path; B rewrites it with
   the SAME bytes and uploads, lease-free, If-Match its baseline — which
   is that very etag, so the PUT lands and the object reads exactly as
   the version A's GC recognises. A's GC deletes it; B's commit cites it.
   This module minted a unique generation for every write, so no GC could
   ever recognise another writer's upload and `Inv_NoDangling` held over
   a race the product had — finding 2's text above even named the fact
   ("a real etag is the content hash") and drew only the adopt arm's
   conclusion from it. The abstraction was the bug, again.
   `AgentWriteSame` (budget `MaxSameBytes`) now writes a generation the
   writer RECOGNISES; back to the baseline's own, the path is dirty only
   by its stat, which `touched` carries. `LeanBarrierLeaseSameBytesUnverified`
   is `BLADOPT` with one such write and the adopt verification ON:
   VIOLATED in 18 steps, in seconds — the trace is the
   drill's, with the writers' names swapped. The fix (79e7dac9) re-verifies
   EVERY citation the commit adds, uploads as well as adoptions, under the
   lease where no GC runs, and withholds what is gone or moved:
   `VerifyUploadedCitations`. `LeanBarrierLeaseSameBytesVerified` is the
   same world with that constant alone moved: HOLDS, 5,498,470 distinct
   states, depth 38, under two minutes — exhaustive on a laptop.

   `LeanProbeUploadWithheld` proves the withhold fires, and its shortest
   trace was a route the drill never showed: B's same-bytes upload lands,
   then A's upload of NEW bytes — If-Match the same etag, which B's PUT
   did not move — lands over it. In that trace B committed first and would
   only have re-cited what the manifest already cited. Ordered the other
   way it is a loss: A COMMITS its edit, and B's commit then cites its own
   generation over A's — the manifest names a version no key holds and A's
   committed bytes sit at the key, cited by nothing. Nothing dangles, so
   no invariant here could see it; `Inv_NoStaleOverride` (a stamp in
   `CASInstall`, barrier lease only) now does. `LeanBarrierLeaseSameBytesOverride`
   is `BLSAME` pre-fix: VIOLATED in 18 steps, and the trace is exactly the
   syncer test written from it,
   `a_peer_put_over_an_identical_bytes_upload_is_not_cited_as_the_old_version`
   — green with the fix, and failing "seq 3 cites x.txt at <seed etag>" with
   the re-read limited to adopted citations. The re-read covers both routes
   because it compares etags, not presence. The invariant is also listed
   in every barrier-lease strict SAFETY run; re-run on the new module,
   `LeanBarrierLeaseAdoptVerified` (641,858), `LeanBarrierLeaseDeposal`
   (2,047,621) and `LeanBarrierLeaseSyncOverlayHolds` (1,493,045) hold with
   their HEAD distinct-state counts unchanged, so the stamp never fired
   there, and `LeanBarrierLeaseEpochOnly`/`RotationOnly` hold.
   `LeanBarrierLeaseHolds` (two paths, HITL, crash, restart) holds with it
   too, exhaustively on the Mac: 21,754,734 distinct states, depth 35,
   eight minutes. The same world WITH a same-bytes write and the fix
   (`LeanBarrierLeaseSameBytesDeep`, opt-in) stopped on the Mac for disk at
   depth 19 (30,265,184 distinct states, 11.6M queued, no violation) — after
   two false positives it surfaced in `Inv_HITLTracked` (below) — and then
   HOLDS exhaustively on the TLC box (i4i.2xlarge, 8 workers, 40 GB heap,
   TLC 2.19, 2026-09-14): 1,169,317,179 states generated, 382,678,936
   distinct, depth 39, two hours and one minute, every `BLINV` invariant
   including `Inv_NoStaleOverride` and `Inv_HITLTracked` (fingerprint
   collision estimate 0.0069 from the actual fingerprints).

**The ack under two writers — a refinement, not a finding.** The first
sentinel run under the barrier lease violated `Inv_AckBoundaryCoherent`
in 13 steps: B honored a sentinel on the fast path (tree clean, manifest
unmoved since its checkout), A's commit then deleted a path, and B wrote
its ok ack. `BoundaryIncoherent` compared B's baseline with the LIVE
manifest, which with one writer nothing could move between the honor
and the ack. An ok ack names a seq (`remote.seq`); the promise is about
the document at that seq, and a later install that merges from theirs
and preserves this workspace's entries is the two-writer rule working.
So under the barrier lease the three ack stamps read `AckedDoc(s)` —
`instSnap`, which now also records the checkout for a never-installed
writer — and `AckedSrc(s)` for the clock. The durability invariants keep
reading the live manifest. FALSE world untouched.

**The ack under two writers, second refinement — a declined repair.** With
`HitlOverwritesTrackedOnly` in place, the two-writer sentinel world
violated `Inv_AckBoundaryCoherent` again, in 16 steps: a HITL write is
consumed by both writers; A's agent edits on top of it and A uploads,
lease-free and uncited; B's commit owes a citation repair for the HITL
generation it integrated, finds the key holding A's upload, and rightly
declines (`repair`'s HEAD guard, `barrier.rs` "moved again or gone: the
next consume reconciles it"); B's ok ack then names a document citing the
pre-HITL generation while B's baseline holds the HITL one. The stamp's
stated harm cannot follow: a reader of that document is sent to a key
that holds neither the superseded generation nor the cited one, so its
conditional read fails into the newer object — and nothing acked is at
risk (`Inv_HITLDurable` held in the same run). So `CASInstall` records the
repairs it declined BECAUSE THE KEY MOVED (`repairMoved`, BarrierLease
only) and `BoundaryIncoherent` exempts exactly those paths, at that CAS. A
repair skipped while the key still held the integrated generation is not
exempt: `LeanSentinelFastPathUnguarded` is still VIOLATED (4,210 states).
With the exemption `LeanBarrierLeaseSentinel` found no violation through
41,958,554 distinct states at depth 18 (the counterexample was at 16) and
was STOPPED, not exhausted — its state queue passed 19 GB on a machine with
10 GB of disk left. Its exhaustive run needs a larger box; until then this
world is "no violation to depth 18", not "holds".

**The larger box answered: VIOLATED at depth 19** (i4i.2xlarge, 2026-09-13,
62,235,430 distinct states). The gate prints only the last 40 lines of a
failing run, so the invariant's name was lost with the spot instance;
`-simulate` reproduced it on the Mac in 21 minutes as
`Inv_AckBoundaryCoherent` (BFS needs more than 35 GB of queue at that depth;
`-dfid` works only with one worker). Analysed, NOT fixed — a third
refinement: B's ok ack names a document AHEAD of B's tree by a peer's change
queued for B's next consume. The ack is honest; the stamp's `#` fires in
both directions while its harm runs in one. It did expose a small contract
bug in the code: step 7 sets `baseline.seq = installed.seq` while the
writer's foreign queue is non-empty, so `remote.seq` reports "no news" for
up to one floor while the tree lags — FIXED in code (2026-09-14:
`integrated_seq` holds while anything waits in the queue;
`remote_seq_reports_news_while_a_peers_change_waits_in_the_queue`).
Until the invariant's refinement lands,
`LeanBarrierLeaseSentinel` is a known red in the gate (91/92 when the box
ran it).

**The two 2026-09-14/15 box runs.** An i4i.2xlarge ran this world again with
its full log kept: `Inv_AckBoundaryCoherent` at depth 19, the name now
observed rather than inferred, and the same world WITHOUT that invariant
violated `Inv_AckImpliesCited` at depth 20 — an ok ack over a delete another
writer's edit outranked (`results/2026-09-14-sentinel-box/`; fixed in the
syncer, 231cff00, and mirrored here as `AckHonest` over CASInstall). An
i4i.4xlarge then ran the mirrored world, two paths, every invariant except
`Inv_AckBoundaryCoherent`, to EXHAUSTION: **no violation, 4,416,800,243
distinct states**, depth 44, queue empty, exit 0 (15,839,180,692 generated,
16 workers, 13 h 59 min; `results/2026-09-15-outranked-box/p2-twopath.log`).
**Read it with its collision estimate:** TLC puts the expected number of
fingerprint collisions at 2.7 (optimistic) and 1.0 (from the actual
fingerprints). A collision merges two distinct states and skips the second
one's successors, so at this size "exhausted" does not rule out one skipped
branch. The 2026-09-14 SameBytesDeep run, at 383M states, estimated 0.0069.
The successor world runs with the view and symmetry (well under half the
states) and a different fingerprint seed. The run left the gate on
2026-09-15: its successor is tranche 7's `LeanBarrierLeaseSentinelImpl`.

**Budgets.** `BLWORLD` is MaxGen=2/MaxBarriers=2 with crash + restart +
HITL — not `LeanSubtree`'s MaxGen=3: two live writers with a crash AND a
restart passed 2.8M states at depth 16 in the first minute with the
queue spilling to disk (the `SENTRESTART` split, for the same reason).
`BLSENT` is `SENTWORLD` (two touches, HITL, no crash), `BLSTALL` is
MaxGen=2/MaxBarriers=2 (A freezes inside its commit section; a third
barrier is only needed for the adopt race, which has its own world),
`BLADOPT` is one path, MaxGen=2/MaxBarriers=3/MaxRestarts=1 (with two
paths the mutation sat past 1M states at depth 20 and its strict control
would have had to exhaust the lot). `BLSAME` is `BLADOPT` with
`MaxSameBytes=1`: the adopt race and the same-bytes race in one world,
so the control certifies both verifications together. The stall world at MaxBarriers=3 was
4–5M states and three to four minutes per run; at 2 it keeps every stamp
site the deposal needs.

**Not modelled, named rather than omitted.** The window closes at the
CAS here and after the GC deletes in the code, so a HITL write inside
the two-request GC window would be a false positive — the GC finding's
world runs MaxHitl=0 and the writer race is the real one. The 412 arm
parks on the FIRST foreign 412 where `upload_one` preserves and
supersedes and parks on the second; and a vanished base (HEAD → 404) is
a create in the code and a park here (review inbox-5) — both make the
model more conservative than the code, and neither is this tranche's.
Generations are unique mints where real etags are content hashes — except
under `MaxSameBytes`, which lets the agent write a generation it already
RECOGNISES (finding 5). Bytes that coincide with a version the writer
never saw are still not modelled: they would have to extend `known`,
which is the amputation stamp's witness. And a same-bytes rewrite after
the scan is absorbed at Finish rather than kept dirty; the next barrier's
own `AgentWriteSame` reaches the same upload. Aliasing cuts the other way
too: the HITL invariants name a UI write by (path, generation), and an
agent that re-creates a UI write's exact bytes carries its generation. The
first same-bytes run in `BLWORLD` stopped on `Inv_HITLTracked` for exactly
that — A consumed a UI write, its agent deleted it, A published the delete
and collected the object, the agent wrote the same bytes back, and A's
upload put them at the key before its commit cited them: nothing lost, and
nothing the invariant counted as tracking. A first repair (accept a LIVE
tree holding those bytes) failed the next run the same way with A's pod
replaced after the upload — finding 10's loss of the agent's own
re-creation, not of the UI write, whose life had ended at A's published
delete. So the invariant now says that directly: a UI write deleted or
overwritten by a party entitled to (a writer that integrated it, or the
UI's own later write) is RETIRED (`gh.hitlRetired`, sticky), which is what
`objects[p] # pr[2]` always meant with unique generations. The ghost is
written only under `MaxSameBytes > 0`, so no other state space moves. The
relaxation was re-run on a known-bad world — `BLWORLD` with the same-bytes
write and `EarlyInboxDrop = TRUE` — and still VIOLATES: a UI write
consumed, then the pod replaced, nothing retired.
Gated mode is asserted off under the barrier lease (`ASSUME`), per D3.
`Inv_NoDeposedPut` and `Inv_NoFencedOkAck` hold vacuously under the
barrier lease — uploads precede the claim and no refused-fenced ack
exists — and are listed in its strict runs for the FALSE-world reader,
not as coverage.

## Ghost-state reduction (2026-09-15)

Most of `gh` is non-vacuity bookkeeping: counters a probe reads and nothing
else does. In a strict or must-fail run, two states that differ only there
have the same successors and the same invariant values, and TLC explored
both. Two fingerprint reductions, neither of which changes an action:

- **`VIEW StrictView`** keeps every `gh` field an action or an invariant
  reads (29) and drops the rest (44), plus `sc`'s `pendReRun` and
  `stageCarried`. `gen-cfgs.sh` adds it to every safety cfg that checks no
  probe; a probe cfg never gets it.
- **`SYMMETRY PathSym`** (`Permutations(Paths)`): nothing in the module names
  a path. It is added wherever the paths start interchangeable (two or more,
  `FreePaths` empty), and never on a `FairSpec` cfg, because TLC's symmetry
  is unsound for temporal properties.

Measured before wiring:

| cfg | before | VIEW | both |
|---|---|---|---|
| `LeanSentinelHolds` | 1,208,901 | 1,018,269 | 512,322 |
| `LeanBarrierLeaseAdoptVerified` (one path) | 641,858 | 320,184 | — |

**Counts under BOTH are not exact, and verdicts are unaffected.** TLC's
`TLCStateMut.fingerPrint` picks the symmetry representative by comparing
FULL states, dropped counters included, and only then fingerprints that
representative's view. Two states with equal views can therefore pick
different permutations and be counted twice. That is an under-merge: two
states are never merged unless their views are permutations of each other,
so nothing reachable is skipped. But the distinct count depends on
exploration order. Measured on `LeanScopedSyncHolds`:

| setting | distinct states |
|---|---|
| no reduction | 623,431 |
| `VIEW` only | 471,015 at 1 and 4 workers |
| `SYMMETRY` only | 318,985 at 1 and 4 workers |
| both | 246,067–246,183 across four runs |

So a count comparison between two runs that use both is not a preservation
check. Compare verdicts there, and compare counts with the reductions
removed (the tranche 7 check below does that).

A view is sound only while no dropped field is read, so that is checked,
not claimed. `view-census.py` runs first in `check.sh` and fails the gate
when any field outside `StrictGh` is read anywhere except a `Probe*`
definition or the update of another dropped field. It also fails when `sc`
is read as a whole record, or when a variable is added to `vars` and not to
the view. `--selftest` applies five edits that each make the view unsound,
and each must fail the census.

## Tranche 7 (2026-09-15): model the implementation

The CHANGELOG named three shapes the code has had since v1.52.0 and the
module did not have. Each changes which interleavings exist.

- **`WriterQueue`: the writer-LOCAL foreign queue.** A merge's foreign
  upserts AND deletions go to `sc[s].fq`, keyed by path. `Consume` drains
  the queue before the shared inbox's entries, settles an entry the
  baseline already holds first ("already"), and applies queued deletions
  after the entries. A restart keeps the queue; a pod replacement takes it.
- **`EmptyInstall`: a barrier that adds nothing installs nothing.** Three
  routes:
  - the skip-on-no-diff fast path runs on every barrier;
  - `PullOnly` queues theirs and takes it as the merge base, with no claim,
    no window and no CAS;
  - a commit whose merge equals theirs skips the CAS, keeps the seq and
    marks no boundary.
- **`Inv_AckBoundaryCoherent`, the third refinement.** An ok ack whose
  document is ahead of the tree by exactly a change waiting in this
  writer's queue is excused: its reader gets newer bytes, not bytes the
  workspace superseded. The known-bad run for the relaxation is
  `LeanBarrierLeaseQueueDropped`: the merge base moves past a peer's change
  and nothing queues it. It is violated in 14 steps.
  The unguarded fast path was to be a second known-bad and is not one on
  this shape. `LeanBarrierLeaseImplFastPathUnguarded` (one path,
  `FastPathGuards = FALSE`) HOLDS exhaustively: 37,058,304 distinct states,
  depth 36, 26 min (2026-09-15, `results/2026-09-15-local/`). That makes it a
  machine-checked redundancy (the 5q method):
  - *Why the guards are redundant here:* the shipped fast path also
    requires an empty consume, and under the barrier lease the ack is
    judged against the writer's own install, not the live manifest. Neither
    the "no repair owed" guard nor the "manifest unmoved" guard is what
    keeps an ack coherent.
  - *Scope:* one path, and `Inv_AckBoundaryCoherent` only. The guards stay
    in the code, where they save a CAS and back other promises.

**The first run of the queue found a shipped defect, in 19 steps
(`LeanBarrierLeaseQueueTombstoneOverHitl`, `Inv_HITLTracked`):**
1. A deletes p1 and publishes.
2. B's pull-only boundary queues the deletion.
3. The UI writes p1 again and is acked.
4. B's next consume ADOPTS the UI write, then applies the queued deletion
   over it.
5. B's window clear drops the write's inbox entry. The acked bytes stay at
   their key, cited by nothing and tracked by nothing.

`a_ui_write_over_a_peers_delete_survives_the_queued_tombstone` failed on the
1.54.0 syncer that way. The fix, in code and here as `TombstoneHeadsKey`: a
queued deletion applies only while the key is absent. That is the rule the
queue's upserts already followed. `LeanBarrierLeaseQueueHolds` is the
control, and `ProbeTombstoneSuperseded` shows the fix fires.

Three more constants came from trace validation (below): each is a step the
first syncer traces took that the module could not.
- `CommitLoadsCurrent`: the commit merges onto the manifest it loads after
  the claim.
- `Upload412Preserves`: a foreign version at upload is preserved as a
  conflict copy, then superseded; the path parks only when that races.
- `DeclaredConfirmsAbsence`: a sentinel honor deletes on a confirmed first
  absence; the fast path refuses a pending one and still advances the
  two-scan clock.

`IMPL` in `gen-cfgs.sh` is all of these, plus `VerifyUploadedCitations`. The
first box run of the one-path sentinel world on this shape omitted that last
one, and stopped in 16 steps on `Inv_NoStaleOverride`: a cfg error, not a
finding (`results/2026-09-15-outranked-box/p1-onepath.log`).

Every earlier cfg keeps all of these FALSE, and that is checked, not
claimed. Every gate run gives the same verdict on this module as on the
module before tranche 7. Every strict run that uses the view without
symmetry gives the same distinct count. The two strict runs whose reduced
counts differed (`LeanScopedSyncHolds`, `LeanBarrierLeaseSyncOverlayHolds`,
both with view and symmetry; see above) were re-run with the reductions
removed, and give the pre-tranche counts exactly: 623,431 and 1,493,045.

**Wider worlds (opt-in, box-scale).** `Writers` is now a constant: a sequence
in start order, substituted in cfgs as `Writers <- TwoWriters`. It generalises
the "B starts no earlier than A" symmetry break to a chain. On the code's
shape:
- `LeanBarrierLeaseSentinelImpl1` and `LeanBarrierLeaseSentinelImpl`: the
  sentinel world, with one and two paths, and every invariant including the
  refined one;
- `LeanBarrierLeaseSentinelImplCrash` (and `...Crash1`, one path): that world
  with a pod replacement and a restart;
- `LeanBarrierLeaseImplThreeWriters`: one path, a UI write, three writers.
  **HOLDS**, exhaustively on a laptop: 5,086,371 distinct states, depth 41,
  12 min 31 s (2026-09-15), fingerprint-collision estimate 5.2E-6. The first
  three-writer world this module has checked;
- `LeanBarrierLeaseImplFastPathUnguarded`: the redundancy question above
  (HOLDS: the guards are redundant for the ack's coherence, one path).

A box started these on 2026-09-15 at 19:27Z and was stopped after 14 minutes
(no more cloud spend; they run locally now). Neither lane had a violation:
- `LeanBarrierLeaseSentinelImpl1` reached depth 28, 29,178,473 distinct
  states;
- `LeanBarrierLeaseSentinelImpl` (two paths) reached depth 18, 27,715,096
  distinct states, with 11.4M queued.

Logs: `results/2026-09-15-impl-box-aborted/`.

**`LeanBarrierLeaseSentinelImpl1` HOLDS, run to exhaustion on a laptop**
(2026-09-15): the one-path sentinel world under the barrier lease, on the
code's shape, with every invariant, including the refined
`Inv_AckBoundaryCoherent`.
- 36,184,256 distinct states, depth 36, 39 min 50 s, 6 workers.
- Fingerprint-collision estimate 1.7E-4 (optimistic), 0.0023 from the
  actual fingerprints.
- The world that has carried the gate's standing red since 2026-09-13 is
  green on the code's shape, for one path.
- Log: `results/2026-09-15-local/impl1.log`.

**`LeanBarrierLeaseSentinelImplCrash1` violates `Inv_HITLTracked`**
(2026-09-15, laptop): 19 states, 8 min 42 s. `Crash1TwoScan.cfg` (the
two-scan rule on) gives the same shape in 21 states, 22 min 29 s. The trace:
1. A publishes x; B runs no barrier, so B's merge base stays at the seed.
2. The UI writes x over A's publish.
3. B's declared barrier consumes the UI write, and the agent deletes x
   between the consume and the scan. `confirm_absences` puts the delete in
   the delete set.
4. A's older publish outranks the delete. The window clear drops the UI
   write's inbox entry.
5. B's pod is replaced before its queue is applied. The acked write is now
   only the object at its key.

The code reaches step 5, and then converges; the model's invariant stops
there. Pinned by two unit tests,
`an_adopted_ui_write_deleted_under_an_older_peer_publish_converges_when_*`:
- *Pod replaced:* the new incarnation's checkout adopts the current object
  (S3-wins) and its barrier cites it. The UI write survives and the agent's
  delete is lost, the safe direction. Refusing the S3-wins arm fails this
  test at the checkout, so that arm is the load-bearing one.
- *Writer survives:* the queued version is superseded, the delete publishes,
  and GC collects the object by the etag the consume integrated.
- *No later checkout and no survivor:* the untracked sweep (finding 10)
  re-tracks the object.

So this is a model-versus-code gap, not a shipped loss: `Inv_HITLTracked`
does not count S3-wins adoption at checkout. A stricter code rule would close
the window itself: do not drop a consumed entry that the commit neither cited
nor retired. It is not built. Logs: `results/2026-09-15-local/crash1*.log`.

## Finding 10 (2026-09-15): convergence after a lost writer

A writer lost for good between its upload and its commit leaves bytes at a
cited key that nothing tracks. That is not a safety violation (nothing
acked is lost), and no invariant in this module could see it. It is a
state property only once nothing can move: `Inv_QuiescentConverged`.
- *Quiescence* is `~ENABLED SyncerProgress`, not `~ENABLED Next`: an agent
  can always delete a file.
- *The claim:* then every object at a CITED key is the citation or is
  tracked by the inbox. An object at an uncited key is a delete whose GC
  never ran: garbage no checkout serves, a leak, not this.

The first three runs of the check each failed for a model reason, and each
is recorded where it was fixed:
1. An unstarted writer counted as quiet (`StartLease` belongs in progress).
2. The fix's append waited forever behind the window of the writer that
   died holding the cell (no window guard: safety never rested on it).
3. A budget of one tracking spent itself on a live writer's in-flight
   upload.

After those, the results:
- `LeanBarrierLeaseOrphanDiverges`: violated in 12 steps.
- `LeanBarrierLeaseOrphanTracked`: `TrackOrphan`, allowed at ANY time,
  holds with every barrier-lease invariant (2,357,000 states, 5 minutes).
- `ProbeOrphanTracked` fires.

The code's sweep is that rule (`lean/syncer/src/untracked.rs`). A
measurement before it: a NEW writer's checkout already healed the
divergence, because its citation repair cites what it adopted, but live
writers that never check out again did not.

## Trace validation (2026-09-15): the model against the code

The gate says the model is internally sound. It cannot notice the Rust
changing underneath, and findings 12 and 13 both lived in exactly that gap.
`trace/` checks the model against what the syncer DID. The method follows
Cirstea, Kuppe, Loillier, Merz and Ranzato, *Validating Traces of Distributed
Programs Against TLA+ Specifications* (2024).

- `lean/syncer/src/tests_conformance.rs` drives two real syncers over the
  in-memory store with the protocol event trace on. It logs what the trace
  cannot see (agent writes and deletes, UI writes, sentinel touches) as
  `conf_*` events into the same stream.
- `trace/ndjson2tla.py` turns a trace into a sequence of model steps.
  - Etags map to generations; equal bytes get one generation.
  - Seqs are offset from the checkout.
  - Budgets fit the trace exactly.
  - The event-to-action table is in its docstring.
- `trace/TraceLean.tla` advances a cursor only through the action each step
  names, with the reported values bound: adoptions, removals, counts, the
  installed seq, the GC's result, the ack's status. One step is silent: the
  GC skips a delete the merge outranked without an event.
- **Accepted** means TLC reached the end (`TraceIncomplete` violated).
  **Rejected** means it exhausted every way to follow the trace;
  `TRACE-REACHED` names the step it could not take.

`trace-check.sh` requires three things:
- every committed trace in `trace/traces/` is accepted (5);
- five mutations, each one fact of a real trace corrupted by `mutate.py`,
  are rejected at the corrupted event: an upload's etag, a merge's foreign
  count, a tombstone's action, a consume's action, an ack's status;
- five controls are rejected. Each turns off one model correction a trace
  forced (the commit token, the 412 arm, declared deletes, the tombstone
  fix, the writer queue), and the trace that forced it must stop exactly at
  the step that correction governs.

**What it found on its first run** (before those corrections): of five
traces, three were rejected, at the commit's CAS (step 17), an upload that
superseded a foreign version (13) and a declared barrier's scan (14). Each
was the model lagging the code, fixed as the three constants above. The
queued-tombstone finding came from modelling, not from a trace; its
scenario's trace was captured on the fixed syncer and passes.

Limits, named:
- The traces are sequential: each barrier runs to completion before the
  other writer's starts, so they check what the actions DO, not every
  interleaving. Phase 2, below, is the concurrent case.
- Regenerate with
  `FLINT_SYNC_CONFORMANCE_DIR=$PWD/lean/formal/trace/traces cargo test --lib conformance_`
  in `lean/syncer`. Traces from a changed syncer that the model rejects are
  the point of the exercise.

## Trace validation, phase 2 (2026-09-15): a LIVE leg of the storm drill

Phase 1 replayed the conformance harness: two writers, one barrier at a
time, on a double. Phase 2 replays what six writers and a UI actor did to
real S3 — `lean/e2e/writers-live/results/2026-09-15-drill/`, round 3, the
churn leg with the fixed binary.

`trace/drill2tla.py` projects a leg onto ONE PATH and writes the NDJSON
phase 1 already validates, so the checked converter does the rest. Nothing
is inferred that the drill logged: the agents' writes come from their
journals, the UI's from its own (with the etag the gateway answered).
`trace/drill-check.sh` runs it and then corrupts it.

**The leg is a behaviour of the model.** `churn/p23.txt` of `R3-S2-churn-ui`:
5,940 trace lines, 3,258 model steps, six writers, accepted to the end
(depth 3,259, 20,311 distinct states, 3 s). Three mutations of that same
projection — a consume that adopted reported as superseded, a withheld
citation reported as still there, a skipped GC reported as a delete — are
each rejected. Logs: `results/2026-09-15-trace-phase2/`.

Getting there took four corrections to the MODEL, each a place where the
model described something the code does not do:

1. **The handoff, and a claim a waiter never queued for.** The first
   rejection was a claim the model refused: its release had reserved the
   cell for the queue head, and the trace showed another writer taking it
   while the reserved one waited. `epoch_handoff` writes the waiter list
   the holder read AT ITS CLAIM, minus the head it names — which looked
   like the bug, and modelling that payload made TLC report `NoStarvation`
   violated. **That was a mis-model, not a defect:** the handoff's write is
   conditional on the lease token (`PutCondition::IfMatch`), so a ticket
   taken since the claim forces a 412, a re-read and a retry on the adopted
   list (`release`, 8 attempts) — within that budget the code and the
   model's FIFO agree, and the storm's own handoffs land on attempt 1 with
   an empty queue. The real difference is on the WAITER's side: the model's
   `Enqueue` always succeeds, while several arms of `claim_step` answer
   Waiting without reaching the enqueue at all, and an enqueue that loses
   its CAS takes no ticket either. So the code's reserved handoff can name
   nobody while a writer waits, which is what the trace shows. A projected
   replay therefore lets any writer claim a RELEASED cell
   (`ProjectedTrace`), and the model's stronger ticket is left as an open
   question rather than a finding. What is NOT modelled, and is the
   residual worth a look: a holder that loses all 8 handoff races returns
   an error with the cell still held, and the fleet waits out the 60 s
   deposal.
2. **A commit section can end without installing** (`AbandonOnStoreError`).
   S3 answered a window-open PUT with 409 ConditionalRequestConflict; the
   barrier returned the error, released the cell and kept its pending
   sentinel. The model had no such step — its only abandon was a fence.
   **The event trace does not record this at all**: only the prose line
   `Publish honor failed (pending kept, retrying)` says so, which is why
   the projector has to infer it from a barrier that never ends. A trace
   event for it is the obvious rig fix.
3. **A published delete clears the baseline only if the GC COLLECTED the
   object** (`BaselineKeepsUncollected`). `report.deleted` is pushed by the
   GC's collect arms, and step 7 clears the baseline from that list — so a
   delete whose GC skipped (the key held bytes this writer does not
   recognize) keeps its baseline entry, the tree reads as locally deleted at
   the next consume, and an incoming version is PRESERVED rather than
   adopted. The model cleared the baseline for every published delete.
4. **A claim, a wait and the counts are facts about every path**
   (`ProjectedTrace`). A projected replay cannot recompute a scan's upload
   count, a merge's foreign count, an ack's status, or why a barrier
   claimed, so those checks are dropped WHERE THE TRACE CANNOT CARRY THEM
   and only there; everything path-scoped is checked as phase 1 checks it.

Open: `churn/p47.txt` — a path with deletes, a skipped GC and a preserve —
is still rejected, now at a consume that adopts after that skipped GC
(`results/2026-09-15-trace-phase2/p47-open.log`). Either the model's
consume or the code's is wrong there; the trace says exactly which step to
read. Constants 1-3 are FALSE in every gate cfg, so the gate's 110 runs
explore the state spaces they always did.


## Review 2026-09-18: the fence is a count (C2), and the leak flap (H1)

The protocol review of 2026-09-18 (`docs/plans/flint-lean-protocol-review-2026-09-18.md`)
found two routes this module could not exhibit, each because an
abstraction stood where the code has a mechanism. Six runs (117 → **123**).

**C2. The GC fence was an atomic guard; the code's was a count.**
`GCDelete` carried `~Fenced(s)` as a conjunct, so a deposed holder could
never delete in any `EpochCheck` world. The code read the cell before the
pointer CAS and then every 200 deletes, and the DELETE request carries no
epoch (S3's DeleteObject has no fencing token). So a holder that stalled
past the deposal threshold AFTER its CAS landed came back to a delete set
whose etags the successor had just re-cited — its agent rewrote the path
with the same bytes, so the upload landed as the same content-hash etag,
and the successor's commit re-verified it "under the lease, where no GC
runs" — and its If-Match DELETE took it. `GCFencePerDelete` is the arm:
TRUE is the module as it was (and the code after the fix), FALSE removes
the guard and disables `GCDeleteFenced`. A second faithfulness fix rode
with it: the collector's "still referenced" test read the LIVE manifest
(`manifest[p] = 0`), where `barrier.rs` step 6 reads the document THIS
barrier installed (`installed.entries`); it now reads `sc[s].instSnap[p]`.
Identical while the fence is atomic — nobody installs between a holder's
CAS and its deletes — and verified by count on seven census worlds
(below).

- `LeanBarrierLeaseStragglerGC` (BLSTALL, one path, `MaxSameBytes = 1`,
  IMPL, `GCFencePerDelete = FALSE`): **`Inv_NoDangling` VIOLATED in 17
  steps.** A's CAS uncites p, A stalls, B deposes A and cites p at the same
  generation, A thaws and its delete zeroes the object under B's citation.
- `LeanBarrierLeaseStragglerGCFenced` (the same world, fence on): HOLDS,
  276,622 distinct states, depth 30, every IMPL invariant.
- `LeanProbeStragglerGCFenced`: `ProbeFenceAbandoned` violated — the thawed
  straggler reaches its GC and is fenced THERE, not earlier.

The code's fence is a CLOCK now (`barrier.rs` step 6): before every delete,
if the last cell WRITE is older than `renew_within_secs` (20 s), renew — a
conditional write on our token, which a deposal has moved. A deposal needs
the token still for six spaced polls, so a write inside the spacing is
proof, not a guess, and the cost is one PUT per spacing. What remains is a
stall between that renew and the DELETE it licenses; the model's per-delete
observation is that residual's upper bound, and SAFETY.md §4 names it.

**H1. The tombstone looked at the key, not at what the delete retired.**
On a store without a conditional DELETE the collector gives way and the
peer's own retired object stays at the key. The other writer queues the
deletion; its consume finds AN object there and, under `TombstoneHeadsKey`
(the L-1 fix), calls the tombstone superseded. Its baseline keeps the path
while its merge base does not, so the path is a citation-repair candidate
and the next commit re-cites the deleted generation; the first writer's
delete is outranked, then applies, then leaks again: the two flap forever.
`TombstoneNamesRetired` is the arm: the tombstone carries `sc[s].fqRetired[p]`,
the merge base's citation the deletion retired (written where the
tombstone is queued: `CASInstall` and `PullOnly`), and an object at the key
supersedes it only when it is a DIFFERENT generation. IMPL carries TRUE.

The invariant that sees it is new, and it is stated over the manifest and
ONE history variable rather than over the action that resurrects:
`Inv_NoDeleteResurrected == \A p : manifest[p] = 0 \/ manifest[p] # gh.retired[p]`,
where `gh.retired[p]` is the generation a writer's own delete uncited at its
CAS and any agent or UI write of p clears it. It took three known-good
routes to state the record rule: a delete is recorded only if UNCONTESTED
at its publication — no other writer dirty at the path or uploading it (a
same-bytes upload that landed before the delete's CAS and was cited after
it is modify-wins); the publisher's own tree still without the path (an
agent that re-created the file between the scan and the CAS has a write
the next barrier publishes); and no other writer holding a generation of
the path it INTEGRATED and has not yet cited (a consumed UI write: its
citation repair is the "modify" of delete/modify, and modify wins — the
acked write survives and the agent's delete is the one lost, the stance
the Crash1 note above already takes). The C2 control world found the first
two; the collector-off breadth world found the third on the gate's first
run, twice — once through a restart between the CAS and step 7 that left
the merge base behind the writer's own install, and once with an honestly
old base — and both have the same observable history (cited, deleted by a
writer that had integrated it, re-cited by one that had too), so both are
the rule working. A restart-recovers-the-base arm was modelled for the
first and withdrawn: with the third contest in the rule it had no
counterexample to demand — and it returned the same evening as `BaseAtCas`,
once that contest was tightened (below). A repair-only-over-the-expected-citation arm
was tried before that and refuted by `Inv_HITLTracked` in two worlds: it
also blocks the repair that keeps a consumed UI write tracked when a peer
that never saw it deletes the OLD citation, and the window clear then
drops the entry. Each of these is recorded here because a relaxation is
only trusted after its known-bad runs: the LeakHolds world holds with the
final rule and LeakResurrects still fails.

- `LeanBarrierLeaseLeakResurrects` (one path, four barriers,
  `ConditionalGC = FALSE`, `CollectorOff`, IMPL, `TombstoneNamesRetired = FALSE`):
  **`Inv_NoDeleteResurrected` VIOLATED in 18 steps** — the flap's first turn.
- `LeanBarrierLeaseLeakHolds` (the same world with the fix): HOLDS, 91,097
  distinct states, depth 42, every IMPL invariant (the count with the
  final contest rule; the Mac log beside it in `results/` is 91,497 from
  the rule before the third contest).
- `LeanProbeTombstoneOverLeak`: `ProbeTombstoneApplied` violated — a queued
  deletion is actually applied over a leaked object there.

The six IMPL strict worlds carry `Inv_NoDeleteResurrected` too (`IMPLINV`).
Its ghost `gh.retired` is written only under `WriterQueue`, and so is the
tombstone's `sc[s].fqRetired` at `CASInstall`; the `PullOnly` write of the
same field is unguarded, but `PullOnly` needs `EmptyInstall`, which no
queue-free world in the gate sets — so every state space without the
writer queue is preserved by construction, and the census below has the
control arm a census needs: the two worlds WITH the queue must move, and
do. Seven worlds, the module before and after (reductions as the gate runs
them): LeanSubtreeTakeover 566,405; LeanEpochOnlyHolds 92,863;
LeanBarrierLeaseDeposal 619,637; LeanBarrierLeaseSameBytesVerified
2,366,702; LeanRemovalHolds 324,499 — all unchanged;
LeanBarrierLeaseQueueHolds moves 69,490 → 94,846 and
LeanBarrierLeaseCollectorOff 6,802,540 → 12,325,522 (33,684,562 generated,
depth 39), the two worlds that carry the queue, because IMPL now carries
the H1 fix and its ghost (see `results/2026-09-18-review-c2-h1/`; the
after-counts are the Linux box's runs with the final contest rule).

## Review 2026-09-18, evening: the invariant kept finding routes (H1b–H1f)

`Inv_NoDeleteResurrected` was written for H1 and carried by the six IMPL
strict worlds. The first full run on the Linux box put it in front of the
untracked sweep's world (`LeanBarrierLeaseOrphanTracked`, finding 10's
shape with `OrphanTrack = TRUE`) and it went red in 21 steps. Every route
below is a published delete coming back through a citation repair; each
got a test that fails on the tree before it, a fix line whose reversion
fails exactly that test, and an arm with a known-bad world. The record
rule's third contest was tightened on the way, and three routes it had
been excusing came out from behind it.

**H1b — the sweep's entry outlives the citation it was judged against.**
The sweep tracks an object at a CITED key whose etag the manifest does not
cite (`untracked.rs`). A live writer's upload still in flight is exactly
that once its grace elapses; the grace is a timer and a long step 3 beats
it. The uploader then commits that very generation, the entry stays — the
window clear removes only what a barrier CONSUMED — the uploader's agent
deletes the file, the delete is published, and the other writer's consume
adopts the entry (a crash before the uploader's GC and clear keeps both the
object and the entry) or had adopted it while it was still pending (no
crash: the consumer's step 3 spans the uploader's two barriers). Its
citation repair re-cites the deleted generation on every tree. Three rules,
one arm (`OrphanEntryCited`):

- the entry carries the citation the sweep judged against
  (`gh.orphanAt[p]`, the code's `InboxEntry::cited`) and a consume DROPS
  an entry whose citation has moved (`outlived`; `ProbeOrphanOutlived`
  shows it firing);
- an adoption made while the entry still stood is PROVISIONAL
  (`sc[s].judged`, the code's `BaselineEntry::judged`): `RepairOwed`
  requires `JudgedStands`, and `MergeGone` queues a voided path the
  manifest no longer cites as a tombstone, since the merge base may never
  have had it;
- and (`LeakSupersedesNothing`, its own arm) an object at the key
  supersedes a queued deletion only if the manifest cites it or an entry
  this consume honours names it. A leak — a delete's GC that never ran, a
  generation this tree never integrated so its tombstone named an older
  one — supersedes nothing, and the delete reaches the tree. This subsumes
  H1's retired-etag rule for the leak; H1e's tombstone and H1f's restored
  base (below) each close the RESURRECTION half on their own as well, so
  `LeanBarrierLeaseLeakResurrects` now sets all four arms off. What each
  rule still carries is pinned one arm from a neighbour. For the
  resurrection: `…LeakRetiredOnly` (the other three off) — the retired-etag
  rule alone closes it, which is what the code's no-GET fast path relies
  on; `…LeakRestoreOnly` (the other three off) — the restore alone closes it
  too, an honest base leaving no repair to ride. For the convergence, only
  the leak rule: `…LeakFlaps` (the restore alone, under `Inv_TreesConverged`)
  is red — the retired generation the collector left supersedes the
  deletion at every consume and the next install queues it again, forever —
  and `…LeakRuleConverges`, one arm from it, holds; `…LeakSkippedGeneration`
  (one arm from `…LeakHolds`, the leak rule off) is red too — a writer that
  never installed the generation the collector left holds a tombstone
  naming an OLDER one, so the retired-etag rule cannot recognise the leak.
  And the tombstone closes H1b's own resurrection route as well: with it
  on, `LeanBarrierLeaseOrphanResurrects` (the sweep-entry arm off) HELD in
  the first 2026-09-19 gate, so that world now turns the tombstone off too.
  What `OrphanEntryCited` still carries is the sweep's POLICY — an entry
  nobody acked does not outlive the citation it was judged against, and an
  adoption made while it stood is provisional — pinned by the code's tests
  (each rule's mutation fails one), not by a world of its own. Whether to
  keep the policy or drop the two rules as redundant, the way `BaseAtCas`
  and the consume-time pull were dropped, is OPEN (review doc, H1b).

The consume-time drop's mutation SURVIVED its test once the repair-time
rule was in: with the adoption voided later anyway, dropping it early is a
cleanliness rule (the agent never sees a deleted file reappear for a
barrier), and the test now pins that with a "never materialised" assertion
rather than pretending the line carries safety.

**`Inv_TreesConverged`** — a peer's published delete reaches every live
tree — is the invariant the leak rule needed, and it took four drafts: at
quiescence no running writer keeps a clean copy of a path the manifest no
longer cites, UNLESS it still holds the queued deletion — one the next
consume would APPLY, not one the key's leak would supersede again
(`DeletionPending`, the fourth draft, forced by H1f below) — or an owed
repair (budget quiescence, not the protocol), AND only where its merge base
has seen the manifest without the path (a writer that never ran a barrier
after the delete is behind, not stale). Its first world was VACUOUS: at
three barriers the consume that applies the tombstone is the fourth, and
`LeanBarrierLeaseOrphanStaleCopy` held with exactly the fixed world's
state count (2,717,456) — the pair moved to a four-barrier world, and
`LeanProbeLeakApplied` now shows the rule reached.

**The third contest, tightened.** "Another writer holds a generation of
the path it integrated but has not cited yet" also excused a writer that
merely held the CURRENT citation early — through a redundant entry, or
through a restart that left its merge base behind its own install. That is
not a modify. The contest is now `baseline[p] # instBase[p] /\ baseline[p]
# manifest[p]`, and three worlds went red:

**H1c, H1d and H1e — a pending adoption, cited and then knowingly
deleted.** A writer adopts a UI write while it is still pending, and the
writer that cites it later deletes it KNOWINGLY: the adopter itself, after
a restart between its CAS and step 7 left its merge base a generation
behind the document it installed (H1c); a writer that restarted before its
window clear, so the entry outlived the citation and was adopted after it
(H1d); or plainly another writer (H1e). In every case the adopter's merge
sees "baseline ≠ merge base, object at the key" — the very view a delete
that merely RACED the write leaves, where modify rightly wins — and its
repair resurrects the deleted generation. Nothing in the bucket told the
two apart. `ManifestTombstones`: a published delete names the generation it
retired, in the document (`gh.tomb[p]`; the code's
`LeanManifest::tombstones`, inline in the single-object layout and a
content-addressed object beside the chunks in the chunked one, kept until
the path is cited again or `TOMBSTONE_KEEP_SEQS` generations pass), and a
repair whose generation the tombstone names is void (`Entombed`); `MergeGone`
queues the path as a tombstone for the tree. Two arms written on the way
were DROPPED as redundant once this one was in, each found the same way —
its known-bad world would not go red: `BaseAtCas` (the merge base persisted
at the CAS, for H1c; the arm first withdrawn under the broad contest) and a
consume-time "pull" (an entry the manifest already cites becomes the merge
base, for H1d). `LeanBarrierLeaseCollectorOffNoTombstone` is the run that
stays red.

**H1f — a superseded tombstone left the merge base dishonest, and the copy
stayed.** Found by the final run of the four-barrier orphan world
(`LeanBarrierLeaseOrphanConverges`, every arm above on) — the one route of
the evening that is not a resurrection: `Inv_TreesConverged`, written for
H1b, went red in 30 steps. A queued deletion is superseded when the key
holds a DIFFERENT object the manifest cites (the peer re-created the path),
and the consume settles it: the pull that replaces it is the next install's
diff from the merge base. But the base moved past the path in the install
that queued the deletion, so when the path is deleted AGAIN before this
writer installs, the diff has nothing at it — the clean copy of the retired
generation stays forever, uncited, and (baseline ≠ base) a repair candidate
at every barrier, so the skip-on-no-diff never fires either.
`SupersedeRestoresBase`: superseding a deletion restores the merge base to
the generation the delete retired (`fqRetired`; the code's
`ForeignChange.retired`), so the next install queues the deletion again — or
the upsert, if the re-cite still stands. `LeanBarrierLeaseSupersedeDropsBase`
is the same world with the arm off and stays red (30 steps);
`…OrphanConverges` holds with the arm (10,475,529 distinct states, depth
43); `LeanProbeBaseRestored` shows the restore fires (22 steps). The arm
then turned `LeanBarrierLeaseOrphanStaleCopy` GREEN: with the base restored,
the leak rule as shipped no longer leaves a settled stale copy — it queues
the same deletion again at every install and the leak supersedes it again,
forever — and the invariant's "a queued deletion is pending work" exception
excused the flap. The exception now counts a queued deletion as pending
only if the next consume would apply it, or an entry names what supersedes
it: `DeletionPending`, evaluated with the tombstone pass's own rule
(`ObjectSupersedes`, shared with `Consume` so the two cannot drift). The
leak world is red again.

**The crash world, both arms, after the gate** (`results/2026-09-18-crash1-orphantrack/`,
SAFETY §4.4's open half). `OrphanTrack = FALSE` violates `Inv_HITLTracked`
at 21, as it should. `OrphanTrack = TRUE` ran 52 minutes to depth 25 —
148,870,390 distinct states, 549,890,823 generated, 45M queued — without
violating it, and stopped there on `Inv_AckImpliesCited`: the agent's
declared write is published, the writer RESTARTS after step 7 and before
the ack, a peer deletes the path, the re-run honours the pending with a
pull-only install of the peer's document and acks ok over a boundary that
no longer cites the declared bytes while the tree still holds them. No
sweep action is in the trace; `AckHonest` cannot see a pull-only. Open as
H10 (review doc); the TRUE half of §4.4 is still not a hold.

**Fallout the killed local gate never reached, found by the box's first
full run:** `LeanBarrierLeaseQueueTombstoneOverHitl` turned the tombstone
key rule off while IMPL now carried the retired-etag rule, which ASSUMEs
it, and two trace controls did the same — TLC errored instead of
rejecting. The mutation sets both off, and `ndjson2tla.py` derives the
retired rule from the two it depends on.

**Counts** (the final gate, `results/2026-09-18-review-h1f/gate.txt`):
Distinct states per world on the final module (`results/2026-09-18-review-h1f/`;
the gate keeps only a failing run's output, so the counts are that
directory's `census/` runs and the deciding batches). The five queue-free
worlds are unchanged from the morning's census — the control arm:
LeanSubtreeTakeover 566,405; LeanEpochOnlyHolds 92,863;
LeanBarrierLeaseDeposal 619,637; LeanBarrierLeaseSameBytesVerified
2,366,702; LeanRemovalHolds 324,499; and LeanBarrierLeaseStragglerGCFenced
276,442. The worlds that carry the queue moved with the evening's arms:
LeanBarrierLeaseQueueHolds 94,846 → 94,858; LeanBarrierLeaseOrphanTracked
2,717,456 → 2,718,984 (three barriers); the four-barrier
LeanBarrierLeaseOrphanConverges 10,475,529 (31,092,979 generated, depth
43); LeanBarrierLeaseLeakHolds 90,249, `…LeakRuleConverges` the same
90,249 (the retired-etag rule adds no state once the leak rule is on),
`…LeakRetiredOnly` 91,097, `…LeakRestoreOnly` 95,185. The three big IMPL
worlds, run on the module one invariant-only refactor before the final one
(the actions are identical): LeanBarrierLeaseCollectorOff 12,447,478
(33,982,392 generated, depth 39) — from 12,325,522 before H1c–H1f;
LeanBarrierLeaseImplHolds 8,936,778 (25,912,345, depth 32);
LeanBarrierLeaseInboxSnapshot 9,978,206 (28,908,051, depth 35). The
counterexamples: `…OrphanResurrects` 23 (tombstone off), `…OrphanStaleCopy`
21, `…SupersedeDropsBase` 30, `…LeakResurrects` 19 (all four rules off),
`…LeakFlaps` 19, `…LeakSkippedGeneration` 24, `…CollectorOffNoTombstone`
20; the probes `ProbeBaseRestored` 22, `ProbeLeakApplied` 20,
`ProbeOrphanOutlived` 13. Gate: 136/136 green, trace replays ok
(2026-09-19 01:29–02:20 UTC on the Linux box).

## Review 2026-09-19: the ack, the fence's position, and removals (H10, H2, H4)

Three more arms, each FALSE as the code shipped and TRUE in `IMPL` once the
code matched; each has a known-bad world in the gate. Every one preserves
the worlds that do not use it: the census control arm (seven worlds, the
C2/H1 census's) reproduces its counts on the final module.

**`AckFromCarrier` (H10).** The crash world at `OrphanTrack = TRUE` stopped
at depth 25 on `Inv_AckImpliesCited`: A's declared write is installed, A
restarts after step 7 and before the ack, B deletes the path, and A's
re-run honours the pending with a PULL-ONLY — `ok`, naming B's document,
while A's tree still holds the declared bytes. `honored` is in-memory and
dies at `Restart`, and the pull-only sets `instSnap` to theirs. Every
barrier that ran while a pending stood set `honored` and the ack followed
at once, so no world had an ack answered by a barrier other than the one
that carried the declaration except across a restart; the code has two
more routes (a failed ack write; the floor's cadence barrier after a failed
honor), found by tracing it. The arm journals, with each carrying install's
CAS, the dirty paths it published (`carryPaths`) and its outranked deletes
(`carryDropped`), kept across `Restart`, cleared by the next consume, the
ack, the retire and a pod replacement; `AckDropped` adds a carried path
whose deletion waits in `fq`, which disables `AckOk` and enables
`AckPartial`. **The first cut named the FIRST carrying install as
`AckedDoc` and was refuted** by `…AckCarried` on `Inv_AckBoundaryCoherent`
in 18 steps: a restart between the CAS and `Finish` made the re-run publish
the agent's post-declaration write, and the ack named a document older than
the tree. Once a peer has deleted a declared path, no document satisfies
both halves of an ok ack; the latest document, `partial`, is the honest
one. (That run was first read on a stale module — `$B:lean-…` in zsh is
the `:l` modifier, and the rsync went to a local directory — and the
module's md5 is now checked on the box before any result is read.)
`LeanBarrierLeaseAckAfterRestart` (one touch, one restart, no HITL: the
crash world's route, reduced) violates at 24; `…AckCarried` holds every
sentinel invariant with `Inv_AckBoundaryCoherent` and
`Inv_NoDeleteResurrected` (4,449,692 distinct, depth 32); `LeanProbeCarrierAck`
shows the journal alone made an ack partial.

**`FenceAfterLoad` (H2).** `CASInstall` carried `~Fenced(s)`, an epoch fence
atomic with the load and the CAS. The code read the cell once, before its
HEAD fan-out and its window, and then loaded and CASed with no fence: a
holder deposed in between loaded its successor's ROTATED document, so the
rotation fenced nothing. With the arm FALSE the one read is `VerifyCell`, a
step of its own, stamping `verifiedAt` with the section's epoch (a claim
mints a new one, so an old stamp never matches), and `CASInstall` and
`CASMiss` require the stamp instead of the fence; `CASFenced` exists only
with the arm on. `LeanBarrierLeaseStragglerLoadsSuccessor` (the C2 straggler
world, the arm off) violates `Inv_NoStragglerInstall` at 16: claim, verify,
stall; B deposes and rotates; A thaws and installs onto B's document.
`…StragglerGCFenced` holds at 276,442 with the arm on, its old count. The
code's fix is the read after the load, which is this module's atomic fence
given the rotation. A restart that releases a deposal before its rotation
(the review's route) is not modelled: `Claim` acquires and rotates in one
action.

**`RemovalNamesGen` and `Inv_RemovalNamesItsVersion` (H4).** A removal was a
bare path, applied if clean, and the amputation stamp excused a delete of
any generation the installer had consumed ("integration followed by
ordinary editing") — so a removal asked for before a UI write, performed
after the consume adopted that write, looked like the agent's own edit.
`gh.remJudged[p]` is the generation the gateway resolved when the removal
was recorded (`TrackedGen`: the newest inbox entry, else the citation); it
stands for the cell's `Removal::etag`, is written in both arms (so the
shipped arm can be judged) and is KEPT in `StrictGh`, so the removal
worlds' counts move (`LeanRemovalHolds` 324,499 → 360,007). With the arm
on, a removal whose generation the tree no longer holds is refused, or
deferred while that generation is still in the inbox. `LeanRemovalOverreaches`
violates at 6 (remove, UI write, consume + apply); `LeanRemovalHolds` and
`LeanRemovalCrashHolds` hold with the arm on.

Gate 141 (38 strict, 56 mutations, 47 probes, by the recipe above; the
136-run split was printed as 37/54/45, one off the recipe's 37/53/46). Results:
`results/2026-09-19-review-h10c/` (the H10 worlds), `…-review-h2/`,
`…-review-final/` (the final module's deciders, gate, census, trace replays).

## Immutable object handles (2026-09-19): the design's arm, built before its code

`docs/plans/flint-lean-immutable-objects-design.md` — the structural fix for
review finding H6, and with it six classes the same-key layout produced. Every
write lands at a HANDLE nobody else writes; the manifest cites handles; a
handle a landed document cites is never overwritten and is collected only once
no document cites it. The owner decided (2026-09-19) to relax fetch-by-bare-
path everywhere and build the model arm first; this section is that arm.

**What the arm is.** `ImmutableObjects` (FALSE in every pre-existing cfg and
NOT in IMPL: IMPL is the code's shape today). Under it `objects` — the one
slot per path that every 412, adopt, park, HEAD-guarded GC and S3-wins arm
arbitrates — is FROZEN (TypeOK pins it), and `versions[p]`, the substrate the
gated tranche left behind, is the set of live handles at `p`. The shipped
`Upload`/`HitlWrite`/`HitlRename`/`GCHead`/`GCDelete`/`TrackOrphan` are
disabled and replaced:

- `UploadIO` / `HitlWriteIO`: register a fresh handle, no condition. The UI
  write REPLACES the cell's entry for its path (one entry per path, as
  `gateway_append` keeps it), retiring the entry it replaced, and records the
  citation the gateway saw (`gh.uiBase`, the entry's `cited`).
- `HitlRenameIO`: a CITATION MOVE — the destination's entry names the
  source's handle, registered at the destination too; nothing is minted.
- `CASInstall` records per path what the install stopped citing
  (`sc.retire`, read from the document it merged onto, as the code's step 6
  reads `current`), and SURFACES what it publishes over: a path it uploaded
  whose citation is neither its merge base nor a generation it integrated
  gets a conflict record naming the cited handle before the upload is cited
  over it — the slot's 412/`Upload412Preserves` arm, taken at the CAS
  (`CommitSurfacesForeign`); `VerifyUploads` is the commit's own re-read of
  every handle its uploads cite, a step of its own BEFORE the CAS;
  `GCCollect` deletes the retired set in one unconditional batch — no HEAD,
  no fence, no lease — sparing what the installed document cites at another
  path and what an inbox entry names, by NAME (`SameHandle`: a generation
  number is a handle name, two paths share one only through a rename, and
  the seed generation at another path is another handle).
- `SweepOrphan`: a handle nothing cites, no entry names and no conflict
  record preserves is collected, by a writer INSIDE its commit section, never
  its own in-flight uploads. No grace is modelled.
- The consume judges a gateway entry against the citation the gateway saw: a
  citation that moved to a later UI write supersedes it (dropped, retired);
  one that moved to a writer's publish makes it a CONFLICT (surfaced, its
  handle preserved), never an adoption over the published version; one that
  moved to the entry's OWN handle — a peer's publish of that very write — is
  LIVE, and the ordinary rules apply (the second box run found the arm
  reading it as "superseded"); one that moved to an EARLIER UI write leaves
  the entry live too — the newer write wins.
- `Inv_NoDangling` reads `manifest[p] \in versions[p]`; `Inv_HITLTracked`'s
  "the object is gone" excuse is gone with the slot — under handles a
  destruction is either the collector's decision (`hitlRetired`) or a loss.

**The rules, each refuted by its mutation** (laptop pilot depths; the box run
is `results/2026-09-19-immutable/`):

| rule | mutation | world | violates |
|---|---|---|---|
| R3: retirement spares a handle the installed document cites at another path | `RetirePerPath` | `LeanImmutableRetirePerPath` (the removal world under the barrier lease) | `Inv_NoDangling`, a 9-state trace (box depth 11) — a UI rename's destination cites the source's handle, the source's removal retires it, the collector takes it at both names. The FIRST trace, same depth, had NO rename in it: the collector was taking p2's seed generation for p1's (see the second box run below) |
| R4a: the commit re-reads its uploads before citing them | `VerifyUploadedCitations=FALSE` | `LeanImmutableCasCitesBlind` | `Inv_NoDangling` at 19 |
| R4b: the sweep runs under the lease | `SweepUnderLease=FALSE` | `LeanImmutableSweepLeaseFree` | `Inv_NoDangling` at 11 — a lease-free sweep between the re-read and the CAS |
| R4c: the sweep spares what an inbox entry names | `SweepSparesTracked=FALSE` | `LeanImmutableSweepTakesTracked` | `Inv_HITLDurable` at 9 — an acked UI write collected before any consume |
| R7: the commit surfaces what it publishes over | `CommitSurfacesForeign=FALSE` | `LeanImmutableCasOverridesUI` (the HitlOverAny world) | `Inv_HITLDurable` at 18 (box 19) — an acked UI write a peer published, cited over blind by a writer that never learned it: the second box run's own trace |
| R7, a peer's publish | `CommitSurfacesForeign=FALSE` | `LeanImmutableCasOverridesPeer` (the probe world with a two-mint budget: both writers edit) | `Inv_NoStaleOverride` at 20 (box) — both writers edit the path, one publishes, the other's CAS cites its upload over that with no record; the breadth world's one-mint budget cannot reach it (still searching at depth 24 with nothing found when that was read off the mint guard) |
| R2: a repair never re-cites a handle the document cites at another path this install keeps | `RepairRespectsMoves=FALSE` | `LeanImmutableRepairRecites` (the rename world) | `Inv_OneName` (box, the fourth run's shape at 18) — an adopter that never saw the removal re-cites the moved handle at its old name |
| L-117: an answered removal record still moves the named version out of a tree that holds it clean | `AnsweredRecordsApply=FALSE` | `LeanImmutableAnsweredRecordSkipped` (the rename world) | `Inv_OneName` — a tree that adopted the source's write before the rename keeps it at the old name beside the destination's (the core model's trace); the seventh run's own shape is the same rule's one-barrier lag |
| L-118: a citation repair yields to a later UI write the document already cites | `RepairYieldsToLaterUI=FALSE` | `LeanImmutableRepairOverridesUI` (the rename world) | `Inv_HITLDurable` at 18 (box, the eighth run) — an older adoption re-cited over the user's newer write, published by a peer, with no record |
| L-119: an adoption declined for the MOVE ALONE, at the destination of a rename still waiting at its source, is PENDING — its entry stays in the cell | `PendingAdoptionStays=FALSE` | `LeanImmutablePendingAdoptionDropped` (the rename world), `LeanCorePendingDropped` (the core) | `Inv_HITLDurable` / `Inv_AckedNamed` — the entry left the cell with the rest of the consumed, the peer that applied the answered record uncited the source, and the collector took the handle: the rename lost at both names (the tenth box run's route, reached through `LeanImmutableRepairOverridesUI` because no step in it reads a mutated constant) |

R4 as FIRST DRAFTED ("judge an orphan by the lease epoch stamped on it; below
the cell's epoch is a dead writer's") was refuted by writing the arm, before
any run: under the per-barrier lease the uploads precede the claim, so a live
writer's uploads carry its previous epoch. The design document was corrected.

**What the first box run found** (`results/2026-09-19-immutable-attempt1/`,
module `b22870eb…`): every holds world with a UI write went red on
`Inv_HITLTracked` (QueueHolds at depth 13, Holds at 14, HitlOverAny at 13),
and the rename world on `Inv_RenameAtomic` at 14.

- The HITL route: a writer consumes a UI write, its agent deletes the path,
  the install retires only the OLD citation (the UI handle was never cited),
  and the consumed UI handle is left as garbage with no decision recorded.
  Under the slot the overwrite WAS the decision; under handles nothing is
  overwritten, and the invariant — deliberately — no longer excuses a gone
  handle. Rule: a writer that integrated an acked write (its baseline holds
  it, it is in `known`) and publishes its own edit or delete of the path
  retires it at its CAS (`CASInstall`'s `hitlRetired` stamp). QueueHolds then
  holds, 154,860 distinct, depth 38 (laptop).
- The rename route: a UI rename to a destination another writer is
  concurrently CREATING. The gateway cannot see an in-flight upload (nothing
  sits at a key: `~Tracked(q)` is all it can ask), so the rename lands; the
  install cites the agent's file at the destination while the source still
  cites the moved handle. The shipped invariant read "the new name is cited
  by anything", which the shipped model could never reach (the key was
  occupied). Under handles the claim is "the same handle is never cited under
  both names" (`manifest[q] = r[4]`, the IO arm of `Inv_RenameAtomic`), and a
  rename's destination entry that the consume finds STALE is a taken
  destination (`staleAt(q)` in `dstTaken`): the source's removal is refused,
  the source stays, the moved bytes survive as a conflict copy — the
  delete/rename design's §5 outcome, by the consume rule instead of the key.

**What the second box run found** (`results/2026-09-19-immutable-attempt2/`,
module `8a0324ca…`, the two rules above in place): `Inv_HITLDurable` at
depth 18 in HitlOverAny and RenameHolds; every other holds world green
(Holds 13,956,600 distinct at depth 35, OrphanCollected 891,356, LeakHolds
64,731, QueueHolds 154,860).

- The trace: the UI writes p1 and is acked; B consumes the entry and
  publishes it; A — dirty at p1 from an edit made against the OLD version —
  consumes the same entry, and the consume read "the citation moved to the
  entry itself" (a peer's publish of that very write) as "superseded":
  dropped, stamped retired, nothing learned. A then uploaded to a fresh
  handle and its CAS cited that over the published UI write. Under the slot
  A's PUT would have failed If-Match on the old etag, a 412, and
  `Upload412Preserves` would have surfaced the UI's version and superseded
  it knowingly; a fresh handle has no slot to fail on. Two rules (R7 in the
  design): an entry whose citation moved to its own handle is LIVE (the
  ordinary consume applies — a dirty tree surfaces it and publishes over it
  knowingly), and the CAS SURFACES what it publishes over — every uploaded
  path whose citation is neither its merge base nor a generation it
  integrated gets a conflict record naming the cited handle before the
  upload is cited (`CommitSurfacesForeign`; `amp` excludes what this CAS
  surfaced). `…CasOverridesUI` (the run's own trace) and `…CasOverridesPeer`
  (a peer's own publish cited over, `Inv_NoStaleOverride` — the ghost's
  handles form, so the invariant is back in `IOINV`) are the shape without
  it.
- A refutation withdrawn and re-established: the `…RetirePerPath` trace had
  NO rename in it. A removal of p1 retired the seed generation, and the
  collector removed "1" from p2 as well — a generation number is a handle
  NAME, and the seed's is one number at every path but a different handle at
  each. `SameHandle` (a rename's citation move, `renamed` `<<p, q, g, g>>`,
  is the only aliasing) now governs `GCCollect`'s spare-and-take,
  `SweepOrphan`'s guards and `Inv_QuiescentConverged`; the per-path
  refutation goes through the rename it was written about (the table above).

**What the later box runs found** (`results/2026-09-19-immutable-attempt3/`
to `…-attempt7/`; the module of each is in its `module.md5`):

- The third: `…CasOverridesPeer` had been emitted in the breadth world,
  where `gh.nextGen <= MaxGen` with MaxGen=2 allows ONE mint and the route
  needs both writers' edits — unreachable, a mutation that could never
  find anything. Moved to the probe world with MaxGen=3; it violates
  `Inv_NoStaleOverride` at depth 20 in under a minute.
- The fourth: `Inv_RenameAtomic` at depth 18 in RenameHolds — an adopted UI
  write, renamed by the UI and performed by a peer, re-cited at its old
  name by the adopter's citation repair. R2 gained its clause: a repair
  never re-cites a handle the document cites at another path
  (`MovedElsewhere`).
- The fifth, killed before its verdict: that clause as first written
  declined the rename PERFORMER's own destination (the source leaves in the
  same install). `KeepsAt`: the clause holds only while this install keeps
  the other path at the handle.
- The sixth: `Inv_RenameNoHole` at depth 13 — the seed generation at a
  third path read as the same handle. `MovedElsewhere` judges by name
  (`SameHandle`), as the collector and the sweep do.
- The seventh: `Inv_HITLTracked` at depth 13, and this one was in the CODE
  too (L-117). The agent dirties p1; the UI renames p1 to p3; the consume
  adopts p3 WITH p1's handle and REFUSES the removal (a dirty source); the
  agent then deletes p1. At the barrier the two-scan guard keeps p1 cited,
  the repair at p3 is declined as "moved elsewhere" (p1 holds the handle
  and this install keeps it), the consumed entry leaves the cell, and a UI
  write at p3 in the next round replaces an acked version nothing had
  cited. The first fix re-minted the destination as a server-side copy
  under a handle of its own, to keep one handle under one name; the core
  model (`LeanCore.tla`, written the same evening) then found in five
  minutes on the laptop that the copy answered the wrong question. Its two
  traces: a rename left the source's PENDING entry in the cell beside the
  destination's, and a writer consuming after the move adopted the handle
  at both names; and a removal one writer had refused was skipped by every
  other writer, so a tree that had adopted the source's write before the
  rename kept it at the old name beside the destination's — one handle
  cited twice either way, copy or no copy. The rules that close both
  (L-117): a rename takes the source's pending entry with it, the entry
  being the citation it moves, and the removal names the version that
  entry was written over (`RenameMovesEntry`, `remOver`); and an answered
  record still moves the named version out of a tree that holds it clean
  at the source (`AnsweredRecordsApply`, `gh.answered`) — with which the
  seventh run's own shape resolves in ONE barrier, the agent's delete
  making the source a declared removal, and the copy is not needed. The
  consume also stamps a version the tree had integrated that a LATER UI
  write at the same path replaces (the UI's own hand, the slot's
  overwrite one consume late) — the seventh run's pair. The naming claim
  itself is now an invariant of every handles world, `Inv_OneName`; R2's
  clause got the pin it never had (`RepairRespectsMoves=FALSE`,
  `…RepairRecites`, the fourth run's shape), and the answered-record rule
  its own (`…AnsweredRecordSkipped`). Three syncer tests written from the
  traces fail on the shipped rules. With the same fix, `GCCollect` stopped
  sparing a handle named only by an entry THIS barrier consumed — the
  code's collector never had (the entry leaves the cell at Finish) — and
  `sc.surfaced` carries the code's consume-dirty sentinel: a baseline that
  names a version the tree SURFACED is never a repair, which the core's
  first trace also found (the model re-cited a moved handle at the refused
  source after the agent deleted its edit there).
- The eighth: `Inv_HITLDurable` at depth 18 in RenameHolds, on the module
  with the copy — and independent of it. The UI's rename lands its entry at
  p3; A adopts it; the UI writes p3 again; B adopts the later write and
  publishes it; A's barrier re-cites its older adoption OVER it: the merge
  let a citation repair beat a foreign citation as an upload does, and the
  user's newer write was retired by a writer that never saw it, with no
  record. A repair now YIELDS to a later acked UI write the document cites
  at the path (`SupersededByUI`, `RepairYieldsToLaterUI`; its mutation
  `…RepairOverridesUI`), the tree taking the newer version through its
  queue; and the CAS surfaces a repair it publishes over a version the tree
  never integrated, as the code's merge always did for every upsert
  (`published` in `contested`). L-118.
- The tenth run's first world, `LeanImmutableRepairOverridesUI`, violated
  `Inv_HITLDurable` at depth 18 after 61 minutes and 76 million states —
  by a route that reads no mutated constant, so the rename world has it
  too. A refused rename's DESTINATION, adopted by the refusing tree, is
  committed while the source is still cited (the agent deleted the source
  between Consume and Scan; a first absence is withheld): the move rule
  rightly declines to cite the handle beside its source, and the model —
  like the code — then dropped the adoption as gone (the entry consumed).
  Nothing named the handle but the source's citation; the peer applying the
  answered record removed that, and the collector took the handle. The
  code is fixed and tested (a repair declined for a move whose rename
  still waits at its source is PENDING: the entry stays in the cell, the
  tree keeps its copy). Both models now carry the rule, at the CAS that
  declines: the pending entry leaves that barrier's consumed set there —
  before the collector, which spares what an entry it did not consume
  names, and before the window clear, which drops what it did
  (`PendingAdoptionStays`, TRUE shipped; the mutation worlds
  `LeanImmutablePendingAdoptionDropped` and `LeanCorePendingDropped`, and
  the probes `…ProbePending` that say the shipped world reaches the rule
  at all). The core's `Inv_AckedNamed` was too weak to see this route: a
  tombstone at ANOTHER path accounted for the destination's ack. It is
  tightened — a citation or tombstone elsewhere counts only where the move
  was acked there. (The same edit first over-tightened the OTHER disjunct,
  to a delete or an edit on top; `LeanCoreHolds` then failed on a route
  that is not a defect — the agent deletes the renamed destination, the
  barrier publishes that delete, and the agent writes a FRESH file at the
  path, which erases the "this tree deleted it" witness. A tree accounts
  for a handle by no longer HOLDING it; only holding it unchanged, which
  can never be published, does not.) L-119.
  The same side check that ran the previous shape's base world against the
  staged module found `Inv_NoDangling` violated at state 2: the handles
  refactor had rewritten its same-key arm to demand the key hold the exact
  cited generation, which that shape never promised. Restored
  (`objects[p] # 0` on the same-key shape; the exact handle under handles).

**What the core's own two-path world found** (2026-09-20). `LeanCoreHolds`
on three paths is a BOX world — 120 million states and still climbing at
depth 19 — so the gate gets `LeanCoreHoldsSmall`, the same shape on two
paths (48,995,156 states, depth 34, twenty-odd minutes on the box's
workers; twenty-five on the laptop's four before `took` was added). Its first run refuted the core's own merge vocabulary twice,
both times in the MODEL and not in the code:

- `KeepsAt` — "this install keeps q at handle h", the premise the move rule
  (R2) declines a repair on — was two guesses: the scan's upload set, and
  any path whose baseline had moved. An upload the re-read WITHHELD moves
  nothing (the merge drops it and q keeps its citation), and a path this
  barrier uploaded has no repair to make. Read that way, a rename's source
  looked moved off the handle when the install left it exactly where it
  was, and the same install cited the destination's repair beside it: one
  handle under two names. It is now `inst[q] = h` in the order the CAS
  builds `inst` — gone, then mine, then the repair, then the delete theirs
  outranks — which is the order the code reads off its own upsert map
  (`void_stale_repairs` walks `upserts`, which a withheld upload has left).
- `Scan` made a declared removal a delete even where the agent had
  RE-CREATED the path, so one path was an upload AND a delete. The code
  does not: `barrier.rs`'s scan skips it, "what is here now is a new file
  the agent wrote, and it publishes as one". Deleting that `continue` in
  the code reproduces the model's counterexample exactly — one handle cited
  at both names — which is now pinned by
  `a_rename_whose_parked_source_keeps_its_citation_does_not_cite_one_handle_twice`
  (the syncer battery, 244 green).

Its second run refuted the core's accounting invariant instead — twice, in
both directions — which is what `took` (below) exists for. Its third found
the last of the three: **theirs-or-mine was judged by ONE FLAT SET per
writer.** `Foreign(s, p)` asked whether this tree had ever integrated the
document's generation, anywhere; the code asks at the path (its merge
compares the base with theirs at p, and reads the baseline AT p to decide
whether it integrated what it is publishing over). Flat, a peer that held
the seed at a rename's SOURCE published its own file over the renamed
DESTINATION and surfaced nothing — the version it published over was
familiar, just not at that path — and the handle was retired with no record
(`Inv_AckedNamed` at depth 19). The core now asks per path, under the
constant `ForeignPerPath`.

**The debt this left, paid the next day — and what it was hiding.** For a
day `LeanSubtree` still judged theirs-or-mine by its flat `sc[s].known` and
`LeanRefine` mapped onto that shape (`ForeignPerPath <- FALSE`). Paying it
turned out to be one line per model rather than the per-path rewrite of
`known` this paragraph used to predict, because neither model's exemption
was what the code does. `manifest.rs::merge` has NO exemption — changed
against the merge base is theirs, full stop — and the exemption the commit
applies lives one level up, in R7's surfacing loop: `baseline.entries
.get(path).key == was.key`, the CURRENT baseline AT THAT PATH. So the merge
asks one question and R7 asks another, and both models now split them the
same way. `ForeignPerPath` mutates R7's, and `LeanCoreForeignFlat` prices
the flat form at depth 20.

Then the gate stopped at `LeanSentinelRestart`, a STRICT world, on
`Inv_AckImpliesCited` at depth 18 — and that is the more interesting
finding, because it is about the model. `MineIsNotForeign` is the rule for a
restart between the CAS and step 7: the writer must not read its own install
as a peer's change, or delete/modify outranks its agent's delete and the ack
still says ok. The model implemented that rule by asking whether the
GENERATION was in `sc[s].known`. The code implements it somewhere else
entirely — the intent journal's `installed_etag`, written the instant the
CAS returns and read at the merge: "if the bucket is still at the document
THIS workspace installed, that document IS the merge base, whatever the
persisted one says." The flat set was covering a mechanism the model did not
have, and covering far more besides. Asking per path took the cover away and
the hole showed in eight seconds.

`MergeBase(s)` now carries the journal's rule (still gated by
`MineIsNotForeign`, so `LeanSentinelStaleMergeBase` still refutes it —
at depth 18 or 19 depending on which counterexample the workers reach
first), `ForeignEntry` has no exemption at all, and `LeanSentinelRestart`
holds at 218,762 states. A model can carry the right rule with the wrong
mechanism, and a stronger rule elsewhere will hide it: that is the general
lesson, and it is why the flat set had to go even though every world was
green with it.

**The core model and the refinement** (`LeanCore.tla`, `LeanRefine.tla`;
2026-09-19 evening). `LeanSubtree.tla` is a history: every design the
protocol ever had is still inside it as an arm, and most of its invariants
are ghost stamps that certify the action that wrote the stamp rather than
the harm it names. `LeanCore.tla` is the protocol as it ships, once, with no
arms — the objects (immutable handles named `<<birth path, gen>>`, the
document and its pointer, the cell's entries and removals, the trees) and
the rules, one action each, on one page — with invariants written over
STATE: `Inv_CitationsLive` (every citation names a live handle),
`Inv_OneName` (one handle is never cited under two names) and
`Inv_AckedNamed` (an acknowledged handle that is gone is accounted for by
something in the state that names it: a conflict record, a citation or
tombstone derived from it through recorded provenance, a later acknowledged
write at its path, or a tree that TOOK IT IN AT THAT PATH and no longer
holds it). That last disjunct is the one the 2026-09-20 session had to get
right three times. It began as "a tree that integrated it and deleted it or
EDITED on top of it", which `LeanCoreHolds` refuted on a route that is not a
defect: the agent deletes the renamed destination, the barrier publishes
that delete, and the agent writes a FRESH file at the path, which erases the
"this tree deleted it" witness. Weakened to "integrated it and no longer
holds it", it went the other way and had nothing to say: `integrated` is one
flat set per writer, so a writer that never held the path answered for it,
and the L-119 mutation went GREEN. The core now keeps `took` — per writer
and path, every version that writer's baseline has named there — written by
one conjunct of `Next` off the step itself (a baseline that moved to a new
version at p), not by any action; `LeanRefine` carries the same rule as a
third history variable. With it the three routes come apart: the tree that
deleted the destination is accounted for, the tree that replaced it is
accounted for, and the tree left holding a pending adoption that nothing
names — L-119 — is not.

Each rule is a constant, TRUE in the design, with a world that violates the
invariant it holds up when the rule is off (`LeanCore*.cfg`, emitted by
`gen-cfgs.sh`'s `emit_core`) — seventeen worlds. Thirteen are in the gate
since 2026-09-20: the shipped world on two paths, eight mutations and four
probes. The other four are decided on the box — the three-path holds world,
and three mutations that need a third name — `…AnsweredSkipped`,
`…RenameLeavesEntry` and `…RepairOverridesUI`, whose routes TLC had not
found on two paths at 67, 45 and 31 million states. The rules they refute are not left unchecked: the history model
refutes all three (`LeanImmutableAnsweredRecordSkipped`,
`LeanImmutableRepairOverridesUI`, and `LeanImmutableRenameLeavesEntry`,
which the box sizes first). The L-119 mutation
(`LeanCorePendingDropped`) is two paths and three barriers: its route is
depth 18 and it finds it in four minutes, where the three-path shape was
still climbing past 41 million states. Its first run — five minutes on
the laptop, the world of the rename holds run — found two rules the code and
the history model both lacked (L-117: a rename moves the source's pending
entry with it; an answered removal record still applies to a tree holding
the named version clean) and the consume-dirty sentinel the model had never
carried, before the history model's box run reached any of them.

`LeanRefine.tla` is the refinement: `LeanSubtree` under its shipped constants
(`IMPL` + `ImmutableObjects`, crash-free) maps to `LeanCore`, every core
variable a function of the history model's state (a handle's birth path
through `gh.renamed` for the seed and a history variable for mints;
provenance as a second history variable, written only at mints), and TLC
checks `Core!Spec` as a property: each history-model step is a core step or
a stutter, and the core's three invariants hold through the mapping. The
mapping is itself a census of which `LeanSubtree` state the shipped shape
reads. It found, in its first runs, the fast path the core lacked (skip on
no diff) and the tree's "seen" pointer generation, both now in the core.
`lean/PROTOCOL.md` is the page written from the core: the objects, the rules
as guard and effect with the invariant each holds up and the world that pins
it, and the invariants as predicates.
Worlds: `LeanRefineQueue` (the queue world: 606,916 states, depth 40, a
minute on the laptop — 636,652 before the merge asked per path) and `LeanRefineProbe` (the probe world: 1,965,383
states, depth 36, twenty-nine minutes on three laptop workers — re-run
2026-09-21 on the settled modules and again on the aligned ones, at
exactly the same count both times: two paths, no UI write and no removal
never reach what the alignment changed), both in
the gate; `LeanRefineRename` (the rename world — run on the box first, a
gate entry once its size is known). A world with a crash or a stall is out
of the core's scope: its writers have no "dead" state.

**The retired classes**, each in its own known-bad world with the same-key
mutation left ON and inert, holding every handles invariant (`IOINV` = BLINV
plus `Inv_NoDeleteResurrected`; `Inv_NoStaleOverride` stays, its ghost
written under handles by a CAS that cites an upload over a citation the
writer never integrated with no record — the shape `…CasOverridesPeer` runs):
`LeanImmutableGCUnconditional` (F1/L-10), `…AdoptBlind` (F2/L-11),
`…HitlOverAny` (F8/L-16), `…LeakHolds` (H1/L-105, L-27, L-102; both leak
rules off, `Inv_TreesConverged` included), `…StragglerGC` (C2/L-104),
`…OrphanCollected` (finding 10 / H6: a writer's pod replaced between its
upload and its commit). Plus the breadth, queue and rename holds worlds
(`…Holds`, `…QueueHolds`, `…RenameHolds`, the last with the rename
invariants) and `…CasVerifies` (the R4a control: 182,906 distinct, depth 33
on the laptop). `Inv_QuiescentConverged` is deliberately NOT checked under
handles: with a lease-bound sweep, quiescence precedes the sweep, and the
harm the invariant named has no state to occupy — the probe below is the
convergence evidence instead.

**Probes**: `…ProbeSwept` (the sweep collected a lost writer's handle),
`…ProbeGC` (a retired handle collected), `…ProbeUploadWithheld` (the re-read
withheld a swept upload), `…ProbeHITLCited`, `…ProbeRename`.

Gate 182 (51 strict, 74 mutations, 57 probes). The census control arm — the
seven shipped-shape worlds — must be unchanged from the 2026-09-19 review's
counts (`results/2026-09-19-review-final/NOTES.md`); the arm is FALSE in all
of them and `versions` stays frozen, so by construction it is.

**What the arm does NOT say.** Nothing about the ingress namespace (outside
writers to `files/` are not modelled, as they never were), nothing about the
sweep's grace (a cost lever), and nothing about the gateway's door
precondition (judged in the cell CAS in the design; the model's UI write is
one step). The manifest-level rules — the tombstone, the queue, the merge —
are unchanged and their worlds still run under handles.

## Tranche 3 candidates (in review-priority order)

1. Layout/multi-subtree (P2/P3): root-owner designation, foreign
   subtree entries at checkout.
2. Window liveness: the HITL starvation bound (needs fairness — keep
   it OUT of the safety gate; the WF ping-pong trap lives here).
3. Refine ClaimB into the poll protocol with a torn heartbeat task
   (the self-recognition + rotation composition).
4. ~~Product 1 — boundary × barrier × inbox with the deposal arm.~~
   **DONE** (above). Two shipped defects, and three rejected invariant
   formulations before the promise was stated correctly.
5. **Pair the other products that share an action.** "Every arm is
   modelled" is not "every pair of arms that meet in one action is
   modelled" — product 1 × product 2 proved the difference. `SyncScope`
   with `GatedCitation` is the obvious next one: a scoped sync and a
   citation lane both advance `inst_base`, by different rules.
