{
  "status": "partial",
  "nonces": [
    "agents-4-15"
  ],
  "sentinel_mtime_unix_ns": 1789360096989578125,
  "seq": 132,
  "manifest_etag": "\"ef7c25767fe74cef348fdf6751865d7e\"",
  "boundary": "sentinel-deferred",
  "completed_unix": 1789360126,
  "report": {
    "uploaded": 5,
    "deleted": 0,
    "parked": 3,
    "consumed": 19,
    "no_change": false,
    "conflicts": [
      {
        "path": "hot/p07.txt",
        "foreign_etag": "\"5ce6445a34221ee81bc598fb4c95f3fa\"",
        "preserved_key": "writers/a2-20260914042313/.flint/lean/conflicts/782a6c32-1345-43d7-ac85-b37884d5ed30/hot/p07.txt",
        "kind": "consume-dirty",
        "at_unix": 1789360113
      },
      {
        "path": "hot/p01.txt",
        "foreign_etag": "\"4a06d4506e0a52d4e12e0b5fadff8ac5\"",
        "preserved_key": "writers/a2-20260914042313/.flint/lean/conflicts/56fb15cc-d1d5-457d-95df-dea0ff08dfbc/hot/p01.txt",
        "kind": "consume-dirty",
        "at_unix": 1789360113
      },
      {
        "path": "hot/p00.txt",
        "foreign_etag": "\"16d87205540fe147aea0691c2c098f92\"",
        "preserved_key": "writers/a2-20260914042313/.flint/lean/conflicts/95a6dcdb-9544-4a72-8e28-88b591e7630f/hot/p00.txt",
        "kind": "upload-412-preserved",
        "at_unix": 1789360113
      },
      {
        "path": "hot/p24.txt",
        "foreign_etag": "\"012cb0fab96249e94f3281ff5ab26660\"",
        "preserved_key": "writers/a2-20260914042313/.flint/lean/conflicts/fd7fb935-4caa-416e-8158-1e670c0b833f/hot/p24.txt",
        "kind": "upload-412-preserved",
        "at_unix": 1789360113
      },
      {
        "path": "hot/p18.txt",
        "foreign_etag": "\"bbab70ccf238c7cc0b6054da00cb15d2\"",
        "preserved_key": null,
        "kind": "adopt-withheld: the object this barrier found already at its key was replaced or collected before its commit; nothing cited, the path stays dirty and publishes next barrier",
        "at_unix": 1789360124
      },
      {
        "path": "hot/p19.txt",
        "foreign_etag": "\"02311de1d45c5aaa50beb7da93c6d9b4\"",
        "preserved_key": null,
        "kind": "adopt-withheld: the object this barrier found already at its key was replaced or collected before its commit; nothing cited, the path stays dirty and publishes next barrier",
        "at_unix": 1789360124
      },
      {
        "path": "hot/p25.txt",
        "foreign_etag": "\"d02727fe8027112e4db4427da3b0ad19\"",
        "preserved_key": null,
        "kind": "adopt-withheld: the object this barrier found already at its key was replaced or collected before its commit; nothing cited, the path stays dirty and publishes next barrier",
        "at_unix": 1789360124
      }
    ],
    "out_of_scope_foreign": 0,
    "dropped": [
      "hot/p18.txt",
      "hot/p19.txt",
      "hot/p25.txt"
    ]
  }
}