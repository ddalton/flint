{
  "status": "ok",
  "nonces": [
    "agents-2-16"
  ],
  "sentinel_mtime_unix_ns": 1789360098446460917,
  "seq": 135,
  "manifest_etag": "\"1b94af41a7954e625f2db2b9fac529d0\"",
  "boundary": "sentinel",
  "completed_unix": 1789360136,
  "report": {
    "uploaded": 0,
    "deleted": 0,
    "parked": 0,
    "consumed": 13,
    "no_change": true,
    "out_of_scope_foreign": 0
  }
}