{
  "status": "partial",
  "nonces": [
    "agents-5-15"
  ],
  "sentinel_mtime_unix_ns": 1789360086544008962,
  "seq": 130,
  "manifest_etag": "\"985bb01c1423b07f232cb2ca70e6fe41\"",
  "boundary": "sentinel",
  "completed_unix": 1789360121,
  "report": {
    "uploaded": 5,
    "deleted": 0,
    "parked": 3,
    "consumed": 15,
    "no_change": false,
    "conflicts": [
      {
        "path": "hot/p28.txt",
        "foreign_etag": "\"7c022bd998616969fa22397b08c35fb8\"",
        "preserved_key": "writers/a2-20260914042313/.flint/lean/conflicts/81a5f7c5-e3c5-4760-8143-3344d30d2d4c/hot/p28.txt",
        "kind": "upload-412-preserved",
        "at_unix": 1789360100
      },
      {
        "path": "hot/p00.txt",
        "foreign_etag": "\"2e50fef4eaf8abbdc38c4b0d8302a837\"",
        "preserved_key": "writers/a2-20260914042313/.flint/lean/conflicts/1f981ea2-921c-4dc5-b704-a7167694014a/hot/p00.txt",
        "kind": "upload-412-preserved",
        "at_unix": 1789360100
      },
      {
        "path": "hot/p24.txt",
        "foreign_etag": "\"9b7fd47997ec5ec455529d08200a67a3\"",
        "preserved_key": "writers/a2-20260914042313/.flint/lean/conflicts/ca39f3f8-2e98-4b91-9477-4704ff641c16/hot/p24.txt",
        "kind": "upload-412-preserved",
        "at_unix": 1789360100
      },
      {
        "path": "hot/p29.txt",
        "foreign_etag": "\"cbe86057ed7988fac853df03b1ad1eec\"",
        "preserved_key": "writers/a2-20260914042313/.flint/lean/conflicts/5929de0f-c8bd-4b7f-a451-6d75b68a7006/hot/p29.txt",
        "kind": "upload-412-preserved",
        "at_unix": 1789360100
      },
      {
        "path": "hot/p01.txt",
        "foreign_etag": "\"4a06d4506e0a52d4e12e0b5fadff8ac5\"",
        "preserved_key": null,
        "kind": "adopt-withheld: the object this barrier found already at its key was replaced or collected before its commit; nothing cited, the path stays dirty and publishes next barrier",
        "at_unix": 1789360119
      },
      {
        "path": "hot/p18.txt",
        "foreign_etag": "\"bbab70ccf238c7cc0b6054da00cb15d2\"",
        "preserved_key": null,
        "kind": "adopt-withheld: the object this barrier found already at its key was replaced or collected before its commit; nothing cited, the path stays dirty and publishes next barrier",
        "at_unix": 1789360119
      },
      {
        "path": "hot/p25.txt",
        "foreign_etag": "\"84a07402b5d685530e0f12286cb3f9b3\"",
        "preserved_key": null,
        "kind": "adopt-withheld: the object this barrier found already at its key was replaced or collected before its commit; nothing cited, the path stays dirty and publishes next barrier",
        "at_unix": 1789360119
      }
    ],
    "out_of_scope_foreign": 0,
    "dropped": [
      "hot/p01.txt",
      "hot/p18.txt",
      "hot/p25.txt"
    ]
  }
}