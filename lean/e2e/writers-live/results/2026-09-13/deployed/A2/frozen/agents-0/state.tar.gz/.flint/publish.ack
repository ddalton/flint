{
  "status": "ok",
  "nonces": [
    "agents-0-15"
  ],
  "sentinel_mtime_unix_ns": 1789360097753401711,
  "seq": 135,
  "manifest_etag": "\"1b94af41a7954e625f2db2b9fac529d0\"",
  "boundary": "sentinel",
  "completed_unix": 1789360132,
  "report": {
    "uploaded": 5,
    "deleted": 0,
    "parked": 0,
    "consumed": 18,
    "no_change": false,
    "conflicts": [
      {
        "path": "hot/p23.txt",
        "foreign_etag": "\"b726ad28ff6eefa2d16ca0c62d7a088c\"",
        "preserved_key": "writers/a2-20260914042313/.flint/lean/conflicts/a736cdc1-7708-4fe1-9edc-a16fcf531123/hot/p23.txt",
        "kind": "consume-dirty",
        "at_unix": 1789360119
      },
      {
        "path": "hot/p25.txt",
        "foreign_etag": "\"d02727fe8027112e4db4427da3b0ad19\"",
        "preserved_key": "writers/a2-20260914042313/.flint/lean/conflicts/02e262f8-8888-4a02-a1d8-526c992a800f/hot/p25.txt",
        "kind": "consume-dirty",
        "at_unix": 1789360119
      },
      {
        "path": "hot/p06.txt",
        "foreign_etag": "\"4a567c1db9a9b30e3b49acf9d3ddfe58\"",
        "preserved_key": "writers/a2-20260914042313/.flint/lean/conflicts/3f309606-3aba-43e0-92c5-7fd650d46b73/hot/p06.txt",
        "kind": "upload-412-preserved",
        "at_unix": 1789360120
      },
      {
        "path": "hot/p20.txt",
        "foreign_etag": "\"0617278a053960ec5a174c00c442a6bf\"",
        "preserved_key": "writers/a2-20260914042313/.flint/lean/conflicts/9750657b-4c71-466b-a8ce-fe0166c388e4/hot/p20.txt",
        "kind": "upload-412-preserved",
        "at_unix": 1789360120
      },
      {
        "path": "hot/p15.txt",
        "foreign_etag": "\"57bc507f95062e248d1d9fe0218edaa7\"",
        "preserved_key": "writers/a2-20260914042313/.flint/lean/conflicts/1d97e056-b383-4512-a0c5-7e69881f9398/hot/p15.txt",
        "kind": "upload-412-preserved",
        "at_unix": 1789360120
      }
    ],
    "out_of_scope_foreign": 0
  }
}