{
  "status": "ok",
  "nonces": [
    "agents-2-16"
  ],
  "sentinel_mtime_unix_ns": 1789364277581606649,
  "seq": 156,
  "manifest_etag": "\"af7a323a60a4c7bf01e7937d86dd7055\"",
  "boundary": "sentinel",
  "completed_unix": 1789364294,
  "report": {
    "uploaded": 5,
    "deleted": 2,
    "parked": 0,
    "consumed": 14,
    "no_change": false,
    "conflicts": [
      {
        "path": "churn/p13.txt",
        "foreign_etag": "\"dec18f67450ee20ffe393ba359567b31\"",
        "preserved_key": "writers/a3-20260914053244/.flint/lean/conflicts/a5f85c0e-81c4-4eda-b7db-be8ecd2051c9/churn/p13.txt",
        "kind": "upload-412-preserved",
        "at_unix": 1789364278
      },
      {
        "path": "churn/p17.txt",
        "foreign_etag": "\"d8e9f54accdb9cf2a92b8d2b994940f2\"",
        "preserved_key": "writers/a3-20260914053244/.flint/lean/conflicts/4c4924be-6882-4a11-9991-e8e6a69f1b48/churn/p17.txt",
        "kind": "upload-412-preserved",
        "at_unix": 1789364278
      }
    ],
    "out_of_scope_foreign": 0
  }
}