{
  "status": "ok",
  "nonces": [
    "agents-4-16"
  ],
  "sentinel_mtime_unix_ns": 1789364277591196331,
  "seq": 167,
  "manifest_etag": "\"53757e7d1cf20f90cb602c9fb4e78cd5\"",
  "boundary": "sentinel",
  "completed_unix": 1789364324,
  "report": {
    "uploaded": 0,
    "deleted": 0,
    "parked": 0,
    "consumed": 3,
    "no_change": true,
    "out_of_scope_foreign": 0
  }
}