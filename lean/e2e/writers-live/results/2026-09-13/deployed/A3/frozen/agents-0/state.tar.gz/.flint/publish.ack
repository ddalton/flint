{
  "status": "ok",
  "nonces": [
    "agents-0-16"
  ],
  "sentinel_mtime_unix_ns": 1789364266372428528,
  "seq": 153,
  "manifest_etag": "\"06565db790b076abf14633aeb801c658\"",
  "boundary": "sentinel-deferred",
  "completed_unix": 1789364286,
  "report": {
    "uploaded": 3,
    "deleted": 1,
    "parked": 0,
    "consumed": 17,
    "no_change": false,
    "out_of_scope_foreign": 0
  }
}