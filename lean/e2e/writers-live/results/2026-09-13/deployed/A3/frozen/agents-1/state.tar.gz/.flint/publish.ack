{
  "status": "ok",
  "nonces": [
    "agents-1-15"
  ],
  "sentinel_mtime_unix_ns": 1789364270942762326,
  "seq": 167,
  "manifest_etag": "\"53757e7d1cf20f90cb602c9fb4e78cd5\"",
  "boundary": "sentinel",
  "completed_unix": 1789364329,
  "report": {
    "uploaded": 0,
    "deleted": 0,
    "parked": 0,
    "consumed": 5,
    "no_change": true,
    "out_of_scope_foreign": 0
  }
}