{
  "status": "ok",
  "nonces": [
    "agents-5-16"
  ],
  "sentinel_mtime_unix_ns": 1789364276894172362,
  "seq": 163,
  "manifest_etag": "\"5d54ae32d2675b2ad3bb449fdfe87df8\"",
  "boundary": "sentinel",
  "completed_unix": 1789364313,
  "report": {
    "uploaded": 0,
    "deleted": 0,
    "parked": 0,
    "consumed": 0,
    "no_change": true,
    "out_of_scope_foreign": 0
  }
}