{
  "status": "ok",
  "nonces": [
    "agents-3-15"
  ],
  "sentinel_mtime_unix_ns": 1789364262426971225,
  "seq": 154,
  "manifest_etag": "\"b950f6ab084f597d17f1e0ebdb53c050\"",
  "boundary": "sentinel-deferred",
  "completed_unix": 1789364289,
  "report": {
    "uploaded": 3,
    "deleted": 3,
    "parked": 0,
    "consumed": 15,
    "no_change": false,
    "conflicts": [
      {
        "path": "churn/p29.txt",
        "foreign_etag": "\"92406afae24a674a7c630b6c280a921e\"",
        "preserved_key": "writers/a3-20260914053244/.flint/lean/conflicts/4776e40a-467b-48bc-b142-94124ec3cf90/churn/p29.txt",
        "kind": "upload-412-preserved",
        "at_unix": 1789364273
      }
    ],
    "out_of_scope_foreign": 0
  }
}