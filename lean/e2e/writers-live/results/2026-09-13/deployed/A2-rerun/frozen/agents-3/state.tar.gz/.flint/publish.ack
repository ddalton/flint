{
  "status": "ok",
  "nonces": [
    "agents-3-16"
  ],
  "sentinel_mtime_unix_ns": 1789362353161759575,
  "seq": 148,
  "manifest_etag": "\"c8e3c561493d147b7c7512591d5cc105\"",
  "boundary": "sentinel",
  "completed_unix": 1789362389,
  "report": {
    "uploaded": 0,
    "deleted": 0,
    "parked": 0,
    "consumed": 9,
    "no_change": false,
    "out_of_scope_foreign": 0
  }
}