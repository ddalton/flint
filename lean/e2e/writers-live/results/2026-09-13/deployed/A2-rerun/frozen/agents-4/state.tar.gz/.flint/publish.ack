{
  "status": "partial",
  "nonces": [
    "agents-4-15"
  ],
  "sentinel_mtime_unix_ns": 1789362352484364320,
  "seq": 144,
  "manifest_etag": "\"d3d613f21a1a30f3b89bf151023e4be8\"",
  "boundary": "sentinel-deferred",
  "completed_unix": 1789362378,
  "report": {
    "uploaded": 5,
    "deleted": 0,
    "parked": 1,
    "consumed": 19,
    "no_change": false,
    "conflicts": [
      {
        "path": "hot/p00.txt",
        "foreign_etag": "\"16d87205540fe147aea0691c2c098f92\"",
        "preserved_key": "writers/a2-20260914050047/.flint/lean/conflicts/72f893ba-f9ed-4f84-ad89-c4144e687968/hot/p00.txt",
        "kind": "consume-dirty",
        "at_unix": 1789362364
      },
      {
        "path": "hot/p07.txt",
        "foreign_etag": "\"e58e21e19c7c3782a4b720be64b7166d\"",
        "preserved_key": "writers/a2-20260914050047/.flint/lean/conflicts/be4f38fd-3af2-4b66-9c95-d1df194402e2/hot/p07.txt",
        "kind": "consume-dirty",
        "at_unix": 1789362364
      },
      {
        "path": "hot/p24.txt",
        "foreign_etag": "\"9b7fd47997ec5ec455529d08200a67a3\"",
        "preserved_key": "writers/a2-20260914050047/.flint/lean/conflicts/bd0955a1-68b4-4d7e-aec5-6969664a982e/hot/p24.txt",
        "kind": "consume-dirty",
        "at_unix": 1789362364
      },
      {
        "path": "hot/p01.txt",
        "foreign_etag": "\"b8f7b01fc56e476bbf9cece0423cef99\"",
        "preserved_key": "writers/a2-20260914050047/.flint/lean/conflicts/848829a3-aa59-4c6d-b83e-89517ceda96b/hot/p01.txt",
        "kind": "upload-412-preserved",
        "at_unix": 1789362365
      },
      {
        "path": "hot/p06.txt",
        "foreign_etag": "\"c48777d779361aeb35612f31a05a866b\"",
        "preserved_key": null,
        "kind": "adopt-withheld: the object this barrier found already at its key was replaced or collected before its commit; nothing cited, the path stays dirty and publishes next barrier",
        "at_unix": 1789362376
      }
    ],
    "out_of_scope_foreign": 0,
    "dropped": [
      "hot/p06.txt"
    ]
  }
}