{
  "status": "ok",
  "nonces": [
    "agents-1-15"
  ],
  "sentinel_mtime_unix_ns": 1789362347864465687,
  "seq": 139,
  "manifest_etag": "\"b56c448f6964db224836a27621c67a39\"",
  "boundary": "sentinel",
  "completed_unix": 1789362367,
  "report": {
    "uploaded": 5,
    "deleted": 0,
    "parked": 0,
    "consumed": 14,
    "no_change": false,
    "conflicts": [
      {
        "path": "hot/p19.txt",
        "foreign_etag": "\"109c9d4e9f1f3c4bed5d08a58316cbeb\"",
        "preserved_key": "writers/a2-20260914050047/.flint/lean/conflicts/eac1d753-0d97-46d8-b2db-c042f0234331/hot/p19.txt",
        "kind": "consume-dirty",
        "at_unix": 1789362353
      },
      {
        "path": "hot/p28.txt",
        "foreign_etag": "\"d48c1da300d514b51070a212f417f7e1\"",
        "preserved_key": "writers/a2-20260914050047/.flint/lean/conflicts/51040115-ce2a-47a7-93e1-d0d107ede593/hot/p28.txt",
        "kind": "upload-412-preserved",
        "at_unix": 1789362353
      },
      {
        "path": "hot/p11.txt",
        "foreign_etag": "\"83949a8f161dd93a1d9c39e29daabbfd\"",
        "preserved_key": "writers/a2-20260914050047/.flint/lean/conflicts/356d5608-89d6-445b-977e-49ba9bf45a84/hot/p11.txt",
        "kind": "upload-412-preserved",
        "at_unix": 1789362353
      },
      {
        "path": "hot/p27.txt",
        "foreign_etag": "\"8f83edcb3a38c98474168380cdb9c312\"",
        "preserved_key": "writers/a2-20260914050047/.flint/lean/conflicts/bed4d435-b4ff-41f2-8c7a-7060a7aa468d/hot/p27.txt",
        "kind": "upload-412-preserved",
        "at_unix": 1789362353
      }
    ],
    "out_of_scope_foreign": 0
  }
}