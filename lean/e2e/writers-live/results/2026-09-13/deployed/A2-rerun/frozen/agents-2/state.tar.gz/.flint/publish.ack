{
  "status": "ok",
  "nonces": [
    "agents-2-15"
  ],
  "sentinel_mtime_unix_ns": 1789362344703448523,
  "seq": 148,
  "manifest_etag": "\"c8e3c561493d147b7c7512591d5cc105\"",
  "boundary": "sentinel",
  "completed_unix": 1789362392,
  "report": {
    "uploaded": 0,
    "deleted": 0,
    "parked": 0,
    "consumed": 0,
    "no_change": true,
    "out_of_scope_foreign": 0
  }
}