{
  "status": "ok",
  "nonces": [
    "agents-0-15"
  ],
  "sentinel_mtime_unix_ns": 1789362357000044025,
  "seq": 146,
  "manifest_etag": "\"a944582ab1793f3ab9cf6b75e8ec7092\"",
  "boundary": "sentinel",
  "completed_unix": 1789362384,
  "report": {
    "uploaded": 5,
    "deleted": 0,
    "parked": 0,
    "consumed": 14,
    "no_change": false,
    "conflicts": [
      {
        "path": "hot/p23.txt",
        "foreign_etag": "\"b726ad28ff6eefa2d16ca0c62d7a088c\"",
        "preserved_key": "writers/a2-20260914050047/.flint/lean/conflicts/d12f1acd-f5c3-40ff-ad06-baf796a6285d/hot/p23.txt",
        "kind": "consume-dirty",
        "at_unix": 1789362369
      },
      {
        "path": "hot/p06.txt",
        "foreign_etag": "\"c48777d779361aeb35612f31a05a866b\"",
        "preserved_key": "writers/a2-20260914050047/.flint/lean/conflicts/cd1676dd-a3dc-45ec-a5f7-5e368f32d95a/hot/p06.txt",
        "kind": "consume-dirty",
        "at_unix": 1789362369
      },
      {
        "path": "hot/p15.txt",
        "foreign_etag": "\"57bc507f95062e248d1d9fe0218edaa7\"",
        "preserved_key": "writers/a2-20260914050047/.flint/lean/conflicts/5aa0ecc2-21c0-4688-8d64-2e1401ee853f/hot/p15.txt",
        "kind": "upload-412-preserved",
        "at_unix": 1789362369
      }
    ],
    "out_of_scope_foreign": 0
  }
}