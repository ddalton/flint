{
  "status": "ok",
  "nonces": [
    "agents-5-15"
  ],
  "sentinel_mtime_unix_ns": 1789362339937272040,
  "seq": 147,
  "manifest_etag": "\"862b9160e845321bdebb6b196b9e3d4e\"",
  "boundary": "sentinel",
  "completed_unix": 1789362387,
  "report": {
    "uploaded": 0,
    "deleted": 0,
    "parked": 0,
    "consumed": 10,
    "no_change": false,
    "out_of_scope_foreign": 0
  }
}